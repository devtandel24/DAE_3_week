import { Moon, Sun, User, Settings, LogOut, Bell, HelpCircle, Link as LinkIcon, Bookmark } from 'lucide-react';
import { Button } from './ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from './ui/dropdown-menu';
import { Badge } from './ui/badge';
import logoImage from 'figma:asset/5a41359254d30e34254c79b43c72d23d4047b129.png';

interface HeaderProps {
  currentPage: string;
  onNavigate: (page: string) => void;
  onLogout: () => void;
  darkMode: boolean;
  toggleDarkMode: () => void;
  unreadNotifications?: number;
}

export function Header({ currentPage, onNavigate, onLogout, darkMode, toggleDarkMode, unreadNotifications = 3 }: HeaderProps) {
  return (
    <header className="sticky top-0 z-40 h-[72px] bg-white dark:bg-slate-800 border-b border-border shadow-sm">
      <div className="container mx-auto h-full px-4 flex items-center justify-between">
        <div className="flex items-center gap-8">
          <button
            onClick={() => onNavigate('home')}
            className="flex items-center gap-3 hover:opacity-80 transition-opacity"
          >
            <img src={logoImage} alt="dae" className="h-10" />
          </button>
          
          <nav className="hidden md:flex items-center gap-6">
            <button
              onClick={() => onNavigate('projects')}
              className={`uppercase tracking-wide transition-colors ${
                currentPage === 'projects' || currentPage === 'home'
                  ? 'text-[#7C3AED]'
                  : 'text-gray-600 dark:text-gray-300 hover:text-[#7C3AED]'
              }`}
            >
              Projects
            </button>
            <button
              onClick={() => onNavigate('collections')}
              className={`uppercase tracking-wide transition-colors ${
                currentPage === 'collections' || currentPage === 'collection-detail'
                  ? 'text-[#7C3AED]'
                  : 'text-gray-600 dark:text-gray-300 hover:text-[#7C3AED]'
              }`}
            >
              Collections
            </button>
            <button
              onClick={() => onNavigate('my-links')}
              className={`uppercase tracking-wide transition-colors ${
                currentPage === 'my-links'
                  ? 'text-[#7C3AED]'
                  : 'text-gray-600 dark:text-gray-300 hover:text-[#7C3AED]'
              }`}
            >
              My Links
            </button>
            <button
              onClick={() => onNavigate('dashboard')}
              className={`uppercase tracking-wide transition-colors ${
                currentPage === 'dashboard'
                  ? 'text-[#7C3AED]'
                  : 'text-gray-600 dark:text-gray-300 hover:text-[#7C3AED]'
              }`}
            >
              Dashboard
            </button>
          </nav>
        </div>

        <div className="flex items-center gap-3">
          {/* Help Icon */}
          <Button
            variant="ghost"
            size="icon"
            onClick={() => onNavigate('help')}
            className="w-10 h-10 rounded-full"
            title="Help Center"
          >
            <HelpCircle className="w-5 h-5" />
          </Button>

          {/* Notifications */}
          <Button
            variant="ghost"
            size="icon"
            onClick={() => onNavigate('notifications')}
            className="w-10 h-10 rounded-full relative"
            title="Notifications"
          >
            <Bell className="w-5 h-5" />
            {unreadNotifications > 0 && (
              <Badge className="absolute -top-1 -right-1 h-5 min-w-5 flex items-center justify-center p-0 bg-red-500 text-white text-xs">
                {unreadNotifications}
              </Badge>
            )}
          </Button>
          
          <Button
            variant="ghost"
            size="icon"
            onClick={toggleDarkMode}
            className="w-10 h-10 rounded-full"
          >
            {darkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
          </Button>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="w-10 h-10 rounded-full"
              >
                <User className="w-5 h-5" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-64">
              <div className="px-3 py-3 border-b border-border">
                <p className="text-sm">Signed in as</p>
                <p className="truncate">admin@dae.com</p>
              </div>
              <div className="px-3 py-2 border-b border-border">
                <div className="space-y-1">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500 dark:text-gray-400">Name:</span>
                    <span>Admin User</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500 dark:text-gray-400">Role:</span>
                    <span>Administrator</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500 dark:text-gray-400">Access:</span>
                    <span>Full Access</span>
                  </div>
                </div>
              </div>
              <DropdownMenuItem onClick={() => onNavigate('profile')}>
                <User className="w-4 h-4 mr-2" />
                My Account
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={onLogout} className="text-red-600 dark:text-red-400">
                <LogOut className="w-4 h-4 mr-2" />
                Logout
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
  );
}
