import { useMemo, useState } from 'react';
import { Plus, TrendingUp, Eye, Edit, Trash2, ExternalLink, Award, Users, BookOpen, Target, Download, AlertTriangle, Clock, Star, Trophy, Bell, Link, MessageSquare, Share2, BarChart3, Calendar as CalendarIcon } from 'lucide-react';
import { Button } from './ui/button';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from './ui/table';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { mockProjects } from '../lib/mockData';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from './ui/select';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from './ui/popover';
import { Calendar } from './ui/calendar';
import {
  BarChart,
  Bar,
  PieChart,
  Pie,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  Cell,
} from 'recharts';

interface AdminDashboardProps {
  onUploadNew: () => void;
  onCreateShareLink: () => void;
  onEditProject?: (projectId: string) => void;
  onDeleteProject?: (projectId: string) => void;
}

export function AdminDashboard({ onUploadNew, onCreateShareLink, onEditProject, onDeleteProject }: AdminDashboardProps) {
  // Date range state
  const [dateRange, setDateRange] = useState('30');
  const [customDateFrom, setCustomDateFrom] = useState<Date>();
  const [customDateTo, setCustomDateTo] = useState<Date>();
  
  // Calculate comprehensive statistics
  const stats = useMemo(() => {
    const total = mockProjects.length;
    const byCategory = {
      webDev: mockProjects.filter((p) => p.category === 'WEB DEV').length,
      cybersecurity: mockProjects.filter((p) => p.category === 'CYBERSECURITY').length,
      gameDev: mockProjects.filter((p) => p.category === 'GAME DEV').length,
      iot: mockProjects.filter((p) => p.category === 'IoT').length,
    };

    const byLevel = {
      beginner: mockProjects.filter((p) => p.level === 'Beginner').length,
      intermediate: mockProjects.filter((p) => p.level === 'Intermediate').length,
      advanced: mockProjects.filter((p) => p.level === 'Advanced').length,
    };

    const byCurationStatus = {
      curated: mockProjects.filter((p) => p.curationStatus === 'Curated').length,
      public: mockProjects.filter((p) => p.curationStatus === 'Public').length,
      draft: mockProjects.filter((p) => p.curationStatus === 'Draft').length,
      private: mockProjects.filter((p) => p.curationStatus === 'Private').length,
    };

    const byVisibility = {
      public: mockProjects.filter((p) => p.visibility === 'Public').length,
      partner: mockProjects.filter((p) => p.visibility === 'Partner').length,
      private: mockProjects.filter((p) => p.visibility === 'Private').length,
    };

    const byGender = {
      female: mockProjects.filter((p) => p.studentGender === 'Female').length,
      male: mockProjects.filter((p) => p.studentGender === 'Male').length,
      other: mockProjects.filter((p) => p.studentGender === 'Other').length,
    };

    return {
      total,
      byCategory,
      byLevel,
      byCurationStatus,
      byVisibility,
      byGender,
      femalePercentage: ((byGender.female / total) * 100).toFixed(1),
    };
  }, []);

  // Chart data
  const categoryData = [
    { name: 'Web Dev', value: stats.byCategory.webDev, color: '#7C3AED' },
    { name: 'Cybersecurity', value: stats.byCategory.cybersecurity, color: '#EC4899' },
    { name: 'Game Dev', value: stats.byCategory.gameDev, color: '#8B5CF6' },
    { name: 'IoT', value: stats.byCategory.iot, color: '#F472B6' },
  ];

  const levelData = [
    { name: 'Beginner', value: stats.byLevel.beginner, color: '#10B981' },
    { name: 'Intermediate', value: stats.byLevel.intermediate, color: '#F59E0B' },
    { name: 'Advanced', value: stats.byLevel.advanced, color: '#EF4444' },
  ];

  const industryData = useMemo(() => {
    const industries = new Map<string, number>();
    mockProjects.forEach((p) => {
      industries.set(p.industry, (industries.get(p.industry) || 0) + 1);
    });
    return Array.from(industries.entries())
      .map(([name, count]) => ({ name, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 8);
  }, []);

  const trackData = useMemo(() => {
    const tracks = new Map<string, number>();
    mockProjects.forEach((p) => {
      tracks.set(p.track, (tracks.get(p.track) || 0) + 1);
    });
    return Array.from(tracks.entries())
      .map(([name, count]) => ({ name, count }))
      .sort((a, b) => b.count - a.count);
  }, []);

  const yearData = useMemo(() => {
    const years = new Map<number, number>();
    mockProjects.forEach((p) => {
      years.set(p.year, (years.get(p.year) || 0) + 1);
    });
    return Array.from(years.entries())
      .map(([year, count]) => ({ year: year.toString(), count }))
      .sort((a, b) => parseInt(a.year) - parseInt(b.year));
  }, []);

  const themeData = useMemo(() => {
    const themes = new Map<string, number>();
    mockProjects.forEach((p) => {
      p.theme.forEach((t) => {
        themes.set(t, (themes.get(t) || 0) + 1);
      });
    });
    return Array.from(themes.entries())
      .map(([name, count]) => ({ name, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 10);
  }, []);

  const techStackData = useMemo(() => {
    const techs = new Map<string, number>();
    mockProjects.forEach((p) => {
      p.techStack.forEach((t) => {
        techs.set(t, (techs.get(t) || 0) + 1);
      });
    });
    return Array.from(techs.entries())
      .map(([name, count]) => ({ name, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 10);
  }, []);

  const frameworkData = useMemo(() => {
    const frameworks = new Map<string, number>();
    mockProjects.forEach((p) => {
      p.frameworks.forEach((f) => {
        frameworks.set(f, (frameworks.get(f) || 0) + 1);
      });
    });
    return Array.from(frameworks.entries())
      .map(([name, count]) => ({ name, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 10);
  }, []);

  const coursesData = useMemo(() => {
    const courses = new Map<string, number>();
    mockProjects.forEach((p) => {
      p.courses.forEach((c) => {
        courses.set(c, (courses.get(c) || 0) + 1);
      });
    });
    return Array.from(courses.entries())
      .map(([name, count]) => ({ name, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 10);
  }, []);

  const projectTypeData = useMemo(() => {
    const types = new Map<string, number>();
    mockProjects.forEach((p) => {
      types.set(p.projectType, (types.get(p.projectType) || 0) + 1);
    });
    return Array.from(types.entries()).map(([name, value], index) => ({
      name,
      value,
      color: ['#7C3AED', '#EC4899', '#10B981'][index % 3]
    }));
  }, []);

  const visibilityData = useMemo(() => {
    const vis = new Map<string, number>();
    mockProjects.forEach((p) => {
      vis.set(p.visibility, (vis.get(p.visibility) || 0) + 1);
    });
    return Array.from(vis.entries()).map(([name, value], index) => ({
      name,
      value,
      color: ['#3B82F6', '#F59E0B', '#EF4444'][index % 3]
    })).filter(item => item.value > 0);
  }, []);

  const genderData = [
    { name: 'Female', value: stats.byGender.female, color: '#EC4899' },
    { name: 'Male', value: stats.byGender.male, color: '#7C3AED' },
    { name: 'Other', value: stats.byGender.other, color: '#8B5CF6' },
  ].filter(item => item.value > 0); // Only show non-zero values

  const curationData = [
    { name: 'Curated', value: stats.byCurationStatus.curated, color: '#10B981' },
    { name: 'Public', value: stats.byCurationStatus.public, color: '#3B82F6' },
    { name: 'Draft', value: stats.byCurationStatus.draft, color: '#F59E0B' },
    { name: 'Private', value: stats.byCurationStatus.private, color: '#6B7280' },
  ].filter(item => item.value > 0); // Only show non-zero values

  // Demographics breakdown data
  const demographicsData = useMemo(() => {
    const breakdown = [
      { name: 'HS New Haven', value: 0, color: '#7C3AED' },
      { name: 'HS Stamford', value: 0, color: '#EC4899' },
      { name: 'Adult New Haven', value: 0, color: '#10B981' },
      { name: 'Adult Stamford', value: 0, color: '#F59E0B' },
    ];
    
    mockProjects.forEach((p) => {
      if (p.programType === 'High School' && p.location === 'New Haven') breakdown[0].value++;
      if (p.programType === 'High School' && p.location === 'Stamford') breakdown[1].value++;
      if (p.programType === 'Adult' && p.location === 'New Haven') breakdown[2].value++;
      if (p.programType === 'Adult' && p.location === 'Stamford') breakdown[3].value++;
    });
    
    return breakdown.filter(item => item.value > 0);
  }, []);

  // Enhanced Analytics Data
  const analyticsData = useMemo(() => {
    const totalViews = mockProjects.reduce((sum, p) => sum + p.views, 0);
    const avgTimePerProject = '4:32'; // Mock data
    const bounceRate = '32%'; // Mock data
    const feedbackForms = 47; // Mock data
    const totalShares = 156; // Mock data
    const activeSharedLinks = 12; // Mock data from LinkManagement

    // Most viewed projects
    const mostViewedProjects = [...mockProjects]
      .sort((a, b) => b.views - a.views)
      .slice(0, 5);

    return {
      totalViews,
      avgTimePerProject,
      bounceRate,
      feedbackForms,
      totalShares,
      activeSharedLinks,
      mostViewedProjects,
    };
  }, []);

  // Project Performance Summary by Track
  const trackPerformance = useMemo(() => {
    const tracks = ['Web Development', 'Cybersecurity', 'Game Development', 'IoT', 'AI & Data Science'];
    
    return tracks.map(track => {
      const trackProjects = mockProjects.filter(p => p.track === track);
      const totalProjects = trackProjects.length;
      const totalViews = trackProjects.reduce((sum, p) => sum + p.views, 0);
      const avgViews = totalProjects > 0 ? Math.round(totalViews / totalProjects) : 0;
      
      // Calculate average difficulty level
      const levelScores = { 'Beginner': 1, 'Intermediate': 2, 'Advanced': 3 };
      const avgDifficultyScore = trackProjects.reduce((sum, p) => sum + levelScores[p.level], 0) / totalProjects;
      let avgDifficulty = 'Beginner';
      if (avgDifficultyScore > 2.3) avgDifficulty = 'Advanced';
      else if (avgDifficultyScore > 1.6) avgDifficulty = 'Intermediate';
      
      return {
        track,
        totalProjects,
        totalViews,
        avgViews,
        avgDifficulty,
        color: track === 'Web Development' ? '#3B82F6' :
               track === 'Cybersecurity' ? '#EF4444' :
               track === 'Game Development' ? '#10B981' :
               track === 'IoT' ? '#F59E0B' : '#7C3AED'
      };
    });
  }, []);

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-slate-900">
      <div className="container mx-auto px-4 py-8 space-y-8">
        {/* Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <h1 className="mb-2">Admin Dashboard</h1>
            <p className="text-gray-600 dark:text-gray-400">
              Manage and monitor all student projects
            </p>
          </div>
          <div className="flex gap-3">
            <Button
              onClick={onCreateShareLink}
              variant="outline"
              className="gap-2"
            >
              <ExternalLink className="w-4 h-4" />
              Create Share Link
            </Button>
            <Button
              onClick={onUploadNew}
              className="bg-gradient-to-r from-[#7C3AED] to-[#EC4899] hover:opacity-90 gap-2"
            >
              <Plus className="w-5 h-5" />
              Upload New Project
            </Button>
          </div>
        </div>

        {/* Date Range Filter */}
        <div className="bg-white dark:bg-slate-800 rounded-xl p-4 border border-border">
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
            <div className="flex items-center gap-2">
              <CalendarIcon className="w-5 h-5 text-gray-600 dark:text-gray-400" />
              <span className="font-medium">Date Range:</span>
            </div>
            <div className="flex flex-wrap gap-2">
              <Select value={dateRange} onValueChange={setDateRange}>
                <SelectTrigger className="w-40">
                  <SelectValue placeholder="Select range" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="7">Last 7 days</SelectItem>
                  <SelectItem value="30">Last 30 days</SelectItem>
                  <SelectItem value="90">Last 90 days</SelectItem>
                  <SelectItem value="365">Last year</SelectItem>
                  <SelectItem value="custom">Custom range</SelectItem>
                </SelectContent>
              </Select>
              
              {dateRange === 'custom' && (
                <Popover>
                  <PopoverTrigger asChild>
                    <Button variant="outline" className="gap-2">
                      <CalendarIcon className="w-4 h-4" />
                      {customDateFrom && customDateTo 
                        ? `${customDateFrom.toLocaleDateString()} - ${customDateTo.toLocaleDateString()}`
                        : 'Pick dates'}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <div className="p-4 space-y-2">
                      <div>
                        <label className="text-sm font-medium">From:</label>
                        <Calendar
                          mode="single"
                          selected={customDateFrom}
                          onSelect={setCustomDateFrom}
                        />
                      </div>
                      <div>
                        <label className="text-sm font-medium">To:</label>
                        <Calendar
                          mode="single"
                          selected={customDateTo}
                          onSelect={setCustomDateTo}
                        />
                      </div>
                    </div>
                  </PopoverContent>
                </Popover>
              )}
            </div>
            <div className="text-sm text-gray-600 dark:text-gray-400 ml-auto">
              Showing data for {dateRange === 'custom' ? 'custom range' : `last ${dateRange} days`}
            </div>
          </div>
        </div>

        {/* Expiring Links Alert */}
        <div className="bg-orange-50 dark:bg-orange-900/20 border-l-4 border-orange-500 rounded-lg p-4">
          <div className="flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-orange-600 dark:text-orange-400 mt-0.5 flex-shrink-0" />
            <div className="flex-1">
              <p className="font-medium text-orange-900 dark:text-orange-200">
                ⚠️ 5 shared links expiring in the next 7 days
              </p>
              <p className="text-sm text-orange-700 dark:text-orange-300 mt-1">
                Review and extend your links to ensure continued access for partners.
              </p>
            </div>
            <Button variant="outline" size="sm" className="flex-shrink-0">
              Review in My Links
            </Button>
          </div>
        </div>

        {/* Key Metrics Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-white dark:bg-slate-800 rounded-xl p-6 border border-border">
            <div className="flex items-start justify-between mb-4">
              <div>
                <p className="text-gray-600 dark:text-gray-400 uppercase tracking-wide mb-1">
                  Total Projects
                </p>
                <div className="text-4xl bg-gradient-to-r from-[#7C3AED] to-[#EC4899] bg-clip-text text-transparent">
                  {stats.total}
                </div>
              </div>
              <Target className="w-8 h-8 text-purple-500" />
            </div>
            <div className="flex items-center gap-1 text-green-600">
              <TrendingUp className="w-4 h-4" />
              <span className="text-sm">All time</span>
            </div>
          </div>

          <div className="bg-white dark:bg-slate-800 rounded-xl p-6 border border-border">
            <div className="flex items-start justify-between mb-4">
              <div>
                <p className="text-gray-600 dark:text-gray-400 uppercase tracking-wide mb-1">
                  Curated
                </p>
                <div className="text-4xl bg-gradient-to-r from-[#7C3AED] to-[#EC4899] bg-clip-text text-transparent">
                  {stats.byCurationStatus.curated}
                </div>
              </div>
              <Award className="w-8 h-8 text-green-500" />
            </div>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              {((stats.byCurationStatus.curated / stats.total) * 100).toFixed(0)}% of total
            </p>
          </div>

          <div className="bg-white dark:bg-slate-800 rounded-xl p-6 border border-border">
            <div className="flex items-start justify-between mb-4">
              <div>
                <p className="text-gray-600 dark:text-gray-400 uppercase tracking-wide mb-1">
                  Partner Projects
                </p>
                <div className="text-4xl bg-gradient-to-r from-[#7C3AED] to-[#EC4899] bg-clip-text text-transparent">
                  {stats.byVisibility.partner}
                </div>
              </div>
              <Users className="w-8 h-8 text-blue-500" />
            </div>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              Restricted visibility
            </p>
          </div>

          <div className="bg-white dark:bg-slate-800 rounded-xl p-6 border border-border">
            <div className="flex items-start justify-between mb-4">
              <div>
                <p className="text-gray-600 dark:text-gray-400 uppercase tracking-wide mb-1">
                  Draft Projects
                </p>
                <div className="text-4xl bg-gradient-to-r from-[#7C3AED] to-[#EC4899] bg-clip-text text-transparent">
                  {stats.byCurationStatus.draft}
                </div>
              </div>
              <BookOpen className="w-8 h-8 text-orange-500" />
            </div>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              Needs review
            </p>
          </div>
        </div>

        {/* Enhanced Analytics Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          <div className="bg-white dark:bg-slate-800 rounded-xl p-6 border border-border">
            <div className="flex items-start justify-between mb-4">
              <div>
                <p className="text-gray-600 dark:text-gray-400 uppercase tracking-wide text-sm mb-1">
                  Active Shared Links
                </p>
                <div className="text-3xl bg-gradient-to-r from-[#7C3AED] to-[#EC4899] bg-clip-text text-transparent">
                  {analyticsData.activeSharedLinks}
                </div>
              </div>
              <Link className="w-8 h-8 text-purple-500" />
            </div>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              Currently active
            </p>
          </div>

          <div className="bg-white dark:bg-slate-800 rounded-xl p-6 border border-border">
            <div className="flex items-start justify-between mb-4">
              <div>
                <p className="text-gray-600 dark:text-gray-400 uppercase tracking-wide text-sm mb-1">
                  Total Views
                </p>
                <div className="text-3xl bg-gradient-to-r from-[#7C3AED] to-[#EC4899] bg-clip-text text-transparent">
                  {analyticsData.totalViews.toLocaleString()}
                </div>
              </div>
              <Eye className="w-8 h-8 text-blue-500" />
            </div>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              All projects combined
            </p>
          </div>

          <div className="bg-white dark:bg-slate-800 rounded-xl p-6 border border-border">
            <div className="flex items-start justify-between mb-4">
              <div>
                <p className="text-gray-600 dark:text-gray-400 uppercase tracking-wide text-sm mb-1">
                  Avg. Time
                </p>
                <div className="text-3xl bg-gradient-to-r from-[#7C3AED] to-[#EC4899] bg-clip-text text-transparent">
                  {analyticsData.avgTimePerProject}
                </div>
              </div>
              <Clock className="w-8 h-8 text-green-500" />
            </div>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              Per project view
            </p>
          </div>

          <div className="bg-white dark:bg-slate-800 rounded-xl p-6 border border-border">
            <div className="flex items-start justify-between mb-4">
              <div>
                <p className="text-gray-600 dark:text-gray-400 uppercase tracking-wide text-sm mb-1">
                  Bounce Rate
                </p>
                <div className="text-3xl bg-gradient-to-r from-[#7C3AED] to-[#EC4899] bg-clip-text text-transparent">
                  {analyticsData.bounceRate}
                </div>
              </div>
              <TrendingUp className="w-8 h-8 text-orange-500" />
            </div>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              Below industry avg
            </p>
          </div>

          <div className="bg-white dark:bg-slate-800 rounded-xl p-6 border border-border">
            <div className="flex items-start justify-between mb-4">
              <div>
                <p className="text-gray-600 dark:text-gray-400 uppercase tracking-wide text-sm mb-1">
                  Feedback Forms
                </p>
                <div className="text-3xl bg-gradient-to-r from-[#7C3AED] to-[#EC4899] bg-clip-text text-transparent">
                  {analyticsData.feedbackForms}
                </div>
              </div>
              <MessageSquare className="w-8 h-8 text-pink-500" />
            </div>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              Total submissions
            </p>
          </div>

          <div className="bg-white dark:bg-slate-800 rounded-xl p-6 border border-border">
            <div className="flex items-start justify-between mb-4">
              <div>
                <p className="text-gray-600 dark:text-gray-400 uppercase tracking-wide text-sm mb-1">
                  Total Shares
                </p>
                <div className="text-3xl bg-gradient-to-r from-[#7C3AED] to-[#EC4899] bg-clip-text text-transparent">
                  {analyticsData.totalShares}
                </div>
              </div>
              <Share2 className="w-8 h-8 text-indigo-500" />
            </div>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              Projects shared
            </p>
          </div>
        </div>

        {/* Most Viewed Projects */}
        <div className="bg-white dark:bg-slate-800 rounded-xl p-6 border border-border">
          <h2 className="mb-6">Most Viewed Projects</h2>
          <div className="space-y-3">
            {analyticsData.mostViewedProjects.map((project, index) => (
              <div key={project.id} className="flex items-center gap-4 p-4 bg-gray-50 dark:bg-slate-700 rounded-lg hover:bg-gray-100 dark:hover:bg-slate-600 transition-colors">
                <div className="flex items-center justify-center w-8 h-8 rounded-full bg-gradient-to-r from-[#7C3AED] to-[#EC4899] text-white">
                  {index + 1}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium truncate">{project.title}</p>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    by {project.student} • {project.category}
                  </p>
                </div>
                <div className="flex items-center gap-2 text-gray-600 dark:text-gray-400">
                  <Eye className="w-4 h-4" />
                  <span className="font-medium">{project.views.toLocaleString()}</span>
                </div>
                <Badge className={
                  project.level === 'Beginner' ? 'bg-green-500' :
                  project.level === 'Intermediate' ? 'bg-yellow-500' : 'bg-red-500'
                }>
                  {project.level}
                </Badge>
              </div>
            ))}
          </div>
        </div>

        {/* Project Performance Summary by Track */}
        <div className="bg-white dark:bg-slate-800 rounded-xl p-6 border border-border">
          <div className="flex items-center gap-2 mb-6">
            <BarChart3 className="w-6 h-6 text-purple-500" />
            <h2>Project Performance Summary by Track</h2>
          </div>
          <div className="space-y-4">
            {trackPerformance.map((track) => (
              <div key={track.track} className="p-5 bg-gray-50 dark:bg-slate-700 rounded-lg">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="w-3 h-3 rounded-full" style={{ backgroundColor: track.color }}></div>
                    <h3 className="text-lg">{track.track}</h3>
                  </div>
                  <Badge variant="outline">{track.totalProjects} Projects</Badge>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                  <div>
                    <p className="text-xs text-gray-600 dark:text-gray-400 uppercase tracking-wide mb-1">
                      Total Views
                    </p>
                    <p className="text-xl font-medium">{track.totalViews.toLocaleString()}</p>
                  </div>
                  <div>
                    <p className="text-xs text-gray-600 dark:text-gray-400 uppercase tracking-wide mb-1">
                      Avg Views
                    </p>
                    <p className="text-xl font-medium">{track.avgViews.toLocaleString()}</p>
                  </div>
                  <div>
                    <p className="text-xs text-gray-600 dark:text-gray-400 uppercase tracking-wide mb-1">
                      Avg Difficulty
                    </p>
                    <Badge className={
                      track.avgDifficulty === 'Beginner' ? 'bg-green-500' :
                      track.avgDifficulty === 'Intermediate' ? 'bg-yellow-500' : 'bg-red-500'
                    }>
                      {track.avgDifficulty}
                    </Badge>
                  </div>
                  <div>
                    <p className="text-xs text-gray-600 dark:text-gray-400 uppercase tracking-wide mb-1">
                      Views per Project
                    </p>
                    <p className="text-xl font-medium">
                      {track.totalProjects > 0 ? (track.totalViews / track.totalProjects).toFixed(0) : 0}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Recent Activity Feed */}
        <div className="bg-white dark:bg-slate-800 rounded-xl p-6 border border-border">
          <h2 className="mb-6">Recent Activity</h2>
          <div className="space-y-4">
            <div className="flex items-start gap-4 p-4 rounded-lg hover:bg-gray-50 dark:hover:bg-slate-700 transition-colors">
              <div className="p-2 bg-green-100 dark:bg-green-900/30 rounded-full">
                <Star className="w-4 h-4 text-green-600 dark:text-green-400" />
              </div>
              <div className="flex-1">
                <p className="font-medium">Project 'Smart City Dashboard' added to Top 150</p>
                <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">2 hours ago</p>
              </div>
              <Badge className="bg-green-500">Curated</Badge>
            </div>

            <div className="flex items-start gap-4 p-4 rounded-lg hover:bg-gray-50 dark:hover:bg-slate-700 transition-colors">
              <div className="p-2 bg-orange-100 dark:bg-orange-900/30 rounded-full">
                <Clock className="w-4 h-4 text-orange-600 dark:text-orange-400" />
              </div>
              <div className="flex-1">
                <p className="font-medium">Shared link expired: Partner ABC Cybersecurity Projects</p>
                <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">4 hours ago</p>
              </div>
            </div>

            <div className="flex items-start gap-4 p-4 rounded-lg hover:bg-gray-50 dark:hover:bg-slate-700 transition-colors">
              <div className="p-2 bg-blue-100 dark:bg-blue-900/30 rounded-full">
                <Plus className="w-4 h-4 text-blue-600 dark:text-blue-400" />
              </div>
              <div className="flex-1">
                <p className="font-medium">New project uploaded: 'AI Music Generator'</p>
                <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">Yesterday</p>
              </div>
              <Badge variant="outline">New</Badge>
            </div>

            <div className="flex items-start gap-4 p-4 rounded-lg hover:bg-gray-50 dark:hover:bg-slate-700 transition-colors">
              <div className="p-2 bg-purple-100 dark:bg-purple-900/30 rounded-full">
                <Trophy className="w-4 h-4 text-purple-600 dark:text-purple-400" />
              </div>
              <div className="flex-1">
                <p className="font-medium">Analytics milestone: 10,000 total views reached</p>
                <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">2 days ago</p>
              </div>
            </div>

            <div className="flex items-start gap-4 p-4 rounded-lg hover:bg-gray-50 dark:hover:bg-slate-700 transition-colors">
              <div className="p-2 bg-gray-100 dark:bg-gray-700 rounded-full">
                <Eye className="w-4 h-4 text-gray-600 dark:text-gray-400" />
              </div>
              <div className="flex-1">
                <p className="font-medium">User 'educator@dae.org' accessed project #445</p>
                <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">3 days ago</p>
              </div>
            </div>
          </div>
        </div>

        {/* Charts Tabs */}
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="demographics">Demographics</TabsTrigger>
            <TabsTrigger value="technical">Technical</TabsTrigger>
            <TabsTrigger value="projects">Projects</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Category Distribution */}
              <div className="bg-white dark:bg-slate-800 rounded-xl p-6 border border-border">
                <h3 className="mb-6">Category Distribution</h3>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={categoryData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      outerRadius={100}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {categoryData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </div>

              {/* Difficulty Level Distribution */}
              <div className="bg-white dark:bg-slate-800 rounded-xl p-6 border border-border">
                <h3 className="mb-6">Difficulty Level Distribution</h3>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={levelData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      outerRadius={100}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {levelData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </div>

              {/* Projects by Year */}
              <div className="bg-white dark:bg-slate-800 rounded-xl p-6 border border-border">
                <h3 className="mb-6">Projects by Year</h3>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={yearData}>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-gray-200 dark:stroke-gray-700" />
                    <XAxis dataKey="year" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="count" fill="#7C3AED" radius={[8, 8, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>

              {/* Curation Status */}
              <div className="bg-white dark:bg-slate-800 rounded-xl p-6 border border-border">
                <h3 className="mb-6">Curation Status</h3>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={curationData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      outerRadius={100}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {curationData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>
          </TabsContent>

          {/* Demographics Tab */}
          <TabsContent value="demographics" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Gender Distribution */}
              <div className="bg-white dark:bg-slate-800 rounded-xl p-6 border border-border">
                <h3 className="mb-6">Gender Distribution</h3>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={genderData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      outerRadius={100}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {genderData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </div>

              {/* Top Industries */}
              <div className="bg-white dark:bg-slate-800 rounded-xl p-6 border border-border">
                <h3 className="mb-6">Top Industries</h3>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={industryData} layout="horizontal">
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis type="number" />
                    <YAxis dataKey="name" type="category" width={100} />
                    <Tooltip />
                    <Bar dataKey="count" fill="#EC4899" radius={[0, 8, 8, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>

              {/* Track Distribution */}
              <div className="bg-white dark:bg-slate-800 rounded-xl p-6 border border-border">
                <h3 className="mb-6">Track Distribution</h3>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={trackData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" angle={-45} textAnchor="end" height={100} />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="count" fill="#8B5CF6" radius={[8, 8, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>

              {/* Demographics Breakdown */}
              <div className="bg-white dark:bg-slate-800 rounded-xl p-6 border border-border">
                <h3 className="mb-6">Program Demographics</h3>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={demographicsData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      outerRadius={100}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {demographicsData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </div>

              {/* Key Stats Grid */}
              <div className="bg-white dark:bg-slate-800 rounded-xl p-6 border border-border">
                <h3 className="mb-6">Key Demographics</h3>
                <div className="space-y-4">
                  <div className="flex justify-between items-center p-3 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
                    <span className="text-sm">Female Students</span>
                    <Badge className="bg-pink-500">{stats.byGender.female} ({stats.femalePercentage}%)</Badge>
                  </div>
                  <div className="flex justify-between items-center p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                    <span className="text-sm">Male Students</span>
                    <Badge className="bg-blue-500">
                      {stats.byGender.male} ({((stats.byGender.male / stats.total) * 100).toFixed(1)}%)
                    </Badge>
                  </div>
                  <div className="flex justify-between items-center p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                    <span className="text-sm">Beginner Level</span>
                    <Badge className="bg-green-500">{stats.byLevel.beginner}</Badge>
                  </div>
                  <div className="flex justify-between items-center p-3 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg">
                    <span className="text-sm">Intermediate Level</span>
                    <Badge className="bg-yellow-500">{stats.byLevel.intermediate}</Badge>
                  </div>
                  <div className="flex justify-between items-center p-3 bg-red-50 dark:bg-red-900/20 rounded-lg">
                    <span className="text-sm">Advanced Level</span>
                    <Badge className="bg-red-500">{stats.byLevel.advanced}</Badge>
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>

          {/* Technical Tab */}
          <TabsContent value="technical" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Top Tech Stacks */}
              <div className="bg-white dark:bg-slate-800 rounded-xl p-6 border border-border">
                <h3 className="mb-6">Top Tech Stacks</h3>
                <ResponsiveContainer width="100%" height={400}>
                  <BarChart data={techStackData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" angle={-45} textAnchor="end" height={100} />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="count" fill="#7C3AED" radius={[8, 8, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>

              {/* Popular Themes */}
              <div className="bg-white dark:bg-slate-800 rounded-xl p-6 border border-border">
                <h3 className="mb-6">Popular Themes</h3>
                <ResponsiveContainer width="100%" height={400}>
                  <BarChart data={themeData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" angle={-45} textAnchor="end" height={100} />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="count" fill="#EC4899" radius={[8, 8, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>

              {/* Top Frameworks */}
              <div className="bg-white dark:bg-slate-800 rounded-xl p-6 border border-border">
                <h3 className="mb-6">Top Frameworks</h3>
                <ResponsiveContainer width="100%" height={400}>
                  <BarChart data={frameworkData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" angle={-45} textAnchor="end" height={100} />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="count" fill="#10B981" radius={[8, 8, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>

              {/* Project Type Distribution */}
              <div className="bg-white dark:bg-slate-800 rounded-xl p-6 border border-border">
                <h3 className="mb-6">Project Types</h3>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={projectTypeData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      outerRadius={100}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {projectTypeData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </div>

              {/* Visibility Distribution */}
              <div className="bg-white dark:bg-slate-800 rounded-xl p-6 border border-border">
                <h3 className="mb-6">Visibility Settings</h3>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={visibilityData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      outerRadius={100}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {visibilityData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </div>

              {/* Projects by Year */}
              <div className="bg-white dark:bg-slate-800 rounded-xl p-6 border border-border">
                <h3 className="mb-6">Projects by Year</h3>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={yearData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="year" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="count" fill="#F59E0B" radius={[8, 8, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>

              {/* Top Courses */}
              <div className="bg-white dark:bg-slate-800 rounded-xl p-6 border border-border">
                <h3 className="mb-6">Most Popular Courses</h3>
                <ResponsiveContainer width="100%" height={400}>
                  <BarChart data={coursesData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" angle={-45} textAnchor="end" height={120} />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="count" fill="#3B82F6" radius={[8, 8, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          </TabsContent>

          {/* Projects Tab */}
          <TabsContent value="projects" className="space-y-6">
            <div className="bg-white dark:bg-slate-800 rounded-xl border border-border overflow-hidden">
              <div className="p-6 border-b border-border flex items-center justify-between">
                <h3>All Projects</h3>
                <Button variant="outline" size="sm" className="gap-2">
                  <Download className="w-4 h-4" />
                  Export CSV
                </Button>
              </div>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Project</TableHead>
                      <TableHead>Student</TableHead>
                      <TableHead>Category</TableHead>
                      <TableHead>Level</TableHead>
                      <TableHead>Year</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Views</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {mockProjects.slice(0, 10).map((project) => (
                      <TableRow key={project.id}>
                        <TableCell>
                          <div className="flex items-center gap-3">
                            <ImageWithFallback
                              src={project.thumbnail}
                              alt={project.title}
                              className="w-12 h-12 rounded-lg object-cover"
                            />
                            <div>
                              <p className="line-clamp-1">{project.title}</p>
                              <p className="text-sm text-gray-500 dark:text-gray-400">
                                {project.industry}
                              </p>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>{project.student}</TableCell>
                        <TableCell>
                          <Badge variant="outline">{project.category}</Badge>
                        </TableCell>
                        <TableCell>
                          <Badge
                            className={
                              project.level === 'Beginner'
                                ? 'bg-green-500'
                                : project.level === 'Intermediate'
                                ? 'bg-yellow-500'
                                : 'bg-red-500'
                            }
                          >
                            {project.level}
                          </Badge>
                        </TableCell>
                        <TableCell>{project.year}</TableCell>
                        <TableCell>
                          <Badge
                            className={
                              project.curationStatus === 'Curated'
                                ? 'bg-green-500'
                                : project.curationStatus === 'Public'
                                ? 'bg-blue-500'
                                : project.curationStatus === 'Draft'
                                ? 'bg-yellow-500'
                                : 'bg-gray-500'
                            }
                          >
                            {project.curationStatus}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-1">
                            <Eye className="w-4 h-4 text-gray-400" />
                            <span>{project.views}</span>
                          </div>
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex items-center justify-end gap-2">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => onEditProject?.(project.id)}
                            >
                              <Edit className="w-4 h-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => onDeleteProject?.(project.id)}
                              className="text-red-500 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20"
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
