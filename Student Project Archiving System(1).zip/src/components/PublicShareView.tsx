import { useState } from 'react';
import { Calendar, Lock, ExternalLink, MessageSquare } from 'lucide-react';
import { ProjectCard } from './ProjectCard';
import { ProjectDetailModal } from './ProjectDetailModal';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Toaster } from './ui/sonner';
import { mockProjects, Project } from '../lib/mockData';
import logoImage from 'figma:asset/5a41359254d30e34254c79b43c72d23d4047b129.png';
import { toast } from 'sonner@2.0.3';

interface PublicShareViewProps {
  shareId?: string;
  requirePassword?: boolean;
  theme?: 'light' | 'dark';
  leadCapture?: boolean;
}

export function PublicShareView({
  shareId = 'demo123',
  requirePassword = false,
  theme = 'light',
  leadCapture = false,
}: PublicShareViewProps) {
  const [password, setPassword] = useState('');
  const [isUnlocked, setIsUnlocked] = useState(!requirePassword);
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [hasSubmittedLead, setHasSubmittedLead] = useState(false);
  const [leadEmail, setLeadEmail] = useState('');
  const [leadName, setLeadName] = useState('');
  const [hasSubmittedFeedback, setHasSubmittedFeedback] = useState(false);
  const [feedbackName, setFeedbackName] = useState('');
  const [feedbackEmail, setFeedbackEmail] = useState('');
  const [feedbackMessage, setFeedbackMessage] = useState('');

  // Demo: Show first 6 projects
  const sharedProjects = mockProjects.slice(0, 6);

  const handlePasswordSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Demo: Accept any password
    setIsUnlocked(true);
  };

  const handleLeadSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setHasSubmittedLead(true);
    toast.success('Thank you! We\'ll keep you updated.');
  };

  const handleFeedbackSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setHasSubmittedFeedback(true);
    toast.success('Thank you for your feedback!');
  };

  const handleProjectClick = (project: Project) => {
    setSelectedProject(project);
  };

  const handleNextProject = () => {
    if (!selectedProject) return;
    const currentIndex = sharedProjects.findIndex((p) => p.id === selectedProject.id);
    const nextIndex = (currentIndex + 1) % sharedProjects.length;
    setSelectedProject(sharedProjects[nextIndex]);
  };

  const handlePreviousProject = () => {
    if (!selectedProject) return;
    const currentIndex = sharedProjects.findIndex((p) => p.id === selectedProject.id);
    const prevIndex = (currentIndex - 1 + sharedProjects.length) % sharedProjects.length;
    setSelectedProject(sharedProjects[prevIndex]);
  };

  if (!isUnlocked) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-purple-50 to-pink-50 dark:from-slate-900 dark:to-slate-800 p-4">
        <div className="w-full max-w-md bg-white dark:bg-slate-800 rounded-xl shadow-lg border border-border p-8">
          <div className="flex flex-col items-center mb-8">
            <img src={logoImage} alt="dae" className="w-32 h-auto mb-4" />
            <h2 className="text-center mb-2">Protected Projects</h2>
            <p className="text-center text-gray-600 dark:text-gray-400">
              This collection is password protected
            </p>
          </div>

          <form onSubmit={handlePasswordSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="password">
                <Lock className="w-4 h-4 inline mr-2" />
                Password
              </Label>
              <Input
                id="password"
                type="password"
                placeholder="Enter password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>

            <Button
              type="submit"
              className="w-full bg-gradient-to-r from-[#7C3AED] to-[#EC4899] hover:opacity-90"
            >
              Unlock Projects
            </Button>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className={`min-h-screen ${theme === 'dark' ? 'dark' : ''}`}>
      <div className="min-h-screen bg-white dark:bg-slate-900">
        {/* Header */}
        <header className="sticky top-0 z-40 bg-white dark:bg-slate-800 border-b border-border shadow-sm">
          <div className="container mx-auto px-4 h-[72px] flex items-center justify-between">
            <div className="flex items-center gap-3">
              <img src={logoImage} alt="dae" className="h-10" />
              <div className="hidden md:block ml-2">
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Student Project Archive
                </p>
              </div>
            </div>

            <div className="flex items-center gap-3 text-sm text-gray-600 dark:text-gray-400">
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4" />
                Expires: Nov 15, 2024
              </div>
            </div>
          </div>
        </header>

        <div className="container mx-auto px-4 py-8">
          {/* Want Updates Section */}
          {leadCapture && !hasSubmittedLead && (
            <div className="mb-8 bg-white dark:bg-slate-800 rounded-xl p-8 border border-border shadow-sm">
              <div className="max-w-2xl mx-auto text-center">
                <h3 className="mb-2">Want updates on these projects?</h3>
                <p className="text-gray-600 dark:text-gray-400 mb-6">
                  Leave your email to stay informed about new student work and updates.
                </p>
                <form onSubmit={handleLeadSubmit} className="flex flex-col sm:flex-row gap-3">
                  <Input
                    type="text"
                    placeholder="Your name"
                    value={leadName}
                    onChange={(e) => setLeadName(e.target.value)}
                    required
                    className="flex-1"
                  />
                  <Input
                    type="email"
                    placeholder="Your email"
                    value={leadEmail}
                    onChange={(e) => setLeadEmail(e.target.value)}
                    required
                    className="flex-1"
                  />
                  <Button
                    type="submit"
                    className="bg-gradient-to-r from-[#7C3AED] to-[#EC4899] hover:opacity-90 sm:w-auto w-full"
                  >
                    Subscribe
                  </Button>
                </form>
              </div>
            </div>
          )}

          {hasSubmittedLead && (
            <div className="mb-8 bg-green-50 dark:bg-green-900/20 rounded-xl p-4 border border-green-200 dark:border-green-800 text-center">
              <p className="text-green-800 dark:text-green-200">
                ✓ Thank you! We'll keep you updated.
              </p>
            </div>
          )}

          {/* Info Banner */}
          <div className="mb-8 bg-gradient-to-r from-purple-50 to-pink-50 dark:from-purple-900/20 dark:to-pink-900/20 rounded-xl p-6 border border-purple-200 dark:border-purple-800">
            <div className="flex flex-col gap-2">
              <h1 className="mb-2">Shared Project Collection</h1>
              <p className="text-gray-600 dark:text-gray-400">
                Viewing {sharedProjects.length} curated student projects
              </p>
            </div>
          </div>

          {/* Projects Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {sharedProjects.map((project) => (
              <ProjectCard
                key={project.id}
                project={project}
                onClick={() => handleProjectClick(project)}
                hideStudentInfo={true}
              />
            ))}
          </div>

          {/* Feedback Form */}
          <div className="mt-12 mb-12 bg-gradient-to-r from-purple-50 to-pink-50 dark:from-purple-900/20 dark:to-pink-900/20 rounded-xl p-8 border border-purple-200 dark:border-purple-800">
            <div className="max-w-2xl mx-auto">
              <div className="text-center mb-6">
                <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-gradient-to-r from-[#7C3AED] to-[#EC4899] text-white mb-4">
                  <MessageSquare className="w-6 h-6" />
                </div>
                <h3 className="mb-2">Share Your Feedback</h3>
                <p className="text-gray-600 dark:text-gray-400">
                  Have feedback on these projects or the students? We'd love to hear from you!
                </p>
              </div>

              {!hasSubmittedFeedback ? (
                <form onSubmit={handleFeedbackSubmit} className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="feedback-name">Your Name</Label>
                      <Input
                        id="feedback-name"
                        type="text"
                        placeholder="John Doe"
                        value={feedbackName}
                        onChange={(e) => setFeedbackName(e.target.value)}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="feedback-email">Your Email</Label>
                      <Input
                        id="feedback-email"
                        type="email"
                        placeholder="john@example.com"
                        value={feedbackEmail}
                        onChange={(e) => setFeedbackEmail(e.target.value)}
                        required
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="feedback-message">Your Feedback</Label>
                    <Textarea
                      id="feedback-message"
                      placeholder="Share your thoughts on the projects, students' work, or any suggestions..."
                      value={feedbackMessage}
                      onChange={(e) => setFeedbackMessage(e.target.value)}
                      required
                      rows={5}
                    />
                  </div>
                  <Button
                    type="submit"
                    className="w-full bg-gradient-to-r from-[#7C3AED] to-[#EC4899] hover:opacity-90"
                  >
                    Submit Feedback
                  </Button>
                </form>
              ) : (
                <div className="bg-green-50 dark:bg-green-900/20 rounded-lg p-6 border border-green-200 dark:border-green-800 text-center">
                  <p className="text-green-800 dark:text-green-200">
                    ✓ Thank you for your feedback! We appreciate your input.
                  </p>
                </div>
              )}
            </div>
          </div>

          {/* Footer */}
          <div className="mt-12 pt-8 border-t border-border text-center">
            <div className="flex flex-col items-center gap-4">
              <img src={logoImage} alt="dae" className="h-12 opacity-60" />
              <p className="text-gray-600 dark:text-gray-400">
                Powered by dae Student Project Archive
              </p>
              <Button
                variant="outline"
                className="gap-2"
                onClick={() => window.open('https://mydae.org', '_blank')}
              >
                <ExternalLink className="w-4 h-4" />
                Learn More About dae
              </Button>
            </div>
          </div>
        </div>

        {selectedProject && (
          <ProjectDetailModal
            project={selectedProject}
            onClose={() => setSelectedProject(null)}
            onNext={handleNextProject}
            onPrevious={handlePreviousProject}
            hideStudentInfo={true}
          />
        )}

        <Toaster position="top-right" />
      </div>
    </div>
  );
}
