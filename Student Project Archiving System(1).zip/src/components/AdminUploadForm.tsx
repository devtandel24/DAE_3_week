import { useState, useEffect } from 'react';
import { Upload, X } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { RadioGroup, RadioGroupItem } from './ui/radio-group';
import { Checkbox } from './ui/checkbox';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from './ui/select';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import {
  mockProjects,
  mockStudents,
  FIXED_TRACKS,
  FIXED_LOCATIONS,
  FIXED_PROGRAM_TYPES,
} from '../lib/mockData';
import { toast } from 'sonner@2.0.3';

interface AdminUploadFormProps {
  onCancel: () => void;
  onSave: () => void;
  editingProjectId?: string | null;
}

export function AdminUploadForm({ onCancel, onSave, editingProjectId }: AdminUploadFormProps) {
  // Generate dynamic options from existing project data
  const allIndustries = Array.from(new Set(mockProjects.map(p => p.industry))).sort();
  const allCourses = Array.from(new Set(mockProjects.flatMap(p => p.courses))).sort();
  const allThemes = Array.from(new Set(mockProjects.flatMap(p => p.theme))).sort();
  const allTracks = [...FIXED_TRACKS];
  const allLocations = [...FIXED_LOCATIONS];
  const allProgramTypes = [...FIXED_PROGRAM_TYPES];

  // UNIFIED TAG SYSTEM - All available tags categorized
  const allAvailableTags = {
    'Industries': allIndustries,
    'Courses': allCourses,
    'Themes & Topics': allThemes,
    'Tracks': allTracks,
    'Categories': ['WEB DEV', 'CYBERSECURITY', 'GAME DEV', 'IoT', 'AI & DATA SCIENCE'],
    'Tech Stack': Array.from(new Set(mockProjects.flatMap(p => p.techStack))).sort().slice(0, 20),
    'Frameworks': Array.from(new Set(mockProjects.flatMap(p => p.frameworks))).sort().slice(0, 20),
  };

  // Basic Information
  const [selectedStudent, setSelectedStudent] = useState('');
  const [cohort, setCohort] = useState('');
  const [bio, setBio] = useState('');
  const [projectTitle, setProjectTitle] = useState('');
  const [description, setDescription] = useState('');
  const [about, setAbout] = useState('');
  const [goals, setGoals] = useState('');
  const [challenges, setChallenges] = useState('');
  const [outcomes, setOutcomes] = useState('');
  const [previewUrl, setPreviewUrl] = useState('');
  const [githubUrl, setGithubUrl] = useState('');
  const [videoUrl, setVideoUrl] = useState('');
  const [presentationUrl, setPresentationUrl] = useState('');
  const [uploadedImages, setUploadedImages] = useState<string[]>([]);
  const [category, setCategory] = useState<'WEB DEV' | 'CYBERSECURITY' | 'GAME DEV' | 'IoT' | 'AI & DATA SCIENCE'>('WEB DEV');

  // Tech Stack
  const [selectedTechStack, setSelectedTechStack] = useState<string[]>([]);
  const [selectedFrameworks, setSelectedFrameworks] = useState<string[]>([]);
  const [customTech, setCustomTech] = useState('');
  const [customFramework, setCustomFramework] = useState('');

  // New Departmental Fields
  const [industry, setIndustry] = useState('');
  const [selectedCourses, setSelectedCourses] = useState<string[]>([]);
  const [level, setLevel] = useState<'Beginner' | 'Intermediate' | 'Advanced'>('Intermediate');
  const [location, setLocation] = useState<'New Haven' | 'Stamford'>('New Haven');
  const [programType, setProgramType] = useState<'High School' | 'Adult'>('Adult');
  const [track, setTrack] = useState('');
  const [selectedThemes, setSelectedThemes] = useState<string[]>([]);
  const [semester, setSemester] = useState<'Spring' | 'Summer' | 'Fall' | 'Winter'>('Fall');
  const [year, setYear] = useState(2024);
  const [curationStatus, setCurationStatus] = useState<'Draft' | 'Curated' | 'Public' | 'Private'>('Draft');
  const [visibility, setVisibility] = useState<'Public' | 'Private' | 'Partner'>('Public');
  const [projectType, setProjectType] = useState<'Individual' | 'Team' | 'Capstone'>('Individual');
  
  // Unified Tag System - combines all categorization
  const [selectedUnifiedTags, setSelectedUnifiedTags] = useState<string[]>([]);
  const [searchTagQuery, setSearchTagQuery] = useState('');

  // Filter tags based on search - MUST be after searchTagQuery declaration
  const filteredTagCategories = Object.entries(allAvailableTags).map(([category, tags]) => ({
    category,
    tags: tags.filter(tag => 
      tag.toLowerCase().includes(searchTagQuery.toLowerCase())
    )
  })).filter(cat => cat.tags.length > 0);

  // Demographics (Admin only - for funder reporting)
  const [isFirstGeneration, setIsFirstGeneration] = useState(false);
  const [isWomenInSTEM, setIsWomenInSTEM] = useState(false);
  const [isUnderrepresented, setIsUnderrepresented] = useState(false);

  // Common tech stacks and frameworks for quick selection
  const commonTechStack = [
    'React', 'TypeScript', 'JavaScript', 'Python', 'Node.js', 'Java', 'C#', 'C++',
    'PostgreSQL', 'MongoDB', 'MySQL', 'Docker', 'AWS', 'Firebase', 'Unity',
    'TensorFlow', 'Solidity', 'Ethereum', 'Arduino', 'Raspberry Pi',
    'Vue.js', 'Angular', 'Flask', 'Django', 'Express'
  ];

  const commonFrameworks = [
    'Next.js', 'React Native', 'Express', 'FastAPI', 'Django', 'Flask',
    'Tailwind CSS', 'Material UI', 'Bootstrap', 'Prisma', 'Pandas',
    'NumPy', 'Scikit-learn', 'TensorFlow.js', 'Socket.io', 'WebRTC',
    'Unity ML-Agents', 'Photon', 'Mirror Networking', 'Hardhat', 'Truffle'
  ];

  useEffect(() => {
    if (editingProjectId) {
      const project = mockProjects.find((p) => p.id === editingProjectId);
      if (project) {
        setSelectedStudent(project.student);
        setCohort(project.cohort);
        setBio(project.studentBio);
        setProjectTitle(project.title);
        setDescription(project.description);
        setAbout(project.about);
        setGoals(project.goals);
        setChallenges(project.challenges);
        setOutcomes(project.outcomes);
        setPreviewUrl(project.previewUrl);
        setGithubUrl(project.githubUrl);
        setVideoUrl(project.videoUrl || '');
        setPresentationUrl(project.presentationUrl || '');
        setSelectedTechStack(project.techStack);
        setSelectedFrameworks(project.frameworks);
        setCategory(project.category);
        setUploadedImages([project.thumbnail, ...project.screenshots]);
        // New fields
        setIndustry(project.industry);
        setSelectedCourses(project.courses);
        setLevel(project.level);
        setTrack(project.track);
        setSelectedThemes(project.theme);
        setSemester(project.semester);
        setYear(project.year);
        setCurationStatus(project.curationStatus);
        setVisibility(project.visibility);
        setProjectType(project.projectType);
        setLocation(project.location);
        setProgramType(project.programType);
        
        // Load demographics
        setIsFirstGeneration(project.isFirstGeneration || false);
        setIsWomenInSTEM(project.isWomenInSTEM || false);
        setIsUnderrepresented(project.isUnderrepresented || false);
        
        // Load unified tags from project data
        const projectTags = [
          project.industry,
          project.track,
          project.category,
          ...project.courses,
          ...project.theme,
          ...project.techStack.slice(0, 5),
          ...project.frameworks.slice(0, 5)
        ].filter(Boolean);
        setSelectedUnifiedTags(projectTags);
      }
    }
  }, [editingProjectId]);

  // Sync unified tags when individual fields change
  useEffect(() => {
    const autoTags = [
      industry,
      track,
      category,
      ...selectedCourses,
      ...selectedThemes,
      ...selectedTechStack,
      ...selectedFrameworks
    ].filter(Boolean);
    
    // Merge auto tags with manually selected tags (don't override manual selections)
    setSelectedUnifiedTags(prev => {
      const combined = Array.from(new Set([...prev, ...autoTags]));
      return combined;
    });
  }, [industry, track, category, selectedCourses, selectedThemes, selectedTechStack, selectedFrameworks]);

  const handleStudentChange = (studentName: string) => {
    setSelectedStudent(studentName);
    const student = mockStudents.find((s) => s.name === studentName);
    if (student) {
      setCohort(student.cohort);
      setBio(student.bio);
    }
  };

  const toggleTechStack = (tech: string) => {
    setSelectedTechStack((prev) =>
      prev.includes(tech) ? prev.filter((t) => t !== tech) : [...prev, tech]
    );
  };

  const toggleFramework = (framework: string) => {
    setSelectedFrameworks((prev) =>
      prev.includes(framework) ? prev.filter((f) => f !== framework) : [...prev, framework]
    );
  };

  const toggleTheme = (theme: string) => {
    setSelectedThemes((prev) =>
      prev.includes(theme) ? prev.filter((t) => t !== theme) : [...prev, theme]
    );
  };

  const toggleCourse = (course: string) => {
    setSelectedCourses((prev) =>
      prev.includes(course) ? prev.filter((c) => c !== course) : [...prev, course]
    );
  };

  const toggleUnifiedTag = (tag: string) => {
    setSelectedUnifiedTags((prev) =>
      prev.includes(tag) ? prev.filter((t) => t !== tag) : [...prev, tag]
    );
  };

  const addCustomTech = () => {
    if (customTech.trim() && !selectedTechStack.includes(customTech.trim())) {
      setSelectedTechStack([...selectedTechStack, customTech.trim()]);
      setCustomTech('');
    }
  };

  const addCustomFramework = () => {
    if (customFramework.trim() && !selectedFrameworks.includes(customFramework.trim())) {
      setSelectedFrameworks([...selectedFrameworks, customFramework.trim()]);
      setCustomFramework('');
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const files = Array.from(e.dataTransfer.files);
    const imageUrls = files.map((file) => URL.createObjectURL(file));
    setUploadedImages((prev) => [...prev, ...imageUrls]);
  };

  const handleSubmit = () => {
    // Process unified tags and distribute them to appropriate fields
    const courses: string[] = [];
    const themes: string[] = [];
    const techStack: string[] = [];
    const frameworks: string[] = [];
    let detectedIndustry = industry;
    let detectedTrack = track;
    
    selectedUnifiedTags.forEach(tag => {
      // Categorize each tag
      if (allIndustries.includes(tag)) {
        detectedIndustry = tag;
      } else if (allCourses.includes(tag)) {
        courses.push(tag);
      } else if (allThemes.includes(tag)) {
        themes.push(tag);
      } else if (allTracks.includes(tag)) {
        detectedTrack = tag;
      } else if (allAvailableTags['Tech Stack'].includes(tag)) {
        techStack.push(tag);
      } else if (allAvailableTags['Frameworks'].includes(tag)) {
        frameworks.push(tag);
      }
    });
    
    // Merge with existing selections
    const finalCourses = Array.from(new Set([...selectedCourses, ...courses]));
    const finalThemes = Array.from(new Set([...selectedThemes, ...themes]));
    const finalTechStack = Array.from(new Set([...selectedTechStack, ...techStack]));
    const finalFrameworks = Array.from(new Set([...selectedFrameworks, ...frameworks]));
    
    // Update state with processed data
    setSelectedCourses(finalCourses);
    setSelectedThemes(finalThemes);
    setSelectedTechStack(finalTechStack);
    setSelectedFrameworks(finalFrameworks);
    if (detectedIndustry) setIndustry(detectedIndustry);
    if (detectedTrack) setTrack(detectedTrack);
    
    // Show toast with summary
    toast.success(`Project ${editingProjectId ? 'updated' : 'created'} with ${selectedUnifiedTags.length} tags applied!`);
    
    // Validation would go here
    onSave();
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-slate-900">
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-5xl mx-auto">
          <div className="flex items-center justify-between mb-8">
            <h1>{editingProjectId ? 'Edit Project' : 'Upload New Project'}</h1>
            <Button variant="ghost" onClick={onCancel}>
              <X className="w-5 h-5" />
            </Button>
          </div>

          <Tabs defaultValue="basic" className="space-y-6">
            <TabsList className="grid w-full grid-cols-5">
              <TabsTrigger value="basic">Basic Info</TabsTrigger>
              <TabsTrigger value="classification">Classification</TabsTrigger>
              <TabsTrigger value="technical">Technical</TabsTrigger>
              <TabsTrigger value="media">Media</TabsTrigger>
              <TabsTrigger value="settings">Settings</TabsTrigger>
            </TabsList>

            {/* Basic Information Tab */}
            <TabsContent value="basic" className="space-y-6">
              <div className="bg-white dark:bg-slate-800 rounded-xl p-8 border border-border space-y-6">
                <h3>Student Information</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <Label htmlFor="student">Student Name *</Label>
                    <Select value={selectedStudent} onValueChange={handleStudentChange}>
                      <SelectTrigger id="student">
                        <SelectValue placeholder="Select a student" />
                      </SelectTrigger>
                      <SelectContent>
                        {mockStudents.map((student) => (
                          <SelectItem key={student.name} value={student.name}>
                            {student.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="cohort">Cohort</Label>
                    <Input
                      id="cohort"
                      value={cohort}
                      onChange={(e) => setCohort(e.target.value)}
                      placeholder="e.g., Cohort 2024-A"
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="bio">Student Bio</Label>
                  <Textarea
                    id="bio"
                    value={bio}
                    onChange={(e) => setBio(e.target.value)}
                    placeholder="Brief bio about the student..."
                    rows={3}
                  />
                </div>

                {/* Demographics Section */}
                <div className="space-y-3">
                  <Label>Demographics (Admin only)</Label>
                  <div className="space-y-3 p-4 bg-muted/30 rounded-lg border border-border">
                    <div className="flex items-center space-x-3">
                      <Checkbox
                        id="firstGen"
                        checked={isFirstGeneration}
                        onCheckedChange={(checked) => setIsFirstGeneration(checked === true)}
                      />
                      <label htmlFor="firstGen" className="cursor-pointer select-none flex-1">
                        First-generation
                      </label>
                    </div>
                    <div className="flex items-center space-x-3">
                      <Checkbox
                        id="womenSTEM"
                        checked={isWomenInSTEM}
                        onCheckedChange={(checked) => setIsWomenInSTEM(checked === true)}
                      />
                      <label htmlFor="womenSTEM" className="cursor-pointer select-none flex-1">
                        Women in STEM
                      </label>
                    </div>
                    <div className="flex items-center space-x-3">
                      <Checkbox
                        id="underrep"
                        checked={isUnderrepresented}
                        onCheckedChange={(checked) => setIsUnderrepresented(checked === true)}
                      />
                      <label htmlFor="underrep" className="cursor-pointer select-none flex-1">
                        Underrepresented groups
                      </label>
                    </div>
                    <p className="text-xs text-muted-foreground italic mt-3">
                      For funder reporting only
                    </p>
                  </div>
                </div>

                <Separator />

                <h3>Project Information</h3>

                <div>
                  <Label htmlFor="title">Project Title *</Label>
                  <Input
                    id="title"
                    value={projectTitle}
                    onChange={(e) => setProjectTitle(e.target.value)}
                    placeholder="Enter project title..."
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="description">Short Description *</Label>
                  <Textarea
                    id="description"
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Brief description for project cards..."
                    rows={3}
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="about">About the Project</Label>
                  <Textarea
                    id="about"
                    value={about}
                    onChange={(e) => setAbout(e.target.value)}
                    placeholder="Detailed description of the project..."
                    rows={5}
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <Label htmlFor="goals">Goals & Objectives</Label>
                    <Textarea
                      id="goals"
                      value={goals}
                      onChange={(e) => setGoals(e.target.value)}
                      placeholder="What were the project goals?"
                      rows={4}
                    />
                  </div>

                  <div>
                    <Label htmlFor="challenges">Challenges Faced</Label>
                    <Textarea
                      id="challenges"
                      value={challenges}
                      onChange={(e) => setChallenges(e.target.value)}
                      placeholder="What challenges were overcome?"
                      rows={4}
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="outcomes">Outcomes & Results</Label>
                  <Textarea
                    id="outcomes"
                    value={outcomes}
                    onChange={(e) => setOutcomes(e.target.value)}
                    placeholder="What were the final outcomes and achievements?"
                    rows={4}
                  />
                </div>
              </div>
            </TabsContent>

            {/* Classification Tab */}
            <TabsContent value="classification" className="space-y-6">
              <div className="bg-white dark:bg-slate-800 rounded-xl p-8 border border-border space-y-6">
                <h3>Project Classification</h3>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <Label htmlFor="category">Category *</Label>
                    <Select value={category} onValueChange={(value: any) => setCategory(value)}>
                      <SelectTrigger id="category">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="WEB DEV">WEB DEV</SelectItem>
                        <SelectItem value="CYBERSECURITY">CYBERSECURITY</SelectItem>
                        <SelectItem value="GAME DEV">GAME DEV</SelectItem>
                        <SelectItem value="IoT">IoT</SelectItem>
                        <SelectItem value="AI & DATA SCIENCE">AI & DATA SCIENCE</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="industry">Industry *</Label>
                    <Select value={industry} onValueChange={setIndustry}>
                      <SelectTrigger id="industry">
                        <SelectValue placeholder="Select industry" />
                      </SelectTrigger>
                      <SelectContent>
                        {allIndustries.map((ind) => (
                          <SelectItem key={ind} value={ind}>
                            {ind}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="location">Location *</Label>
                    <Select value={location} onValueChange={(value: any) => setLocation(value)}>
                      <SelectTrigger id="location">
                        <SelectValue placeholder="Select location" />
                      </SelectTrigger>
                      <SelectContent>
                        {allLocations.map((loc) => (
                          <SelectItem key={loc} value={loc}>
                            {loc}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="programType">Program Type *</Label>
                    <Select value={programType} onValueChange={(value: any) => setProgramType(value)}>
                      <SelectTrigger id="programType">
                        <SelectValue placeholder="Select program type" />
                      </SelectTrigger>
                      <SelectContent>
                        {allProgramTypes.map((type) => (
                          <SelectItem key={type} value={type}>
                            {type}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div>
                  <Label className="mb-3">Project Tags * (Industries, Courses, Themes, Categories, Tech)</Label>
                  <p className="text-sm text-gray-500 dark:text-gray-400 mb-3">
                    Select all relevant tags. These will be used for filtering and categorization.
                  </p>
                  
                  {/* Search Tags */}
                  <Input
                    placeholder="Search tags... (e.g., Healthcare, Python, AI, etc.)"
                    value={searchTagQuery}
                    onChange={(e) => setSearchTagQuery(e.target.value)}
                    className="mb-4"
                  />

                  {/* Selected Tags Display */}
                  {selectedUnifiedTags.length > 0 && (
                    <div className="mb-4 p-4 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
                      <p className="text-sm mb-2">Selected Tags ({selectedUnifiedTags.length}):</p>
                      <div className="flex flex-wrap gap-2">
                        {selectedUnifiedTags.map((tag) => (
                          <Badge key={tag} variant="secondary" className="gap-1">
                            {tag}
                            <button onClick={() => toggleUnifiedTag(tag)}>
                              <X className="w-3 h-3" />
                            </button>
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Tag Categories */}
                  <div className="border rounded-lg p-4 max-h-96 overflow-y-auto space-y-6">
                    {filteredTagCategories.map(({ category, tags }) => (
                      <div key={category}>
                        <h4 className="text-sm uppercase tracking-wide text-purple-600 dark:text-purple-400 mb-2">
                          {category}
                        </h4>
                        <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                          {tags.map((tag) => (
                            <div key={tag} className="flex items-center space-x-2">
                              <Checkbox
                                id={`tag-${tag}`}
                                checked={selectedUnifiedTags.includes(tag)}
                                onCheckedChange={() => toggleUnifiedTag(tag)}
                              />
                              <label htmlFor={`tag-${tag}`} className="text-sm cursor-pointer flex-1">
                                {tag}
                              </label>
                            </div>
                          ))}
                        </div>
                      </div>
                    ))}
                    {filteredTagCategories.length === 0 && (
                      <p className="text-center text-gray-500 py-4">No tags found matching "{searchTagQuery}"</p>
                    )}
                  </div>
                </div>

                <Separator />

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">

                  <div>
                    <Label htmlFor="track">Track *</Label>
                    <Select value={track} onValueChange={setTrack}>
                      <SelectTrigger id="track">
                        <SelectValue placeholder="Select track" />
                      </SelectTrigger>
                      <SelectContent>
                        {allTracks.map((t) => (
                          <SelectItem key={t} value={t}>
                            {t}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="level">Difficulty Level *</Label>
                    <Select value={level} onValueChange={(value: any) => setLevel(value)}>
                      <SelectTrigger id="level">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Beginner">Beginner</SelectItem>
                        <SelectItem value="Intermediate">Intermediate</SelectItem>
                        <SelectItem value="Advanced">Advanced</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="projectType">Project Type *</Label>
                    <Select value={projectType} onValueChange={(value: any) => setProjectType(value)}>
                      <SelectTrigger id="projectType">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Individual">Individual</SelectItem>
                        <SelectItem value="Team">Team</SelectItem>
                        <SelectItem value="Capstone">Capstone</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="semester">Semester *</Label>
                    <Select value={semester} onValueChange={(value: any) => setSemester(value)}>
                      <SelectTrigger id="semester">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Spring">Spring</SelectItem>
                        <SelectItem value="Summer">Summer</SelectItem>
                        <SelectItem value="Fall">Fall</SelectItem>
                        <SelectItem value="Winter">Winter</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="year">Year *</Label>
                    <Input
                      id="year"
                      type="number"
                      value={year}
                      onChange={(e) => setYear(parseInt(e.target.value))}
                      min="2020"
                      max="2030"
                    />
                  </div>
                </div>

                <div>
                  <Label className="mb-3">Themes & Topics (Select all that apply)</Label>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                    {allThemes.map((theme) => (
                      <div key={theme} className="flex items-center space-x-2">
                        <Checkbox
                          id={`theme-${theme}`}
                          checked={selectedThemes.includes(theme)}
                          onCheckedChange={() => toggleTheme(theme)}
                        />
                        <label htmlFor={`theme-${theme}`} className="text-sm cursor-pointer">
                          {theme}
                        </label>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </TabsContent>

            {/* Technical Details Tab */}
            <TabsContent value="technical" className="space-y-6">
              <div className="bg-white dark:bg-slate-800 rounded-xl p-8 border border-border space-y-6">
                <h3>Technical Stack</h3>

                <div>
                  <Label className="mb-3">Tech Stack</Label>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mb-4">
                    {commonTechStack.map((tech) => (
                      <Button
                        key={tech}
                        type="button"
                        variant={selectedTechStack.includes(tech) ? 'default' : 'outline'}
                        size="sm"
                        onClick={() => toggleTechStack(tech)}
                        className={selectedTechStack.includes(tech) ? 'bg-gradient-to-r from-[#7C3AED] to-[#EC4899]' : ''}
                      >
                        {tech}
                      </Button>
                    ))}
                  </div>
                  
                  <div className="flex gap-2">
                    <Input
                      placeholder="Add custom technology..."
                      value={customTech}
                      onChange={(e) => setCustomTech(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addCustomTech())}
                    />
                    <Button type="button" onClick={addCustomTech}>Add</Button>
                  </div>

                  {selectedTechStack.length > 0 && (
                    <div className="flex flex-wrap gap-2 mt-4">
                      {selectedTechStack.map((tech) => (
                        <Badge key={tech} variant="secondary" className="gap-1">
                          {tech}
                          <button onClick={() => toggleTechStack(tech)}>
                            <X className="w-3 h-3" />
                          </button>
                        </Badge>
                      ))}
                    </div>
                  )}
                </div>

                <Separator />

                <div>
                  <Label className="mb-3">Frameworks & Libraries</Label>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mb-4">
                    {commonFrameworks.map((framework) => (
                      <Button
                        key={framework}
                        type="button"
                        variant={selectedFrameworks.includes(framework) ? 'default' : 'outline'}
                        size="sm"
                        onClick={() => toggleFramework(framework)}
                        className={selectedFrameworks.includes(framework) ? 'bg-gradient-to-r from-[#7C3AED] to-[#EC4899]' : ''}
                      >
                        {framework}
                      </Button>
                    ))}
                  </div>

                  <div className="flex gap-2">
                    <Input
                      placeholder="Add custom framework..."
                      value={customFramework}
                      onChange={(e) => setCustomFramework(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addCustomFramework())}
                    />
                    <Button type="button" onClick={addCustomFramework}>Add</Button>
                  </div>

                  {selectedFrameworks.length > 0 && (
                    <div className="flex flex-wrap gap-2 mt-4">
                      {selectedFrameworks.map((framework) => (
                        <Badge key={framework} variant="secondary" className="gap-1">
                          {framework}
                          <button onClick={() => toggleFramework(framework)}>
                            <X className="w-3 h-3" />
                          </button>
                        </Badge>
                      ))}
                    </div>
                  )}
                </div>

                <Separator />

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <Label htmlFor="previewUrl">Demo URL</Label>
                    <Input
                      id="previewUrl"
                      type="url"
                      value={previewUrl}
                      onChange={(e) => setPreviewUrl(e.target.value)}
                      placeholder="https://example.com/demo"
                    />
                  </div>

                  <div>
                    <Label htmlFor="githubUrl">GitHub Repository</Label>
                    <Input
                      id="githubUrl"
                      type="url"
                      value={githubUrl}
                      onChange={(e) => setGithubUrl(e.target.value)}
                      placeholder="https://github.com/username/repo"
                    />
                  </div>
                </div>
              </div>
            </TabsContent>

            {/* Media Tab */}
            <TabsContent value="media" className="space-y-6">
              <div className="bg-white dark:bg-slate-800 rounded-xl p-8 border border-border space-y-6">
                <h3>Media & Resources</h3>

                <div>
                  <Label htmlFor="videoUrl">Video URL (Optional)</Label>
                  <Input
                    id="videoUrl"
                    type="url"
                    value={videoUrl}
                    onChange={(e) => setVideoUrl(e.target.value)}
                    placeholder="https://youtube.com/watch?v=..."
                  />
                </div>

                <div>
                  <Label htmlFor="presentationUrl">Presentation/Slides URL (Optional)</Label>
                  <Input
                    id="presentationUrl"
                    type="url"
                    value={presentationUrl}
                    onChange={(e) => setPresentationUrl(e.target.value)}
                    placeholder="https://example.com/presentation.pdf"
                  />
                </div>

                <Separator />

                <div>
                  <Label className="mb-3">Project Images</Label>
                  <div
                    onDrop={handleDrop}
                    onDragOver={(e) => e.preventDefault()}
                    className="border-2 border-dashed border-border rounded-lg p-12 text-center hover:border-purple-500 transition-colors cursor-pointer"
                  >
                    <Upload className="w-12 h-12 mx-auto mb-4 text-gray-400" />
                    <p className="text-gray-600 dark:text-gray-400 mb-2">
                      Drag and drop images here, or click to browse
                    </p>
                    <p className="text-sm text-gray-500 dark:text-gray-500">
                      Supports: JPG, PNG, GIF (Max 5MB)
                    </p>
                  </div>

                  {uploadedImages.length > 0 && (
                    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 mt-6">
                      {uploadedImages.map((image, index) => (
                        <div key={index} className="relative group">
                          <img
                            src={image}
                            alt={`Upload ${index + 1}`}
                            className="w-full h-32 object-cover rounded-lg"
                          />
                          <button
                            onClick={() =>
                              setUploadedImages((prev) => prev.filter((_, i) => i !== index))
                            }
                            className="absolute top-2 right-2 p-1 bg-red-500 text-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                          >
                            <X className="w-4 h-4" />
                          </button>
                          {index === 0 && (
                            <Badge className="absolute bottom-2 left-2 bg-purple-500">
                              Thumbnail
                            </Badge>
                          )}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </TabsContent>

            {/* Settings Tab */}
            <TabsContent value="settings" className="space-y-6">
              <div className="bg-white dark:bg-slate-800 rounded-xl p-8 border border-border space-y-6">
                <h3>Publication Settings</h3>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div>
                    <Label htmlFor="curationStatus">Curation Status</Label>
                    <Select value={curationStatus} onValueChange={(value: any) => setCurationStatus(value)}>
                      <SelectTrigger id="curationStatus">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Draft">Draft</SelectItem>
                        <SelectItem value="Curated">Curated</SelectItem>
                        <SelectItem value="Public">Public</SelectItem>
                        <SelectItem value="Private">Private</SelectItem>
                      </SelectContent>
                    </Select>
                    <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                      Draft: Work in progress<br/>
                      Curated: Approved for showcase<br/>
                      Public: Visible to everyone<br/>
                      Private: Internal only
                    </p>
                  </div>

                  <div>
                    <Label htmlFor="visibility">Visibility</Label>
                    <RadioGroup value={visibility} onValueChange={(value: any) => setVisibility(value)}>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="Public" id="vis-public" />
                        <Label htmlFor="vis-public" className="cursor-pointer">Public</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="Partner" id="vis-partner" />
                        <Label htmlFor="vis-partner" className="cursor-pointer">Partner Only</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="Private" id="vis-private" />
                        <Label htmlFor="vis-private" className="cursor-pointer">Private</Label>
                      </div>
                    </RadioGroup>
                  </div>

                  <div>
                    <Label>Project Status</Label>
                    <div className="space-y-3 mt-2">
                      <Badge className={`${
                        curationStatus === 'Curated' 
                          ? 'bg-green-500' 
                          : curationStatus === 'Public' 
                          ? 'bg-blue-500' 
                          : curationStatus === 'Draft'
                          ? 'bg-yellow-500'
                          : 'bg-gray-500'
                      }`}>
                        {curationStatus}
                      </Badge>
                      <Badge variant="outline">{visibility}</Badge>
                      <Badge variant="outline">{projectType}</Badge>
                    </div>
                  </div>
                </div>

                <Separator />

                <div className="bg-purple-50 dark:bg-purple-900/20 rounded-lg p-4">
                  <p className="text-sm">
                    <strong>Note:</strong> Projects marked as "Curated" will be featured in public galleries and share links. 
                    "Private" projects are only visible to authenticated admin users.
                  </p>
                </div>
              </div>
            </TabsContent>
          </Tabs>

          {/* Action Buttons */}
          <div className="flex justify-end gap-4 mt-8">
            <Button variant="outline" onClick={onCancel} size="lg">
              Cancel
            </Button>
            <Button
              onClick={handleSubmit}
              size="lg"
              className="bg-gradient-to-r from-[#7C3AED] to-[#EC4899] hover:opacity-90"
            >
              {editingProjectId ? 'Update Project' : 'Publish Project'}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
