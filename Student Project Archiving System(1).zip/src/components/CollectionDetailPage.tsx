import { useState } from 'react';
import { ArrowLeft, Trash2, AlertCircle, FolderOpen } from 'lucide-react';
import { useCollectionsStore } from '../lib/collectionsStore';
import { mockProjects, Project } from '../lib/mockData';
import { ProjectCard } from './ProjectCard';
import { ProjectDetailModal } from './ProjectDetailModal';
import { Button } from './ui/button';
import { EmptyState } from './EmptyState';
import { toast } from 'sonner@2.0.3';

interface CollectionDetailPageProps {
  collectionId: string;
  onBack: () => void;
  onBackToGallery: () => void;
}

export function CollectionDetailPage({
  collectionId,
  onBack,
  onBackToGallery,
}: CollectionDetailPageProps) {
  const { collections, removeFromCollection } = useCollectionsStore();
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  
  const collection = collections[collectionId];

  if (!collection) {
    return (
      <div className="min-h-screen bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <EmptyState
            icon={AlertCircle}
            title="Collection not found"
            description="This collection may have been deleted."
            actionLabel="Back to Collections"
            onAction={onBack}
          />
        </div>
      </div>
    );
  }

  const projects = collection.projectIds
    .map((id) => mockProjects.find((p) => p.id === id))
    .filter((p): p is Project => p !== undefined);

  const handleRemoveFromCollection = (projectId: string) => {
    removeFromCollection(projectId, collectionId);
    toast.success('Removed from collection');
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8 space-y-4">
          <Button
            variant="ghost"
            onClick={onBack}
            className="mb-4"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Collections
          </Button>
          
          <div>
            <h1>{collection.name}</h1>
            <p className="text-muted-foreground">
              {projects.length} project{projects.length !== 1 ? 's' : ''}
            </p>
          </div>
        </div>

        {/* Projects Grid */}
        {projects.length === 0 ? (
          <EmptyState
            icon={FolderOpen}
            title="No projects in this collection"
            description="Browse the gallery and add projects to this collection."
            actionLabel="Browse Projects"
            onAction={onBackToGallery}
          />
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {projects.map((project) => (
              <div key={project.id} className="relative group">
                <ProjectCard
                  project={project}
                  onClick={() => setSelectedProject(project)}
                  hideActions
                />
                
                {/* Remove from Collection Button */}
                <button
                  onClick={() => handleRemoveFromCollection(project.id)}
                  className="absolute top-3 right-3 bg-destructive text-destructive-foreground p-2 rounded-full opacity-0 group-hover:opacity-100 transition-opacity shadow-lg hover:scale-110 transform"
                  title="Remove from collection"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Project Detail Modal */}
      {selectedProject && (
        <ProjectDetailModal
          project={selectedProject}
          isOpen={!!selectedProject}
          onClose={() => setSelectedProject(null)}
        />
      )}
    </div>
  );
}
