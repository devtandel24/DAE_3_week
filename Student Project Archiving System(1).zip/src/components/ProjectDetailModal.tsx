import { useState } from 'react';
import { X, ArrowLeft, ChevronLeft, ChevronRight, ExternalLink, Github, FileText, Award, BookOpen, Target, TrendingUp, Calendar, User as UserIcon, Bookmark } from 'lucide-react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { Project } from '../lib/mockData';
import { ScrollArea } from './ui/scroll-area';
import { Separator } from './ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { SaveToCollectionModal } from './SaveToCollectionModal';
import { GitHubDisclaimerModal } from './GitHubDisclaimerModal';
import { GitHubRedirectPage } from './GitHubRedirectPage';
import { useCollectionsStore } from '../lib/collectionsStore';

interface ProjectDetailModalProps {
  project: Project;
  onClose: () => void;
  onPrevious?: () => void;
  onNext?: () => void;
  hideStudentInfo?: boolean;
  isOpen?: boolean;
}

export function ProjectDetailModal({ project, onClose, onPrevious, onNext, hideStudentInfo = false, isOpen = true }: ProjectDetailModalProps) {
  const [showSaveModal, setShowSaveModal] = useState(false);
  const [showGitHubDisclaimer, setShowGitHubDisclaimer] = useState(false);
  const [showGitHubRedirect, setShowGitHubRedirect] = useState(false);
  const { getCollectionsForProject, hasAcceptedGitHubDisclaimer, acceptGitHubDisclaimer } = useCollectionsStore();
  
  const savedCollections = getCollectionsForProject(project.id);
  const isSaved = savedCollections.length > 0;

  const handleGitHubClick = () => {
    if (hasAcceptedGitHubDisclaimer(project.id)) {
      setShowGitHubRedirect(true);
    } else {
      setShowGitHubDisclaimer(true);
    }
  };

  const handleDisclaimerAccept = () => {
    acceptGitHubDisclaimer(project.id);
    setShowGitHubDisclaimer(false);
    setShowGitHubRedirect(true);
  };

  if (showGitHubRedirect) {
    return (
      <GitHubRedirectPage
        projectTitle={project.title}
        githubUrl={project.githubUrl}
        onBack={() => setShowGitHubRedirect(false)}
      />
    );
  }

  if (!isOpen) return null;
  return (
    <>
      <div
        className="fixed inset-0 bg-black/50 backdrop-blur-sm z-40 animate-in fade-in duration-350"
        onClick={onClose}
      />
      
      <div className="fixed top-0 right-0 bottom-0 w-[90%] max-w-5xl bg-white dark:bg-slate-800 z-50 shadow-2xl animate-in slide-in-from-right duration-350 flex flex-col overflow-hidden">
        <div className="flex items-center justify-between p-6 border-b border-border flex-shrink-0">
          <div className="flex items-center gap-4 flex-1 min-w-0">
            <Button
              variant="ghost"
              size="icon"
              onClick={onClose}
              className="rounded-full flex-shrink-0"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <h2 className="text-xl md:text-2xl truncate">{project.title}</h2>
          </div>

          <div className="flex items-center gap-2 flex-shrink-0">
            {onPrevious && (
              <Button
                variant="ghost"
                size="icon"
                onClick={onPrevious}
                className="rounded-full"
              >
                <ChevronLeft className="w-5 h-5" />
              </Button>
            )}
            {onNext && (
              <Button
                variant="ghost"
                size="icon"
                onClick={onNext}
                className="rounded-full"
              >
                <ChevronRight className="w-5 h-5" />
              </Button>
            )}
            <Button
              variant="ghost"
              size="icon"
              onClick={onClose}
              className="rounded-full"
            >
              <X className="w-5 h-5" />
            </Button>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto">
          <div className="p-6 space-y-6">
            {/* Hero Image */}
            <div className="aspect-video w-full overflow-hidden rounded-xl">
              <ImageWithFallback
                src={project.thumbnail}
                alt={project.title}
                className="w-full h-full object-cover"
              />
            </div>

            {/* Metadata Badges */}
            <div className="flex flex-wrap gap-2">
              <Badge variant="outline" className="gap-1">
                <BookOpen className="w-3 h-3" />
                {project.level}
              </Badge>
              <Badge variant="outline">{project.category}</Badge>
              <Badge variant="outline">{project.industry}</Badge>
              <Badge variant="outline">{project.track}</Badge>
              {project.courses.map((course) => (
                <Badge key={course} variant="outline">{course}</Badge>
              ))}
              <Badge variant="outline">{project.location}</Badge>
              <Badge variant="outline">{project.programType}</Badge>
              <Badge
                className={
                  project.curationStatus === 'Curated'
                    ? 'bg-green-500'
                    : project.curationStatus === 'Public'
                    ? 'bg-blue-500'
                    : project.curationStatus === 'Draft'
                    ? 'bg-yellow-500'
                    : 'bg-gray-500'
                }
              >
                {project.curationStatus}
              </Badge>
              <Badge variant="outline">
                <Calendar className="w-3 h-3 mr-1" />
                {project.semester} {project.year}
              </Badge>
              <Badge variant="outline">{project.projectType}</Badge>
            </div>

            {/* Job Roles Section */}
            {project.jobRoles && project.jobRoles.length > 0 && (
              <div className="space-y-2">
                <p className="text-sm text-muted-foreground">Career Pathways</p>
                <div className="flex flex-wrap gap-2">
                  {project.jobRoles.map((role) => (
                    <Badge
                      key={role}
                      variant="outline"
                      className="bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-300 border-blue-200 dark:border-blue-800"
                    >
                      {role}
                    </Badge>
                  ))}
                </div>
              </div>
            )}

            {/* Action Buttons */}
            <div className="flex flex-wrap gap-3">
              <Button
                className="bg-gradient-to-r from-[#7C3AED] to-[#EC4899] hover:opacity-90 uppercase tracking-wider"
                asChild
              >
                <a href={project.previewUrl} target="_blank" rel="noopener noreferrer">
                  <ExternalLink className="w-4 h-4 mr-2" />
                  Preview Live
                </a>
              </Button>
              <Button 
                variant="outline"
                onClick={handleGitHubClick}
              >
                <Github className="w-4 h-4 mr-2" />
                GitHub
              </Button>
              <Button
                variant="outline"
                onClick={() => setShowSaveModal(true)}
                className={isSaved ? 'border-primary' : ''}
              >
                <Bookmark className={`w-4 h-4 mr-2 ${isSaved ? 'fill-primary text-primary' : ''}`} />
                {isSaved ? `Saved (${savedCollections.length})` : 'Save to Collection'}
              </Button>
              {project.videoUrl && (
                <Button variant="outline" asChild>
                  <a href={project.videoUrl} target="_blank" rel="noopener noreferrer">
                    <ExternalLink className="w-4 h-4 mr-2" />
                    Video
                  </a>
                </Button>
              )}
              {project.presentationUrl && (
                <Button variant="outline" asChild>
                  <a href={project.presentationUrl} target="_blank" rel="noopener noreferrer">
                    <FileText className="w-4 h-4 mr-2" />
                    Presentation
                  </a>
                </Button>
              )}
            </div>

            <Separator />

            {/* Student Info - Hidden on public share for compliance */}
            {!hideStudentInfo && (
              <div className="flex items-start gap-4 p-4 bg-purple-50 dark:bg-purple-900/20 rounded-xl">
                <ImageWithFallback
                  src={project.studentPhoto}
                  alt={project.student}
                  className="w-16 h-16 rounded-full object-cover"
                />
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <h4>{project.student}</h4>
                    <Badge variant="outline">{project.cohort}</Badge>
                  </div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    {project.studentBio}
                  </p>
                </div>
              </div>
            )}

            {/* Demographics info shown instead on public share */}
            {hideStudentInfo && (
              <div className="flex items-start gap-4 p-4 bg-purple-50 dark:bg-purple-900/20 rounded-xl">
                <div className="flex-1">
                  <h4 className="mb-2">Project Information</h4>
                  <div className="flex flex-wrap gap-2">
                    <Badge variant="outline">{project.location}</Badge>
                    <Badge variant="outline">{project.programType}</Badge>
                    <Badge variant="outline">{project.cohort}</Badge>
                    <Badge variant="outline">{project.level} Level</Badge>
                  </div>
                </div>
              </div>
            )}

            {/* Main Content Tabs */}
            <Tabs defaultValue="about" className="w-full">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="about">About</TabsTrigger>
                <TabsTrigger value="technical">Technical</TabsTrigger>
                <TabsTrigger value="outcomes">Outcomes</TabsTrigger>
                <TabsTrigger value="media">Media</TabsTrigger>
              </TabsList>

              <TabsContent value="about" className="space-y-6 mt-6">
                {/* Description */}
                <section>
                  <h3 className="mb-3">Description</h3>
                  <p className="text-gray-600 dark:text-gray-300 leading-relaxed">
                    {project.about}
                  </p>
                </section>

                {/* Goals */}
                {project.goals && (
                  <section>
                    <div className="flex items-center gap-2 mb-3">
                      <Target className="w-5 h-5 text-purple-500" />
                      <h3>Goals & Objectives</h3>
                    </div>
                    <p className="text-gray-600 dark:text-gray-300 leading-relaxed">
                      {project.goals}
                    </p>
                  </section>
                )}

                {/* Challenges */}
                {project.challenges && (
                  <section>
                    <div className="flex items-center gap-2 mb-3">
                      <TrendingUp className="w-5 h-5 text-orange-500" />
                      <h3>Challenges Overcome</h3>
                    </div>
                    <p className="text-gray-600 dark:text-gray-300 leading-relaxed">
                      {project.challenges}
                    </p>
                  </section>
                )}

                {/* Themes */}
                {project.theme && project.theme.length > 0 && (
                  <section>
                    <h3 className="mb-3">Themes & Topics</h3>
                    <div className="flex flex-wrap gap-2">
                      {project.theme.map((theme) => (
                        <Badge key={theme} variant="secondary">
                          {theme}
                        </Badge>
                      ))}
                    </div>
                  </section>
                )}
              </TabsContent>

              <TabsContent value="technical" className="space-y-6 mt-6">
                {/* Tech Stack */}
                <section>
                  <h3 className="mb-3">Tech Stack</h3>
                  <div className="flex flex-wrap gap-2">
                    {project.techStack.map((tech) => (
                      <Badge
                        key={tech}
                        className="bg-gradient-to-r from-[#7C3AED] to-[#EC4899] text-white"
                      >
                        {tech}
                      </Badge>
                    ))}
                  </div>
                </section>

                {/* Frameworks */}
                <section>
                  <h3 className="mb-3">Frameworks & Libraries</h3>
                  <div className="flex flex-wrap gap-2">
                    {project.frameworks.map((framework) => (
                      <Badge key={framework} variant="outline">
                        {framework}
                      </Badge>
                    ))}
                  </div>
                </section>

                {/* Additional Tags */}
                {project.tags && project.tags.length > 0 && (
                  <section>
                    <h3 className="mb-3">Tags</h3>
                    <div className="flex flex-wrap gap-2">
                      {project.tags.map((tag) => (
                        <Badge key={tag} variant="secondary">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  </section>
                )}

                {/* Career Pathways */}
                {project.jobRoles && project.jobRoles.length > 0 && (
                  <section>
                    <h3 className="mb-3">Career Pathways</h3>
                    <div className="flex flex-wrap gap-2">
                      {project.jobRoles.map((role) => (
                        <Badge 
                          key={role} 
                          className="bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300 hover:bg-blue-200 dark:hover:bg-blue-900/50 border-blue-200 dark:border-blue-800"
                        >
                          {role}
                        </Badge>
                      ))}
                    </div>
                  </section>
                )}

                {/* Project Details Grid */}
                <section>
                  <h3 className="mb-3">Project Details</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="p-4 bg-gray-50 dark:bg-slate-700/50 rounded-lg">
                      <p className="text-sm text-gray-500 dark:text-gray-400 mb-1">Industry</p>
                      <p>{project.industry}</p>
                    </div>
                    <div className="p-4 bg-gray-50 dark:bg-slate-700/50 rounded-lg">
                      <p className="text-sm text-gray-500 dark:text-gray-400 mb-1">Courses</p>
                      <div className="flex flex-wrap gap-1">
                        {project.courses.map((course) => (
                          <Badge key={course} variant="secondary" className="text-xs">{course}</Badge>
                        ))}
                      </div>
                    </div>
                    <div className="p-4 bg-gray-50 dark:bg-slate-700/50 rounded-lg">
                      <p className="text-sm text-gray-500 dark:text-gray-400 mb-1">Track</p>
                      <p>{project.track}</p>
                    </div>
                    <div className="p-4 bg-gray-50 dark:bg-slate-700/50 rounded-lg">
                      <p className="text-sm text-gray-500 dark:text-gray-400 mb-1">Difficulty</p>
                      <Badge
                        className={
                          project.level === 'Beginner'
                            ? 'bg-green-500'
                            : project.level === 'Intermediate'
                            ? 'bg-yellow-500'
                            : 'bg-red-500'
                        }
                      >
                        {project.level}
                      </Badge>
                    </div>
                    <div className="p-4 bg-gray-50 dark:bg-slate-700/50 rounded-lg">
                      <p className="text-sm text-gray-500 dark:text-gray-400 mb-1">Type</p>
                      <p>{project.projectType}</p>
                    </div>
                    <div className="p-4 bg-gray-50 dark:bg-slate-700/50 rounded-lg">
                      <p className="text-sm text-gray-500 dark:text-gray-400 mb-1">Semester</p>
                      <p>{project.semester} {project.year}</p>
                    </div>
                  </div>
                </section>
              </TabsContent>

              <TabsContent value="outcomes" className="space-y-6 mt-6">
                {/* Outcomes & Results */}
                <section>
                  <div className="flex items-center gap-2 mb-3">
                    <Award className="w-5 h-5 text-green-500" />
                    <h3>Outcomes & Results</h3>
                  </div>
                  <p className="text-gray-600 dark:text-gray-300 leading-relaxed">
                    {project.outcomes}
                  </p>
                </section>

                {/* Project Stats */}
                <section>
                  <h3 className="mb-3">Project Statistics</h3>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    <div className="p-4 bg-purple-50 dark:bg-purple-900/20 rounded-lg text-center">
                      <p className="text-3xl bg-gradient-to-r from-[#7C3AED] to-[#EC4899] bg-clip-text text-transparent mb-1">
                        {project.views}
                      </p>
                      <p className="text-sm text-gray-600 dark:text-gray-400">Views</p>
                    </div>
                    <div className="p-4 bg-purple-50 dark:bg-purple-900/20 rounded-lg text-center">
                      <p className="text-3xl bg-gradient-to-r from-[#7C3AED] to-[#EC4899] bg-clip-text text-transparent mb-1">
                        {project.techStack.length}
                      </p>
                      <p className="text-sm text-gray-600 dark:text-gray-400">Technologies</p>
                    </div>
                    <div className="p-4 bg-purple-50 dark:bg-purple-900/20 rounded-lg text-center">
                      <p className="text-3xl bg-gradient-to-r from-[#7C3AED] to-[#EC4899] bg-clip-text text-transparent mb-1">
                        {new Date(project.date).toLocaleDateString('en-US', { month: 'short', year: 'numeric' })}
                      </p>
                      <p className="text-sm text-gray-600 dark:text-gray-400">Completed</p>
                    </div>
                  </div>
                </section>

                {/* Skills Demonstrated */}
                <section className="p-6 bg-gradient-to-r from-purple-50 to-pink-50 dark:from-purple-900/20 dark:to-pink-900/20 rounded-xl">
                  <h3 className="mb-4">Skills Demonstrated</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {project.theme.map((theme) => (
                      <div key={theme} className="flex items-center gap-2">
                        <div className="w-2 h-2 rounded-full bg-gradient-to-r from-[#7C3AED] to-[#EC4899]"></div>
                        <span className="text-sm">{theme}</span>
                      </div>
                    ))}
                  </div>
                </section>
              </TabsContent>

              <TabsContent value="media" className="space-y-6 mt-6">
                {/* Video Embed */}
                {project.videoUrl && (
                  <section>
                    <h3 className="mb-3">Project Video</h3>
                    <div className="aspect-video w-full overflow-hidden rounded-xl bg-gray-100 dark:bg-slate-700 flex items-center justify-center">
                      <Button variant="outline" asChild>
                        <a href={project.videoUrl} target="_blank" rel="noopener noreferrer">
                          <ExternalLink className="w-4 h-4 mr-2" />
                          Watch Video
                        </a>
                      </Button>
                    </div>
                  </section>
                )}

                {/* Screenshots Gallery */}
                {project.screenshots && project.screenshots.length > 0 && (
                  <section>
                    <h3 className="mb-3">Screenshots</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {project.screenshots.map((screenshot, index) => (
                        <div key={index} className="aspect-video overflow-hidden rounded-xl">
                          <ImageWithFallback
                            src={screenshot}
                            alt={`Screenshot ${index + 1}`}
                            className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                          />
                        </div>
                      ))}
                    </div>
                  </section>
                )}

                {/* Links */}
                <section>
                  <h3 className="mb-3">Resources</h3>
                  <div className="space-y-2">
                    <a
                      href={project.previewUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-3 p-4 bg-gray-50 dark:bg-slate-700/50 rounded-lg hover:bg-gray-100 dark:hover:bg-slate-700 transition-colors"
                    >
                      <ExternalLink className="w-5 h-5 text-purple-500" />
                      <div>
                        <p>Live Demo</p>
                        <p className="text-sm text-gray-500 dark:text-gray-400">View the live project</p>
                      </div>
                    </a>
                    <a
                      href={project.githubUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-3 p-4 bg-gray-50 dark:bg-slate-700/50 rounded-lg hover:bg-gray-100 dark:hover:bg-slate-700 transition-colors"
                    >
                      <Github className="w-5 h-5 text-purple-500" />
                      <div>
                        <p>Source Code</p>
                        <p className="text-sm text-gray-500 dark:text-gray-400">View on GitHub</p>
                      </div>
                    </a>
                    {project.presentationUrl && (
                      <a
                        href={project.presentationUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center gap-3 p-4 bg-gray-50 dark:bg-slate-700/50 rounded-lg hover:bg-gray-100 dark:hover:bg-slate-700 transition-colors"
                      >
                        <FileText className="w-5 h-5 text-purple-500" />
                        <div>
                          <p>Presentation</p>
                          <p className="text-sm text-gray-500 dark:text-gray-400">View slides</p>
                        </div>
                      </a>
                    )}
                  </div>
                </section>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>

      {/* Save to Collection Modal */}
      <SaveToCollectionModal
        projectId={project.id}
        projectTitle={project.title}
        isOpen={showSaveModal}
        onClose={() => setShowSaveModal(false)}
      />

      {/* GitHub Disclaimer Modal */}
      <GitHubDisclaimerModal
        isOpen={showGitHubDisclaimer}
        onClose={() => setShowGitHubDisclaimer(false)}
        onAccept={handleDisclaimerAccept}
      />
    </>
  );
}
