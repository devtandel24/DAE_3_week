import { useState } from 'react';
import { ExternalLink } from 'lucide-react';
import {
  AlertDialog,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from './ui/alert-dialog';
import { Button } from './ui/button';
import { Checkbox } from './ui/checkbox';

interface GitHubDisclaimerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAccept: () => void;
}

export function GitHubDisclaimerModal({
  isOpen,
  onClose,
  onAccept,
}: GitHubDisclaimerModalProps) {
  const [hasAccepted, setHasAccepted] = useState(false);

  const handleContinue = () => {
    if (hasAccepted) {
      onAccept();
    }
  };

  const handleClose = () => {
    setHasAccepted(false);
    onClose();
  };

  return (
    <AlertDialog open={isOpen} onOpenChange={handleClose}>
      <AlertDialogContent className="sm:max-w-[600px]">
        <AlertDialogHeader>
          <AlertDialogTitle>Before you view this project on GitHub</AlertDialogTitle>
          <AlertDialogDescription className="text-base space-y-4 pt-4">
            <p>
              This repository is provided for educational review. By proceeding, you agree not to copy,
              redistribute, or misrepresent this work as your own. Use of this content is governed by
              DAE's Licenses and Terms of Use.
            </p>

            <div className="pt-2">
              <div className="flex items-start space-x-3 p-4 bg-muted rounded-lg border">
                <Checkbox
                  id="accept-disclaimer"
                  checked={hasAccepted}
                  onCheckedChange={(checked) => setHasAccepted(checked === true)}
                  className="mt-0.5"
                />
                <label
                  htmlFor="accept-disclaimer"
                  className="text-sm cursor-pointer select-none flex-1"
                >
                  I've read and agree to the disclaimer, Licenses, and Terms.
                </label>
              </div>
            </div>

            <div className="flex gap-4 text-sm pt-2">
              <a
                href="#"
                className="text-primary hover:underline flex items-center gap-1"
                target="_blank"
                rel="noopener noreferrer"
                onClick={(e) => e.preventDefault()}
              >
                Licenses
                <ExternalLink className="w-3 h-3" />
              </a>
              <a
                href="#"
                className="text-primary hover:underline flex items-center gap-1"
                target="_blank"
                rel="noopener noreferrer"
                onClick={(e) => e.preventDefault()}
              >
                Terms & Privacy
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <Button variant="ghost" onClick={handleClose}>
            Cancel
          </Button>
          <Button
            onClick={handleContinue}
            disabled={!hasAccepted}
            className="bg-gradient-to-r from-[#7C3AED] to-[#EC4899] hover:opacity-90 disabled:opacity-50"
          >
            Continue
          </Button>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}
