import { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Checkbox } from './ui/checkbox';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from './ui/dialog';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from './ui/accordion';
import logoImage from 'figma:asset/5a41359254d30e34254c79b43c72d23d4047b129.png';
import { ImageWithFallback } from './figma/ImageWithFallback';

const LOGIN_BG = {
  src: 'https://images.unsplash.com/photo-1583929212081-b59975d37aa8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1920',
  alt: 'DAE Four Pillars',
  overlay: 'linear-gradient(180deg, rgba(15, 23, 42, 0.35), rgba(15, 23, 42, 0.55))',
};

interface LoginPageProps {
  onLogin: () => void;
}

export function LoginPage({ onLogin }: LoginPageProps) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [rememberMe, setRememberMe] = useState(false);
  const [showPolicyModal, setShowPolicyModal] = useState(false);
  const [acceptedPolicies, setAcceptedPolicies] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Show policy modal on first login
    setShowPolicyModal(true);
  };

  const handlePolicyAccept = () => {
    if (acceptedPolicies) {
      setShowPolicyModal(false);
      onLogin();
    }
  };

  const currentDateTime = new Date().toLocaleString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });

  // Mock IP address for demonstration
  const mockIP = '192.168.1.1';

  return (
    <>
      <div className="min-h-screen flex items-center justify-center relative overflow-hidden p-4">
        {/* Background Image Layer */}
        <div className="absolute inset-0 z-0">
          <ImageWithFallback
            src={LOGIN_BG.src}
            alt={LOGIN_BG.alt}
            className="w-full h-full object-cover animate-[fadeIn_300ms_ease-in]"
            style={{ opacity: 1 }}
          />
          {/* Gradient Overlay */}
          <div 
            className="absolute inset-0"
            style={{ background: LOGIN_BG.overlay }}
          />
        </div>
        
        {/* Form Container */}
        <div className="w-full max-w-[400px] bg-white dark:bg-slate-800 rounded-xl shadow-lg border border-border p-8 relative z-10">
          <div className="flex flex-col items-center mb-8">
            <img src={logoImage} alt="dae" className="w-40 h-auto mb-4" />
          </div>

          {/* Development Note */}
          <div className="mb-6 p-3 bg-gray-100 dark:bg-slate-700 border border-gray-300 dark:border-slate-600 rounded-lg">
            <p className="text-xs text-gray-600 dark:text-gray-300 text-center">
              <span className="font-medium">Development Note:</span> Authentication not yet implemented. 
              Use any credentials to explore the prototype.
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                placeholder="your.email@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="h-11 focus:ring-2 focus:ring-[#7C3AED]"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type="password"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="h-11 focus:ring-2 focus:ring-[#7C3AED]"
                required
              />
            </div>

            <div className="flex items-center space-x-2">
              <Checkbox
                id="remember"
                checked={rememberMe}
                onCheckedChange={(checked) => setRememberMe(checked as boolean)}
              />
              <label htmlFor="remember" className="cursor-pointer select-none">
                Remember me
              </label>
            </div>

            <Button
              type="submit"
              className="w-full h-12 bg-gradient-to-r from-[#7C3AED] to-[#EC4899] hover:opacity-90 transition-opacity uppercase tracking-wider"
            >
              Login
            </Button>
          </form>
        </div>
      </div>

      {/* First-Time User Policy Modal */}
      <Dialog open={showPolicyModal} onOpenChange={setShowPolicyModal}>
        <DialogContent className="max-w-[600px] max-h-[85vh] p-0 gap-0 flex flex-col">
          <DialogHeader className="px-6 pt-6 pb-4">
            <DialogTitle>Welcome to DAE Project Showcase</DialogTitle>
            <DialogDescription>
              This platform showcases innovative student projects from DAE programs. We use AI to organize and present projects while maintaining fairness and non-bias in all implementations. Please review and accept our policies to continue.
            </DialogDescription>
          </DialogHeader>

          <div className="overflow-y-auto flex-1 px-6 py-2">
            <Accordion type="single" collapsible className="w-full">
              <AccordionItem value="privacy">
                <AccordionTrigger>Privacy Policy</AccordionTrigger>
                <AccordionContent className="text-sm text-muted-foreground space-y-2">
                  <p>
                    This Privacy Policy describes how DAE (Digital Arts Experience) collects,
                    uses, and protects your personal information when you use our Project
                    Showcase platform.
                  </p>
                  <p className="font-medium text-foreground">How AI is being used:</p>
                  <p>
                    Our platform uses AI to organize and present student projects. All AI
                    implementations are designed with fairness and non-bias as core principles.
                    We employ machine learning for project categorization, search optimization,
                    and analytics insights.
                  </p>
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="terms">
                <AccordionTrigger>Terms of Use</AccordionTrigger>
                <AccordionContent className="text-sm text-muted-foreground space-y-2">
                  <p>
                    By accessing and using the DAE Project Showcase, you agree to comply with
                    and be bound by these Terms of Use.
                  </p>
                  <p className="font-medium text-foreground">How AI is being used:</p>
                  <p>
                    Our platform uses AI to organize and present student projects. All AI
                    implementations are designed with fairness and non-bias as core principles.
                  </p>
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="conditions">
                <AccordionTrigger>Terms and Conditions</AccordionTrigger>
                <AccordionContent className="text-sm text-muted-foreground space-y-2">
                  <p>
                    These Terms and Conditions govern your use of the DAE Project Showcase
                    platform and constitute a legal agreement between you and DAE.
                  </p>
                  <p className="font-medium text-foreground">How AI is being used:</p>
                  <p>
                    Our platform uses AI to organize and present student projects. All AI
                    implementations are designed with fairness and non-bias as core principles.
                  </p>
                </AccordionContent>
              </AccordionItem>
            </Accordion>
          </div>

          <div className="px-6 pb-6 pt-4 border-t border-border space-y-4 bg-card">
            <div className="flex items-start space-x-3 p-4 bg-muted rounded-lg border-2 border-border">
              <Checkbox
                id="accept"
                checked={acceptedPolicies}
                onCheckedChange={(checked) => setAcceptedPolicies(checked === true)}
                className="mt-1 border-2"
              />
              <label htmlFor="accept" className="text-sm cursor-pointer select-none text-foreground flex-1">
                I accept the Privacy Policy, Terms of Use, and Terms and Conditions
              </label>
            </div>

            <div className="text-xs text-muted-foreground">
              Timestamp: {currentDateTime}
            </div>

            <Button
              onClick={handlePolicyAccept}
              disabled={!acceptedPolicies}
              className="w-full h-12 bg-gradient-to-r from-[#7C3AED] to-[#EC4899] hover:opacity-90 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
            >
              Continue
            </Button>

            <p className="text-xs text-muted-foreground text-center">
              By clicking Continue, you acknowledge acceptance on {currentDateTime} from IP {mockIP}
            </p>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
