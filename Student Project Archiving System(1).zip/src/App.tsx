import { useState, useEffect } from 'react';
import { LoginPage } from './components/LoginPage';
import { Header } from './components/Header';
import { MainGallery } from './components/MainGallery';
import { AdminDashboard } from './components/AdminDashboard';
import { AdminUploadForm } from './components/AdminUploadForm';
import { ShareLinkCreation } from './components/ShareLinkCreation';
import { ProfilePage } from './components/ProfilePage';
import { PublicShareView } from './components/PublicShareView';
import { LinkManagement } from './components/LinkManagement';
import { NotificationsCenter } from './components/NotificationsCenter';
import { HelpCenter } from './components/HelpCenter';
import { SettingsPage } from './components/SettingsPage';
import { CollectionsPage } from './components/CollectionsPage';
import { CollectionDetailPage } from './components/CollectionDetailPage';
import { Toaster } from './components/ui/sonner';
import { toast } from 'sonner@2.0.3';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from './components/ui/alert-dialog';

type Page = 'login' | 'home' | 'projects' | 'dashboard' | 'upload' | 'share-link' | 'profile' | 'settings' | 'public-share' | 'my-links' | 'notifications' | 'help' | 'collections' | 'collection-detail';

export default function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [currentPage, setCurrentPage] = useState<Page>('home');
  const [darkMode, setDarkMode] = useState(false);
  const [deleteProjectId, setDeleteProjectId] = useState<string | null>(null);
  const [editingProjectId, setEditingProjectId] = useState<string | null>(null);
  const [selectedCollectionId, setSelectedCollectionId] = useState<string | null>(null);
  const [shareLinkCollectionId, setShareLinkCollectionId] = useState<string | null>(null);

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  const handleLogin = () => {
    setIsAuthenticated(true);
    setCurrentPage('home');
    toast.success('Welcome back to dae!');
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setCurrentPage('login');
    toast.success('Logged out successfully');
  };

  const handleNavigate = (page: string) => {
    setCurrentPage(page as Page);
  };

  const toggleDarkMode = () => {
    setDarkMode((prev) => !prev);
  };

  const handleUploadSave = () => {
    setCurrentPage('dashboard');
    toast.success('Project published successfully!');
  };

  const handleEditProject = (projectId: string) => {
    setEditingProjectId(projectId);
    setCurrentPage('upload');
  };

  const handleDeleteProject = (projectId: string) => {
    setDeleteProjectId(projectId);
  };

  const confirmDelete = () => {
    if (deleteProjectId) {
      toast.success('Project deleted successfully!');
      setDeleteProjectId(null);
    }
  };

  if (!isAuthenticated) {
    return (
      <>
        <LoginPage onLogin={handleLogin} />
        <Toaster position="top-right" />
      </>
    );
  }

  return (
    <div className="min-h-screen bg-white dark:bg-slate-900">
      {/* Show header on all pages except public-share (external users shouldn't see full nav) */}
      {currentPage !== 'public-share' && (
        <Header
          currentPage={currentPage}
          onNavigate={handleNavigate}
          onLogout={handleLogout}
          darkMode={darkMode}
          toggleDarkMode={toggleDarkMode}
          unreadNotifications={3}
        />
      )}

      {currentPage === 'home' && <MainGallery />}
      {currentPage === 'projects' && <MainGallery />}
      {currentPage === 'dashboard' && (
        <AdminDashboard
          onUploadNew={() => setCurrentPage('upload')}
          onCreateShareLink={() => setCurrentPage('share-link')}
          onEditProject={handleEditProject}
          onDeleteProject={handleDeleteProject}
        />
      )}
      {currentPage === 'upload' && (
        <AdminUploadForm
          onCancel={() => {
            setCurrentPage('dashboard');
            setEditingProjectId(null);
          }}
          onSave={() => {
            handleUploadSave();
            setEditingProjectId(null);
          }}
          editingProjectId={editingProjectId}
        />
      )}
      {currentPage === 'share-link' && (
        <ShareLinkCreation 
          onBack={() => {
            setCurrentPage(shareLinkCollectionId ? 'collections' : 'dashboard');
            setShareLinkCollectionId(null);
          }}
          onPreview={() => setCurrentPage('public-share')}
          collectionId={shareLinkCollectionId}
        />
      )}
      {currentPage === 'profile' && (
        <ProfilePage onBack={() => setCurrentPage('projects')} />
      )}
      {currentPage === 'my-links' && (
        <LinkManagement onCreateNew={() => setCurrentPage('share-link')} />
      )}
      {currentPage === 'notifications' && (
        <NotificationsCenter onBack={() => setCurrentPage('projects')} />
      )}
      {currentPage === 'help' && (
        <HelpCenter onBack={() => setCurrentPage('projects')} />
      )}
      {currentPage === 'settings' && (
        <SettingsPage onBack={() => setCurrentPage('projects')} />
      )}
      {currentPage === 'collections' && (
        <CollectionsPage 
          onViewCollection={(collectionId) => {
            setSelectedCollectionId(collectionId);
            setCurrentPage('collection-detail');
          }}
          onCreateShareLink={(collectionId) => {
            setShareLinkCollectionId(collectionId);
            setCurrentPage('share-link');
          }}
          onBackToGallery={() => setCurrentPage('projects')}
        />
      )}
      {currentPage === 'collection-detail' && selectedCollectionId && (
        <CollectionDetailPage
          collectionId={selectedCollectionId}
          onBack={() => setCurrentPage('collections')}
          onBackToGallery={() => setCurrentPage('projects')}
        />
      )}
      {currentPage === 'public-share' && (
        <PublicShareView
          shareId="demo123"
          requirePassword={false}
          theme={darkMode ? 'dark' : 'light'}
          leadCapture={true}
        />
      )}

      <Toaster position="top-right" />

      <AlertDialog open={deleteProjectId !== null} onOpenChange={() => setDeleteProjectId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete the project
              from the system.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmDelete}
              className="bg-red-500 hover:bg-red-600"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
