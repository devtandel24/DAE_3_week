import { useState } from 'react';
import { Copy, ExternalLink, Eye, MoreVertical, Clock, CheckCircle, XCircle, Search, Calendar, TrendingUp, Users } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from './ui/table';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from './ui/dropdown-menu';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from './ui/select';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from './ui/dialog';
import { Badge } from './ui/badge';
import { toast } from 'sonner@2.0.3';

interface LinkManagementProps {
  onCreateNew: () => void;
}

interface ShareLink {
  id: string;
  name: string;
  projectCount: number;
  created: string;
  expires: string;
  daysRemaining: number;
  status: 'Active' | 'Expiring Soon' | 'Expired' | 'Revoked';
  views: number;
  url: string;
}

export function LinkManagement({ onCreateNew }: LinkManagementProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [showAnalytics, setShowAnalytics] = useState(false);
  const [selectedLink, setSelectedLink] = useState<ShareLink | null>(null);
  const [links, setLinks] = useState<ShareLink[]>([
    {
      id: '1',
      name: 'Novus Insights - Cybersecurity Projects',
      projectCount: 5,
      created: '2025-01-15',
      expires: '2025-04-15',
      daysRemaining: 60,
      status: 'Active',
      views: 47,
      url: 'https://projects.dae.org/share/abc123xyz',
    },
    {
      id: '2',
      name: 'Workforce Alliance - Q1 Showcase',
      projectCount: 8,
      created: '2024-12-10',
      expires: '2025-02-28',
      daysRemaining: 5,
      status: 'Expiring Soon',
      views: 123,
      url: 'https://projects.dae.org/share/def456uvw',
    },
    {
      id: '3',
      name: 'Fall 2024 Board Presentation',
      projectCount: 12,
      created: '2024-11-05',
      expires: '2025-01-20',
      daysRemaining: -25,
      status: 'Expired',
      views: 89,
      url: 'https://projects.dae.org/share/ghi789rst',
    },
    {
      id: '4',
      name: 'Partner ABC Cybersecurity Projects',
      projectCount: 7,
      created: '2025-01-20',
      expires: '2025-05-20',
      daysRemaining: 95,
      status: 'Active',
      views: 23,
      url: 'https://projects.dae.org/share/jkl012mno',
    },
    {
      id: '5',
      name: 'Game Development Showcase 2024',
      projectCount: 10,
      created: '2024-12-01',
      expires: '2025-03-01',
      daysRemaining: 31,
      status: 'Active',
      views: 156,
      url: 'https://projects.dae.org/share/pqr345stu',
    },
  ]);

  const filteredLinks = links.filter((link) => {
    const matchesSearch = link.name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'all' || link.status.toLowerCase().replace(' ', '-') === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const handleCopyLink = async (url: string) => {
    try {
      await navigator.clipboard.writeText(url);
      toast.success('Link copied to clipboard!');
    } catch (err) {
      toast.error('Failed to copy link. Please try again.');
    }
  };

  const handleExtend = (linkName: string) => {
    toast.success(`Extended link: ${linkName}`);
  };

  const handleRevoke = (linkId: string, linkName: string) => {
    setLinks(links.map(link => 
      link.id === linkId ? { ...link, status: 'Revoked' as const } : link
    ));
    toast.success(`Revoked link: ${linkName}`);
  };

  const handlePreview = (url: string) => {
    // Open in new tab
    window.open(url, '_blank');
    toast.success('Opening preview in new tab...');
  };

  const handleViewAnalytics = (link: ShareLink) => {
    setSelectedLink(link);
    setShowAnalytics(true);
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'Active':
        return <Badge className="bg-green-500">Active</Badge>;
      case 'Expiring Soon':
        return <Badge className="bg-orange-500">Expiring Soon</Badge>;
      case 'Expired':
        return <Badge className="bg-gray-500">Expired</Badge>;
      case 'Revoked':
        return <Badge className="bg-red-500">Revoked</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-slate-900">
      <div className="container mx-auto px-4 py-8 space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <h1 className="mb-2">My Shared Links</h1>
            <p className="text-gray-600 dark:text-gray-400">
              Manage and track all your shared project links
            </p>
          </div>
          <Button
            onClick={onCreateNew}
            className="bg-gradient-to-r from-[#7C3AED] to-[#EC4899] hover:opacity-90"
          >
            Create New Link
          </Button>
        </div>

        {/* Filter Bar */}
        <div className="bg-white dark:bg-slate-800 rounded-xl p-4 border border-border">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <Input
                  placeholder="Search links..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full sm:w-48">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="expiring-soon">Expiring Soon</SelectItem>
                <SelectItem value="expired">Expired</SelectItem>
                <SelectItem value="revoked">Revoked</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Links Table */}
        <div className="bg-white dark:bg-slate-800 rounded-xl border border-border overflow-hidden">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Link Name</TableHead>
                  <TableHead className="text-center">Projects</TableHead>
                  <TableHead>Created</TableHead>
                  <TableHead>Expiration</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-center">Views</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredLinks.map((link) => (
                  <TableRow key={link.id}>
                    <TableCell>
                      <div className="space-y-1">
                        <p className="font-medium">{link.name}</p>
                        <p className="text-xs text-gray-500 dark:text-gray-400 truncate max-w-xs">
                          {link.url}
                        </p>
                      </div>
                    </TableCell>
                    <TableCell className="text-center">
                      <Badge variant="outline">{link.projectCount}</Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Calendar className="w-4 h-4 text-gray-400" />
                        {new Date(link.created).toLocaleDateString('en-US', {
                          month: 'short',
                          day: 'numeric',
                          year: 'numeric',
                        })}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <Clock className="w-4 h-4 text-gray-400" />
                          {new Date(link.expires).toLocaleDateString('en-US', {
                            month: 'short',
                            day: 'numeric',
                            year: 'numeric',
                          })}
                        </div>
                        {link.status !== 'Expired' && link.status !== 'Revoked' && (
                          <p className="text-xs text-gray-500 dark:text-gray-400">
                            {link.daysRemaining} days remaining
                          </p>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>{getStatusBadge(link.status)}</TableCell>
                    <TableCell className="text-center">
                      <div className="flex items-center justify-center gap-1">
                        <Eye className="w-4 h-4 text-gray-400" />
                        <span>{link.views}</span>
                      </div>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-2">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleCopyLink(link.url)}
                          title="Copy Link"
                        >
                          <Copy className="w-4 h-4" />
                        </Button>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon">
                              <MoreVertical className="w-4 h-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => handleCopyLink(link.url)}>
                              <Copy className="w-4 h-4 mr-2" />
                              Copy Link
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => handlePreview(link.url)}>
                              <ExternalLink className="w-4 h-4 mr-2" />
                              Preview
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => handleViewAnalytics(link)}>
                              <Eye className="w-4 h-4 mr-2" />
                              View Analytics
                            </DropdownMenuItem>
                            {link.status === 'Expiring Soon' && (
                              <DropdownMenuItem onClick={() => handleExtend(link.name)}>
                                <Clock className="w-4 h-4 mr-2" />
                                Extend
                              </DropdownMenuItem>
                            )}
                            {link.status !== 'Expired' && link.status !== 'Revoked' && (
                              <DropdownMenuItem onClick={() => handleRevoke(link.id, link.name)}>
                                <XCircle className="w-4 h-4 mr-2" />
                                Revoke
                              </DropdownMenuItem>
                            )}
                            {link.status === 'Expired' && (
                              <DropdownMenuItem>
                                <CheckCircle className="w-4 h-4 mr-2" />
                                Regenerate
                              </DropdownMenuItem>
                            )}
                            <DropdownMenuItem className="text-red-600 dark:text-red-400">
                              <XCircle className="w-4 h-4 mr-2" />
                              Delete
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          {filteredLinks.length === 0 && (
            <div className="py-12 text-center">
              <p className="text-gray-500 dark:text-gray-400 mb-4">
                No links found matching your criteria
              </p>
              <Button onClick={onCreateNew} variant="outline">
                Create Your First Link
              </Button>
            </div>
          )}
        </div>
      </div>

      {/* Analytics Dialog */}
      <Dialog open={showAnalytics} onOpenChange={setShowAnalytics}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Link Analytics</DialogTitle>
            <DialogDescription>
              {selectedLink?.name}
            </DialogDescription>
          </DialogHeader>
          
          {selectedLink && (
            <div className="space-y-6">
              {/* Stats Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="bg-purple-50 dark:bg-purple-900/20 rounded-lg p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <Eye className="w-5 h-5 text-purple-500" />
                    <p className="text-sm text-gray-600 dark:text-gray-400">Total Views</p>
                  </div>
                  <p className="text-3xl bg-gradient-to-r from-[#7C3AED] to-[#EC4899] bg-clip-text text-transparent">
                    {selectedLink.views}
                  </p>
                </div>
                
                <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <Users className="w-5 h-5 text-blue-500" />
                    <p className="text-sm text-gray-600 dark:text-gray-400">Unique Visitors</p>
                  </div>
                  <p className="text-3xl text-blue-600 dark:text-blue-400">
                    {Math.floor(selectedLink.views * 0.7)}
                  </p>
                </div>
                
                <div className="bg-green-50 dark:bg-green-900/20 rounded-lg p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <TrendingUp className="w-5 h-5 text-green-500" />
                    <p className="text-sm text-gray-600 dark:text-gray-400">Avg. Time</p>
                  </div>
                  <p className="text-3xl text-green-600 dark:text-green-400">
                    4:32
                  </p>
                </div>
              </div>

              {/* Additional Details */}
              <div className="space-y-3">
                <div className="flex justify-between items-center py-2 border-b border-border">
                  <span className="text-gray-600 dark:text-gray-400">Projects Shared</span>
                  <span className="font-medium">{selectedLink.projectCount}</span>
                </div>
                <div className="flex justify-between items-center py-2 border-b border-border">
                  <span className="text-gray-600 dark:text-gray-400">Created</span>
                  <span className="font-medium">{new Date(selectedLink.created).toLocaleDateString()}</span>
                </div>
                <div className="flex justify-between items-center py-2 border-b border-border">
                  <span className="text-gray-600 dark:text-gray-400">Expires</span>
                  <span className="font-medium">{new Date(selectedLink.expires).toLocaleDateString()}</span>
                </div>
                <div className="flex justify-between items-center py-2 border-b border-border">
                  <span className="text-gray-600 dark:text-gray-400">Status</span>
                  {getStatusBadge(selectedLink.status)}
                </div>
                <div className="flex justify-between items-center py-2">
                  <span className="text-gray-600 dark:text-gray-400">Bounce Rate</span>
                  <span className="font-medium">23%</span>
                </div>
              </div>

              {/* Top Viewed Projects */}
              <div>
                <h4 className="mb-3">Top Viewed Projects</h4>
                <div className="space-y-2">
                  <div className="flex justify-between items-center p-3 bg-gray-50 dark:bg-slate-700 rounded-lg">
                    <span className="text-sm">Network Security Dashboard</span>
                    <Badge variant="outline">34 views</Badge>
                  </div>
                  <div className="flex justify-between items-center p-3 bg-gray-50 dark:bg-slate-700 rounded-lg">
                    <span className="text-sm">Blockchain Voting System</span>
                    <Badge variant="outline">28 views</Badge>
                  </div>
                  <div className="flex justify-between items-center p-3 bg-gray-50 dark:bg-slate-700 rounded-lg">
                    <span className="text-sm">AI Malware Detection</span>
                    <Badge variant="outline">19 views</Badge>
                  </div>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
