import { useState } from 'react';
import { Star, AlertTriangle, Trophy, Info, Eye, X, Bell } from 'lucide-react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { ScrollArea } from './ui/scroll-area';

interface NotificationsCenterProps {
  onBack: () => void;
}

interface Notification {
  id: string;
  type: 'curation' | 'expiration' | 'milestone' | 'system' | 'access';
  title: string;
  message: string;
  timestamp: string;
  read: boolean;
  actions?: { label: string; handler: () => void }[];
}

export function NotificationsCenter({ onBack }: NotificationsCenterProps) {
  const [notifications, setNotifications] = useState<Notification[]>([
    {
      id: '1',
      type: 'curation',
      title: 'Project added to Top 150',
      message: "Project 'Smart City Dashboard' has been added to the Top 150 showcase by caitlin@dae.org",
      timestamp: '2 hours ago',
      read: false,
    },
    {
      id: '2',
      type: 'expiration',
      title: 'Shared link expiring soon',
      message: "'Novus Insights' link expires in 5 days (Apr 15, 2025)",
      timestamp: '5 hours ago',
      read: false,
    },
    {
      id: '3',
      type: 'milestone',
      title: 'Milestone reached!',
      message: 'Your projects have reached 10,000 total views',
      timestamp: 'Yesterday',
      read: false,
    },
    {
      id: '4',
      type: 'system',
      title: 'System maintenance scheduled',
      message: 'Platform maintenance on Feb 1, 2025 from 2-4 AM EST',
      timestamp: 'Yesterday',
      read: true,
    },
    {
      id: '5',
      type: 'access',
      title: 'Shared link accessed',
      message: "'Workforce Alliance' link was accessed 3 times today",
      timestamp: '2 days ago',
      read: true,
    },
  ]);

  const [filter, setFilter] = useState<'all' | 'unread'>('all');

  const filteredNotifications = notifications.filter((n) =>
    filter === 'all' ? true : !n.read
  );

  const unreadCount = notifications.filter((n) => !n.read).length;

  const handleMarkAsRead = (id: string) => {
    setNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, read: true } : n))
    );
  };

  const handleMarkAllAsRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
  };

  const handleDismiss = (id: string) => {
    setNotifications((prev) => prev.filter((n) => n.id !== id));
  };

  const getIcon = (type: string) => {
    switch (type) {
      case 'curation':
        return <Star className="w-5 h-5 text-yellow-500" />;
      case 'expiration':
        return <AlertTriangle className="w-5 h-5 text-orange-500" />;
      case 'milestone':
        return <Trophy className="w-5 h-5 text-blue-500" />;
      case 'system':
        return <Info className="w-5 h-5 text-gray-500" />;
      case 'access':
        return <Eye className="w-5 h-5 text-purple-500" />;
      default:
        return <Bell className="w-5 h-5" />;
    }
  };

  const getBackgroundColor = (type: string) => {
    switch (type) {
      case 'curation':
        return 'bg-yellow-50 dark:bg-yellow-900/20 border-yellow-200 dark:border-yellow-800';
      case 'expiration':
        return 'bg-orange-50 dark:bg-orange-900/20 border-orange-200 dark:border-orange-800';
      case 'milestone':
        return 'bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800';
      case 'system':
        return 'bg-gray-50 dark:bg-gray-800/20 border-gray-200 dark:border-gray-700';
      case 'access':
        return 'bg-purple-50 dark:bg-purple-900/20 border-purple-200 dark:border-purple-800';
      default:
        return 'bg-white dark:bg-slate-800 border-border';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-slate-900">
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto space-y-6">
          {/* Header */}
          <div className="flex items-center justify-between">
            <div>
              <h1 className="mb-2">Notifications</h1>
              <p className="text-gray-600 dark:text-gray-400">
                Stay updated on important events and activities
              </p>
            </div>
            <Button variant="ghost" onClick={onBack}>
              ← Back
            </Button>
          </div>

          {/* Controls */}
          <div className="bg-white dark:bg-slate-800 rounded-xl p-4 border border-border">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <Tabs value={filter} onValueChange={(v) => setFilter(v as 'all' | 'unread')}>
                  <TabsList>
                    <TabsTrigger value="all">
                      All
                      <Badge variant="secondary" className="ml-2">
                        {notifications.length}
                      </Badge>
                    </TabsTrigger>
                    <TabsTrigger value="unread">
                      Unread
                      {unreadCount > 0 && (
                        <Badge className="ml-2 bg-red-500">{unreadCount}</Badge>
                      )}
                    </TabsTrigger>
                  </TabsList>
                </Tabs>
              </div>
              {unreadCount > 0 && (
                <Button variant="ghost" onClick={handleMarkAllAsRead}>
                  Mark all as read
                </Button>
              )}
            </div>
          </div>

          {/* Notifications List */}
          <ScrollArea className="h-[calc(100vh-320px)]">
            <div className="space-y-4">
              {filteredNotifications.length === 0 ? (
                <div className="bg-white dark:bg-slate-800 rounded-xl p-12 border border-border text-center">
                  <Bell className="w-12 h-12 mx-auto mb-4 text-gray-400" />
                  <h3 className="mb-2">No notifications</h3>
                  <p className="text-gray-600 dark:text-gray-400">
                    You're all caught up! No new notifications to display.
                  </p>
                </div>
              ) : (
                filteredNotifications.map((notification) => (
                  <div
                    key={notification.id}
                    className={`rounded-xl p-6 border ${getBackgroundColor(
                      notification.type
                    )} ${!notification.read ? 'shadow-md' : ''}`}
                  >
                    <div className="flex items-start gap-4">
                      <div className="flex-shrink-0 mt-1">{getIcon(notification.type)}</div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-4 mb-2">
                          <div className="flex-1">
                            <h4 className="mb-1">
                              {notification.title}
                              {!notification.read && (
                                <Badge className="ml-2 bg-blue-500">New</Badge>
                              )}
                            </h4>
                            <p className="text-gray-700 dark:text-gray-300">
                              {notification.message}
                            </p>
                          </div>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleDismiss(notification.id)}
                            className="flex-shrink-0"
                          >
                            <X className="w-4 h-4" />
                          </Button>
                        </div>
                        <div className="flex items-center justify-between gap-4 mt-4">
                          <p className="text-sm text-gray-500 dark:text-gray-400">
                            {notification.timestamp}
                          </p>
                          <div className="flex gap-2">
                            {!notification.read && (
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handleMarkAsRead(notification.id)}
                              >
                                Mark as read
                              </Button>
                            )}
                            {notification.type === 'expiration' && (
                              <Button size="sm" className="bg-orange-500 hover:bg-orange-600">
                                Extend Link
                              </Button>
                            )}
                            {notification.type === 'curation' && (
                              <Button size="sm" variant="outline">
                                View Project
                              </Button>
                            )}
                            {notification.type === 'milestone' && (
                              <Button size="sm" variant="outline">
                                View Analytics
                              </Button>
                            )}
                            {notification.type === 'access' && (
                              <Button size="sm" variant="outline">
                                View Details
                              </Button>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </ScrollArea>

          {/* Settings Link */}
          <div className="text-center">
            <Button variant="link" className="text-gray-600 dark:text-gray-400">
              Manage notification preferences →
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
