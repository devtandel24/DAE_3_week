
  # Student Project Archiving System

  This is a code bundle for Student Project Archiving System. The original project is available at https://www.figma.com/design/ueTphCUoyEVebd9EVL2jHA/Student-Project-Archiving-System.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  