import { useState } from 'react';
import { Trash2, Edit2, Check, X, Bookmark, Share2 } from 'lucide-react';
import { useCollectionsStore } from '../lib/collectionsStore';
import { mockProjects } from '../lib/mockData';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { EmptyState } from './EmptyState';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from './ui/alert-dialog';
import { toast } from 'sonner@2.0.3';

interface CollectionsPageProps {
  onViewCollection: (collectionId: string) => void;
  onCreateShareLink: (collectionId: string) => void;
  onBackToGallery: () => void;
}

export function CollectionsPage({ onViewCollection, onCreateShareLink, onBackToGallery }: CollectionsPageProps) {
  const { collections, deleteCollection, renameCollection } = useCollectionsStore();
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editName, setEditName] = useState('');
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  const collectionsList = Object.values(collections);

  const startEdit = (collectionId: string, currentName: string) => {
    setEditingId(collectionId);
    setEditName(currentName);
  };

  const saveEdit = (collectionId: string) => {
    if (editName.trim()) {
      renameCollection(collectionId, editName.trim());
      toast.success('Collection renamed');
    }
    setEditingId(null);
    setEditName('');
  };

  const cancelEdit = () => {
    setEditingId(null);
    setEditName('');
  };

  const handleDelete = (collectionId: string) => {
    deleteCollection(collectionId);
    setDeleteConfirmId(null);
    toast.success('Collection deleted');
  };

  const getCollectionThumbnails = (projectIds: string[]) => {
    const projects = projectIds
      .map((id) => mockProjects.find((p) => p.id === id))
      .filter(Boolean)
      .slice(0, 4);
    return projects;
  };

  if (collectionsList.length === 0) {
    return (
      <div className="min-h-screen bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="mb-8">
            <h1>My Collections</h1>
            <p className="text-muted-foreground">Save and organize your favorite projects</p>
          </div>
          <EmptyState
            icon={Bookmark}
            title="No saved projects yet"
            description="Start exploring and save projects to collections for easy access later."
            actionLabel="Browse Projects"
            onAction={onBackToGallery}
          />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1>My Collections</h1>
          <p className="text-muted-foreground">
            {collectionsList.length} collection{collectionsList.length !== 1 ? 's' : ''}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {collectionsList.map((collection) => {
            const thumbnails = getCollectionThumbnails(collection.projectIds);
            const isEditing = editingId === collection.id;

            return (
              <div
                key={collection.id}
                className="bg-card border border-border rounded-xl overflow-hidden hover:shadow-lg transition-shadow"
              >
                {/* Thumbnail Mosaic */}
                <div
                  className="h-48 bg-muted relative cursor-pointer"
                  onClick={() => !isEditing && onViewCollection(collection.id)}
                >
                  {thumbnails.length === 0 ? (
                    <div className="w-full h-full flex items-center justify-center text-muted-foreground">
                      Empty Collection
                    </div>
                  ) : thumbnails.length === 1 ? (
                    <img
                      src={thumbnails[0]?.thumbnail}
                      alt=""
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="grid grid-cols-2 gap-0.5 h-full">
                      {thumbnails.map((project, idx) => (
                        <img
                          key={idx}
                          src={project?.thumbnail}
                          alt=""
                          className="w-full h-full object-cover"
                        />
                      ))}
                    </div>
                  )}
                  
                  {/* Project Count Badge */}
                  <div className="absolute bottom-2 right-2 bg-primary text-primary-foreground px-3 py-1 rounded-full text-sm">
                    {collection.projectIds.length} {collection.projectIds.length === 1 ? 'Project' : 'Projects'}
                  </div>
                </div>

                {/* Collection Info */}
                <div className="p-4 space-y-3">
                  {isEditing ? (
                    <div className="flex items-center gap-2">
                      <Input
                        value={editName}
                        onChange={(e) => setEditName(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') saveEdit(collection.id);
                          if (e.key === 'Escape') cancelEdit();
                        }}
                        className="h-9"
                        autoFocus
                      />
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => saveEdit(collection.id)}
                        className="h-9 w-9 p-0"
                      >
                        <Check className="w-4 h-4" />
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={cancelEdit}
                        className="h-9 w-9 p-0"
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                  ) : (
                    <h3 className="truncate">{collection.name}</h3>
                  )}

                  <div className="space-y-2">
                    <Button
                      size="sm"
                      className="w-full bg-gradient-to-r from-[#7C3AED] to-[#EC4899] hover:opacity-90 text-white"
                      onClick={() => onCreateShareLink(collection.id)}
                    >
                      <Share2 className="w-4 h-4 mr-2" />
                      Create Share Link
                    </Button>
                    <div className="flex items-center gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => startEdit(collection.id, collection.name)}
                        className="flex-1"
                      >
                        <Edit2 className="w-4 h-4 mr-2" />
                        Rename
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => setDeleteConfirmId(collection.id)}
                        className="flex-1 text-destructive hover:text-destructive"
                      >
                        <Trash2 className="w-4 h-4 mr-2" />
                        Delete
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={deleteConfirmId !== null} onOpenChange={() => setDeleteConfirmId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Collection?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete this collection.
              The projects themselves will not be affected.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => deleteConfirmId && handleDelete(deleteConfirmId)}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
