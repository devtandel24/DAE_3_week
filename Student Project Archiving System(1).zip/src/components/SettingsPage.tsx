import { useState } from 'react';
import { User, Shield, Bell, FileText, Key, Database, Download } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Switch } from './ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Card } from './ui/card';
import { Separator } from './ui/separator';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from './ui/table';

interface SettingsPageProps {
  onBack: () => void;
}

export function SettingsPage({ onBack }: SettingsPageProps) {
  const [emailNotifications, setEmailNotifications] = useState(true);
  const [linkAccessAlerts, setLinkAccessAlerts] = useState(true);
  const [expirationWarnings, setExpirationWarnings] = useState(true);
  const [autoArchive, setAutoArchive] = useState(false);

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-slate-900">
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-5xl mx-auto space-y-6">
          {/* Header */}
          <div className="flex items-center justify-between">
            <div>
              <h1 className="mb-2">Settings & Compliance</h1>
              <p className="text-gray-600 dark:text-gray-400">
                Manage your account settings and compliance policies
              </p>
            </div>
            <Button variant="ghost" onClick={onBack}>
              ← Back
            </Button>
          </div>

          {/* Tabbed Interface */}
          <Tabs defaultValue="profile" className="space-y-6">
            <TabsList className="grid w-full grid-cols-5">
              <TabsTrigger value="profile">
                <User className="w-4 h-4 mr-2" />
                Profile
              </TabsTrigger>
              <TabsTrigger value="notifications">
                <Bell className="w-4 h-4 mr-2" />
                Notifications
              </TabsTrigger>
              <TabsTrigger value="retention">
                <Database className="w-4 h-4 mr-2" />
                Data Retention
              </TabsTrigger>
              <TabsTrigger value="security">
                <Shield className="w-4 h-4 mr-2" />
                Security
              </TabsTrigger>
              <TabsTrigger value="policies">
                <FileText className="w-4 h-4 mr-2" />
                Policies
              </TabsTrigger>
            </TabsList>

            {/* Profile Tab */}
            <TabsContent value="profile">
              <Card className="p-6 space-y-6">
                <div>
                  <h3 className="mb-4">User Information</h3>
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="name">Full Name</Label>
                        <Input id="name" defaultValue="Admin User" />
                      </div>
                      <div>
                        <Label htmlFor="email">Email</Label>
                        <Input id="email" defaultValue="admin@dae.com" disabled />
                      </div>
                    </div>
                    <div>
                      <Label htmlFor="role">Role</Label>
                      <Input id="role" defaultValue="Administrator" disabled />
                    </div>
                  </div>
                </div>

                <Separator />

                <div>
                  <h3 className="mb-4">Change Password</h3>
                  <div className="space-y-4 max-w-md">
                    <div>
                      <Label htmlFor="current-password">Current Password</Label>
                      <Input id="current-password" type="password" />
                    </div>
                    <div>
                      <Label htmlFor="new-password">New Password</Label>
                      <Input id="new-password" type="password" />
                    </div>
                    <div>
                      <Label htmlFor="confirm-password">Confirm New Password</Label>
                      <Input id="confirm-password" type="password" />
                    </div>
                    <Button className="bg-gradient-to-r from-[#7C3AED] to-[#EC4899] hover:opacity-90">
                      Update Password
                    </Button>
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      Passwords must be changed every 90 days
                    </p>
                  </div>
                </div>
              </Card>
            </TabsContent>

            {/* Notifications Tab */}
            <TabsContent value="notifications">
              <Card className="p-6 space-y-6">
                <div>
                  <h3 className="mb-4">Email Notifications</h3>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-4 border border-border rounded-lg">
                      <div>
                        <p className="font-medium">Enable Email Notifications</p>
                        <p className="text-sm text-gray-600 dark:text-gray-400">
                          Receive email updates about platform activities
                        </p>
                      </div>
                      <Switch checked={emailNotifications} onCheckedChange={setEmailNotifications} />
                    </div>

                    <div className="flex items-center justify-between p-4 border border-border rounded-lg">
                      <div>
                        <p className="font-medium">Link Access Alerts</p>
                        <p className="text-sm text-gray-600 dark:text-gray-400">
                          Notify me when shared links are accessed
                        </p>
                      </div>
                      <Switch checked={linkAccessAlerts} onCheckedChange={setLinkAccessAlerts} />
                    </div>

                    <div className="flex items-center justify-between p-4 border border-border rounded-lg">
                      <div>
                        <p className="font-medium">Expiration Warnings</p>
                        <p className="text-sm text-gray-600 dark:text-gray-400">
                          Alert me 7 days before links expire
                        </p>
                      </div>
                      <Switch checked={expirationWarnings} onCheckedChange={setExpirationWarnings} />
                    </div>
                  </div>
                </div>
              </Card>
            </TabsContent>

            {/* Data Retention Tab */}
            <TabsContent value="retention" className="space-y-6">
              <Card className="p-6">
                <h3 className="mb-4">Retention Policy</h3>
                <div className="space-y-4">
                  <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg border border-blue-200 dark:border-blue-800">
                    <p className="font-medium mb-2">Student Records</p>
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      Student project records are retained for <strong>7 years</strong> from completion date
                    </p>
                  </div>
                  <div className="p-4 bg-purple-50 dark:bg-purple-900/20 rounded-lg border border-purple-200 dark:border-purple-800">
                    <p className="font-medium mb-2">Marketing Records</p>
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      Marketing and showcase records retained for <strong>5 years minimum</strong>
                    </p>
                  </div>
                </div>
              </Card>

              <Card className="p-6">
                <h3 className="mb-4">Projects Approaching Expiration</h3>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Project Title</TableHead>
                      <TableHead>Completion Date</TableHead>
                      <TableHead>Expiration Date</TableHead>
                      <TableHead>Days Until Expiration</TableHead>
                      <TableHead>Action</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <TableRow>
                      <TableCell>Smart City Dashboard</TableCell>
                      <TableCell>Dec 15, 2018</TableCell>
                      <TableCell>Dec 15, 2025</TableCell>
                      <TableCell>334 days</TableCell>
                      <TableCell>
                        <Button variant="outline" size="sm">Review</Button>
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell>E-Commerce Platform</TableCell>
                      <TableCell>May 20, 2018</TableCell>
                      <TableCell>May 20, 2025</TableCell>
                      <TableCell>125 days</TableCell>
                      <TableCell>
                        <Button variant="outline" size="sm">Review</Button>
                      </TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </Card>

              <Card className="p-6">
                <h3 className="mb-4">Automated Archival Settings</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 border border-border rounded-lg">
                    <div>
                      <p className="font-medium">Auto-archive after retention period</p>
                      <p className="text-sm text-gray-600 dark:text-gray-400">
                        Automatically archive projects when they reach 7 years
                      </p>
                    </div>
                    <Switch checked={autoArchive} onCheckedChange={setAutoArchive} />
                  </div>
                </div>
              </Card>
            </TabsContent>

            {/* Security Tab */}
            <TabsContent value="security">
              <Card className="p-6 space-y-6">
                <div>
                  <h3 className="mb-4">Password Requirements</h3>
                  <div className="p-4 bg-gray-50 dark:bg-slate-800 rounded-lg space-y-2">
                    <p className="text-sm">• Minimum 12 characters</p>
                    <p className="text-sm">• At least one uppercase letter</p>
                    <p className="text-sm">• At least one number</p>
                    <p className="text-sm">• At least one special character</p>
                    <p className="text-sm font-medium text-orange-600 dark:text-orange-400 mt-4">
                      ⚠️ Passwords must be changed every 90 days
                    </p>
                  </div>
                </div>

                <Separator />

                <div>
                  <h3 className="mb-4">Backup & Recovery</h3>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-4 border border-border rounded-lg">
                      <div>
                        <p className="font-medium">Last Backup</p>
                        <p className="text-sm text-gray-600 dark:text-gray-400">
                          Today at 2:00 AM EST
                        </p>
                      </div>
                      <Download className="w-5 h-5 text-gray-400" />
                    </div>
                    <div className="flex items-center justify-between p-4 border border-border rounded-lg">
                      <div>
                        <p className="font-medium">Backup Frequency</p>
                        <p className="text-sm text-gray-600 dark:text-gray-400">
                          Daily (automated)
                        </p>
                      </div>
                      <Shield className="w-5 h-5 text-green-500" />
                    </div>
                  </div>
                </div>
              </Card>
            </TabsContent>

            {/* Policies Tab */}
            <TabsContent value="policies">
              <Card className="p-6 space-y-6">
                <div>
                  <h3 className="mb-4">Policy Documents</h3>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-4 border border-border rounded-lg">
                      <div>
                        <p className="font-medium">Privacy Policy</p>
                        <p className="text-sm text-gray-600 dark:text-gray-400">
                          Last updated: January 1, 2025
                        </p>
                      </div>
                      <Button variant="outline">View</Button>
                    </div>
                    <div className="flex items-center justify-between p-4 border border-border rounded-lg">
                      <div>
                        <p className="font-medium">Terms of Use</p>
                        <p className="text-sm text-gray-600 dark:text-gray-400">
                          Last updated: January 1, 2025
                        </p>
                      </div>
                      <Button variant="outline">View</Button>
                    </div>
                    <div className="flex items-center justify-between p-4 border border-border rounded-lg">
                      <div>
                        <p className="font-medium">Terms and Conditions</p>
                        <p className="text-sm text-gray-600 dark:text-gray-400">
                          Last updated: January 1, 2025
                        </p>
                      </div>
                      <Button variant="outline">View</Button>
                    </div>
                    <div className="flex items-center justify-between p-4 border border-border rounded-lg">
                      <div>
                        <p className="font-medium">FERPA Compliance Guidelines</p>
                        <p className="text-sm text-gray-600 dark:text-gray-400">
                          Student privacy protection standards
                        </p>
                      </div>
                      <Button variant="outline">View</Button>
                    </div>
                  </div>
                </div>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}
