import { create } from 'zustand';

export interface Collection {
  id: string;
  name: string;
  projectIds: string[];
  createdAt: Date;
}

interface CollectionsState {
  collections: Record<string, Collection>;
  githubDisclaimerAccepted: Record<string, boolean>;
  
  // Collections methods
  createCollection: (name: string) => string;
  addToCollection: (projectId: string, collectionId: string) => void;
  removeFromCollection: (projectId: string, collectionId: string) => void;
  deleteCollection: (collectionId: string) => void;
  renameCollection: (collectionId: string, newName: string) => void;
  isProjectInCollection: (projectId: string, collectionId: string) => boolean;
  getCollectionsForProject: (projectId: string) => Collection[];
  
  // GitHub disclaimer methods
  acceptGitHubDisclaimer: (projectId: string) => void;
  hasAcceptedGitHubDisclaimer: (projectId: string) => boolean;
}

export const useCollectionsStore = create<CollectionsState>((set, get) => ({
  collections: {},
  githubDisclaimerAccepted: {},
  
  createCollection: (name: string) => {
    const id = `collection_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
    const newCollection: Collection = {
      id,
      name,
      projectIds: [],
      createdAt: new Date(),
    };
    
    set((state) => ({
      collections: {
        ...state.collections,
        [id]: newCollection,
      },
    }));
    
    return id;
  },
  
  addToCollection: (projectId: string, collectionId: string) => {
    set((state) => {
      const collection = state.collections[collectionId];
      if (!collection) return state;
      
      // Avoid duplicates
      if (collection.projectIds.includes(projectId)) return state;
      
      return {
        collections: {
          ...state.collections,
          [collectionId]: {
            ...collection,
            projectIds: [...collection.projectIds, projectId],
          },
        },
      };
    });
  },
  
  removeFromCollection: (projectId: string, collectionId: string) => {
    set((state) => {
      const collection = state.collections[collectionId];
      if (!collection) return state;
      
      return {
        collections: {
          ...state.collections,
          [collectionId]: {
            ...collection,
            projectIds: collection.projectIds.filter((id) => id !== projectId),
          },
        },
      };
    });
  },
  
  deleteCollection: (collectionId: string) => {
    set((state) => {
      const newCollections = { ...state.collections };
      delete newCollections[collectionId];
      return { collections: newCollections };
    });
  },
  
  renameCollection: (collectionId: string, newName: string) => {
    set((state) => {
      const collection = state.collections[collectionId];
      if (!collection) return state;
      
      return {
        collections: {
          ...state.collections,
          [collectionId]: {
            ...collection,
            name: newName,
          },
        },
      };
    });
  },
  
  isProjectInCollection: (projectId: string, collectionId: string) => {
    const collection = get().collections[collectionId];
    return collection ? collection.projectIds.includes(projectId) : false;
  },
  
  getCollectionsForProject: (projectId: string) => {
    const collections = get().collections;
    return Object.values(collections).filter((collection) =>
      collection.projectIds.includes(projectId)
    );
  },
  
  acceptGitHubDisclaimer: (projectId: string) => {
    set((state) => ({
      githubDisclaimerAccepted: {
        ...state.githubDisclaimerAccepted,
        [projectId]: true,
      },
    }));
  },
  
  hasAcceptedGitHubDisclaimer: (projectId: string) => {
    return get().githubDisclaimerAccepted[projectId] || false;
  },
}));
