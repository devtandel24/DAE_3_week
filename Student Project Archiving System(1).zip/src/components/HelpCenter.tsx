import { useState } from 'react';
import { Search, BookOpen, Share2, BarChart3, Shield, Settings as SettingsIcon, ChevronRight, Mail } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from './ui/accordion';
import { Card } from './ui/card';

interface HelpCenterProps {
  onBack: () => void;
}

export function HelpCenter({ onBack }: HelpCenterProps) {
  const [searchQuery, setSearchQuery] = useState('');

  const categories = [
    {
      id: 'getting-started',
      title: 'Getting Started',
      icon: <BookOpen className="w-5 h-5" />,
      articles: [
        { title: 'Creating your first shared link', duration: '3 min read' },
        { title: 'Understanding the interface', duration: '5 min read' },
        { title: 'User roles explained', duration: '4 min read' },
      ],
    },
    {
      id: 'browsing',
      title: 'Browsing Projects',
      icon: <Search className="w-5 h-5" />,
      articles: [
        { title: 'Using filters effectively', duration: '4 min read' },
        { title: 'Understanding project complexity levels', duration: '3 min read' },
        { title: 'Reading project metadata', duration: '3 min read' },
      ],
    },
    {
      id: 'sharing',
      title: 'Sharing Projects',
      icon: <Share2 className="w-5 h-5" />,
      articles: [
        { title: 'Creating shareable links', duration: '5 min read' },
        { title: 'Setting expiration dates', duration: '3 min read' },
        { title: 'Managing active links', duration: '4 min read' },
        { title: 'Understanding view-only access', duration: '3 min read' },
      ],
    },
    {
      id: 'analytics',
      title: 'Analytics',
      icon: <BarChart3 className="w-5 h-5" />,
      articles: [
        { title: 'Reading the dashboard', duration: '5 min read' },
        { title: 'Understanding metrics', duration: '4 min read' },
        { title: 'Exporting data', duration: '3 min read' },
      ],
    },
    {
      id: 'compliance',
      title: 'Compliance',
      icon: <Shield className="w-5 h-5" />,
      articles: [
        { title: 'Data retention policies', duration: '6 min read' },
        { title: 'Student privacy guidelines', duration: '5 min read' },
        { title: 'Audit log access', duration: '4 min read' },
        { title: 'FERPA compliance', duration: '7 min read' },
      ],
    },
  ];

  const faqs = [
    {
      question: 'How long do shared links last?',
      answer: 'Shared links can be set to expire after 7, 14, 30, or 90 days. You can also create permanent links for educational use. You will receive notifications before links expire.',
    },
    {
      question: 'Can I see who accessed my shared links?',
      answer: 'Yes! Each shared link has detailed analytics showing view counts, unique visitors, and access times. You can enable notifications to be alerted when links are accessed.',
    },
    {
      question: 'What is the Top 150 showcase?',
      answer: 'The Top 150 showcase features our most impressive student projects. Only 3% of projects meet the curation threshold. Projects in the Top 150 receive additional visibility and recognition.',
    },
    {
      question: 'How do I protect student privacy?',
      answer: 'By default, student names are not displayed in public shared links. All projects show only contextual information (year, program type, specialization). Student names are visible only to authenticated administrators.',
    },
    {
      question: 'Can I download projects from shared links?',
      answer: 'No. All shared links are view-only to protect student intellectual property. Projects can only be viewed in the browser, not downloaded.',
    },
    {
      question: 'What happens to projects after 7 years?',
      answer: 'Student projects are retained for 7 years as part of our data retention policy. You will receive notifications 30 days before expiration, and can choose to archive, extend, or delete projects.',
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-slate-900">
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto space-y-8">
          {/* Header */}
          <div className="flex items-center justify-between">
            <div>
              <h1 className="mb-2">Help Center</h1>
              <p className="text-gray-600 dark:text-gray-400">
                Find answers and learn how to use the platform
              </p>
            </div>
            <Button variant="ghost" onClick={onBack}>
              ← Back
            </Button>
          </div>

          {/* Search Bar */}
          <Card className="p-6">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <Input
                placeholder="What do you need help with?"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-12 text-lg h-14"
              />
            </div>
          </Card>

          {/* Categories */}
          <div>
            <h2 className="mb-4">Browse by Category</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {categories.map((category) => (
                <Card key={category.id} className="p-6 hover:shadow-lg transition-shadow cursor-pointer">
                  <div className="flex items-start gap-4">
                    <div className="p-3 bg-purple-100 dark:bg-purple-900/30 rounded-lg text-purple-600 dark:text-purple-400">
                      {category.icon}
                    </div>
                    <div className="flex-1">
                      <h3 className="mb-2">{category.title}</h3>
                      <ul className="space-y-2">
                        {category.articles.map((article, idx) => (
                          <li key={idx} className="flex items-center justify-between text-sm group">
                            <span className="text-gray-600 dark:text-gray-400 group-hover:text-purple-600 dark:group-hover:text-purple-400">
                              {article.title}
                            </span>
                            <ChevronRight className="w-4 h-4 text-gray-400 group-hover:text-purple-600" />
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </div>

          {/* FAQ Section */}
          <div>
            <h2 className="mb-4">Frequently Asked Questions</h2>
            <Card className="p-6">
              <Accordion type="single" collapsible>
                {faqs.map((faq, idx) => (
                  <AccordionItem key={idx} value={`faq-${idx}`}>
                    <AccordionTrigger>{faq.question}</AccordionTrigger>
                    <AccordionContent>
                      <p className="text-gray-600 dark:text-gray-400">{faq.answer}</p>
                    </AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            </Card>
          </div>

          {/* Video Tutorials */}
          <div>
            <h2 className="mb-4">Video Tutorials</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {[
                { title: 'How to Create a Shared Link', duration: '3:45' },
                { title: 'Using Filters to Find Projects', duration: '2:30' },
                { title: 'Understanding Analytics', duration: '4:15' },
              ].map((video, idx) => (
                <Card key={idx} className="overflow-hidden hover:shadow-lg transition-shadow cursor-pointer">
                  <div className="aspect-video bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
                    <div className="w-16 h-16 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center">
                      <div className="w-0 h-0 border-t-8 border-t-transparent border-l-12 border-l-white border-b-8 border-b-transparent ml-1"></div>
                    </div>
                  </div>
                  <div className="p-4">
                    <p className="font-medium mb-1">{video.title}</p>
                    <p className="text-sm text-gray-600 dark:text-gray-400">{video.duration}</p>
                  </div>
                </Card>
              ))}
            </div>
          </div>

          {/* Contact Support */}
          <Card className="p-8 bg-gradient-to-r from-purple-50 to-pink-50 dark:from-purple-900/20 dark:to-pink-900/20">
            <div className="text-center max-w-2xl mx-auto">
              <Mail className="w-12 h-12 mx-auto mb-4 text-purple-600 dark:text-purple-400" />
              <h3 className="mb-2">Still need help?</h3>
              <p className="text-gray-600 dark:text-gray-400 mb-6">
                Can't find what you're looking for? Our support team is here to help.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button className="bg-gradient-to-r from-[#7C3AED] to-[#EC4899] hover:opacity-90">
                  Contact Support
                </Button>
                <Button variant="outline">Submit a Ticket</Button>
              </div>
              <p className="text-sm text-gray-500 dark:text-gray-400 mt-4">
                Email: support@dae.org
              </p>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
