import { useState } from 'react';
import { Plus, Check } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from './ui/dialog';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Checkbox } from './ui/checkbox';
import { useCollectionsStore } from '../lib/collectionsStore';
import { toast } from 'sonner@2.0.3';

interface SaveToCollectionModalProps {
  projectId: string;
  projectTitle: string;
  isOpen: boolean;
  onClose: () => void;
}

export function SaveToCollectionModal({
  projectId,
  projectTitle,
  isOpen,
  onClose,
}: SaveToCollectionModalProps) {
  const { collections, createCollection, addToCollection, isProjectInCollection } = useCollectionsStore();
  const [showNewCollection, setShowNewCollection] = useState(false);
  const [newCollectionName, setNewCollectionName] = useState('');
  const [selectedCollections, setSelectedCollections] = useState<Set<string>>(new Set());

  const collectionsList = Object.values(collections);

  const handleSave = () => {
    // Add to selected existing collections
    selectedCollections.forEach((collectionId) => {
      addToCollection(projectId, collectionId);
    });

    // Create new collection if needed
    if (showNewCollection && newCollectionName.trim()) {
      const newId = createCollection(newCollectionName.trim());
      addToCollection(projectId, newId);
    }

    const count = selectedCollections.size + (showNewCollection && newCollectionName.trim() ? 1 : 0);
    if (count > 0) {
      toast.success(`Added to ${count} collection${count > 1 ? 's' : ''}`);
    }

    // Reset and close
    setSelectedCollections(new Set());
    setShowNewCollection(false);
    setNewCollectionName('');
    onClose();
  };

  const toggleCollection = (collectionId: string) => {
    const newSet = new Set(selectedCollections);
    if (newSet.has(collectionId)) {
      newSet.delete(collectionId);
    } else {
      newSet.add(collectionId);
    }
    setSelectedCollections(newSet);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Save to Collection</DialogTitle>
          <DialogDescription>
            Save "{projectTitle}" to one or more collections
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          {/* Existing Collections */}
          {collectionsList.length > 0 && (
            <div className="space-y-2">
              <p className="text-sm text-muted-foreground">Existing Collections</p>
              <div className="max-h-[200px] overflow-y-auto space-y-2">
                {collectionsList.map((collection) => {
                  const alreadyInCollection = isProjectInCollection(projectId, collection.id);
                  return (
                    <div
                      key={collection.id}
                      className="flex items-center space-x-3 p-3 rounded-lg border hover:bg-muted/50 transition-colors"
                    >
                      <Checkbox
                        id={collection.id}
                        checked={selectedCollections.has(collection.id) || alreadyInCollection}
                        onCheckedChange={() => !alreadyInCollection && toggleCollection(collection.id)}
                        disabled={alreadyInCollection}
                      />
                      <label
                        htmlFor={collection.id}
                        className="flex-1 cursor-pointer select-none flex items-center justify-between"
                      >
                        <span className={alreadyInCollection ? 'text-muted-foreground' : ''}>
                          {collection.name}
                        </span>
                        {alreadyInCollection && (
                          <span className="text-xs text-primary flex items-center gap-1">
                            <Check className="w-3 h-3" />
                            Already saved
                          </span>
                        )}
                      </label>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Create New Collection */}
          <div className="space-y-2">
            {!showNewCollection ? (
              <Button
                type="button"
                variant="outline"
                className="w-full"
                onClick={() => setShowNewCollection(true)}
              >
                <Plus className="w-4 h-4 mr-2" />
                Create New Collection
              </Button>
            ) : (
              <div className="space-y-2">
                <p className="text-sm text-muted-foreground">New Collection</p>
                <Input
                  placeholder="Enter collection name..."
                  value={newCollectionName}
                  onChange={(e) => setNewCollectionName(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && newCollectionName.trim()) {
                      handleSave();
                    }
                  }}
                  autoFocus
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  onClick={() => {
                    setShowNewCollection(false);
                    setNewCollectionName('');
                  }}
                >
                  Cancel
                </Button>
              </div>
            )}
          </div>
        </div>

        {/* Actions */}
        <div className="flex justify-end gap-3">
          <Button type="button" variant="ghost" onClick={onClose}>
            Cancel
          </Button>
          <Button
            type="button"
            onClick={handleSave}
            disabled={selectedCollections.size === 0 && (!showNewCollection || !newCollectionName.trim())}
            className="bg-gradient-to-r from-[#7C3AED] to-[#EC4899] hover:opacity-90"
          >
            Save
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
