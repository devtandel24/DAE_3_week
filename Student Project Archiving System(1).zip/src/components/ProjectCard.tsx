import { User, Bookmark } from 'lucide-react';
import { useState } from 'react';
import { Badge } from './ui/badge';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { Project } from '../lib/mockData';
import { SaveToCollectionModal } from './SaveToCollectionModal';
import { useCollectionsStore } from '../lib/collectionsStore';

interface ProjectCardProps {
  project: Project;
  onClick: () => void;
  hideStudentInfo?: boolean;
  hideActions?: boolean;
}

const getCategoryColor = (category: Project['category']) => {
  switch (category) {
    case 'WEB DEV':
      return 'bg-blue-500 text-white';
    case 'CYBERSECURITY':
      return 'bg-red-500 text-white';
    case 'GAME DEV':
      return 'bg-green-500 text-white';
    case 'IoT':
      return 'bg-orange-500 text-white';
    case 'AI & DATA SCIENCE':
      return 'bg-purple-500 text-white';
    default:
      return 'bg-gray-500 text-white';
  }
};

const getLevelColor = (level: Project['level']) => {
  switch (level) {
    case 'Beginner':
      return 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-300';
    case 'Intermediate':
      return 'bg-yellow-100 text-yellow-700 dark:bg-yellow-900/30 dark:text-yellow-300';
    case 'Advanced':
      return 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300';
    default:
      return 'bg-gray-100 text-gray-700 dark:bg-gray-900/30 dark:text-gray-300';
  }
};

export function ProjectCard({ project, onClick, hideStudentInfo = false, hideActions = false }: ProjectCardProps) {
  const [showSaveModal, setShowSaveModal] = useState(false);
  const { getCollectionsForProject } = useCollectionsStore();
  
  // Format program type with duration
  const programInfo = project.programType === 'High School' 
    ? `HS ${project.programDuration || ''}` 
    : `Adult ${project.programDuration || ''}`;

  const savedCollections = getCollectionsForProject(project.id);
  const isSaved = savedCollections.length > 0;

  const handleBookmarkClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    setShowSaveModal(true);
  };

  return (
    <>
      <div
        onClick={onClick}
        className="group w-full bg-white dark:bg-slate-800 rounded-xl border border-border overflow-hidden transition-all duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-purple-500/20 hover:border-purple-500 cursor-pointer relative"
      >
        <div className="aspect-video w-full overflow-hidden bg-gray-100 dark:bg-gray-900 relative">
          <ImageWithFallback
            src={project.thumbnail}
            alt={project.title}
            className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
          />
          {/* Category badge overlay */}
          <div className="absolute top-2 right-2">
            <Badge className={`${getCategoryColor(project.category)} text-xs`}>
              {project.category}
            </Badge>
          </div>
          {/* Level badge overlay */}
          <div className="absolute top-2 left-2">
            <Badge className={`${getLevelColor(project.level)} text-xs`}>
              {project.level}
            </Badge>
          </div>
          
          {/* Bookmark Button */}
          {!hideActions && (
            <button
              onClick={handleBookmarkClick}
              className="absolute bottom-2 right-2 bg-white dark:bg-slate-800 p-2 rounded-full shadow-lg hover:scale-110 transition-transform border border-border"
              title={isSaved ? `Saved to ${savedCollections.length} collection(s)` : 'Save to collection'}
            >
              <Bookmark
                className={`w-4 h-4 ${isSaved ? 'fill-primary text-primary' : 'text-muted-foreground'}`}
              />
            </button>
          )}
        </div>

      <div className="p-4 space-y-3">
        <h3 className="line-clamp-2 min-h-[3rem]">
          {project.title}
        </h3>

        {!hideStudentInfo && (
          <div className="flex items-center gap-2 text-gray-600 dark:text-gray-400 text-sm">
            <User className="w-4 h-4 flex-shrink-0" />
            <span className="truncate">{project.student}</span>
          </div>
        )}

        {/* Program details row */}
        <div className="flex flex-wrap gap-2 text-xs">
          {project.studentYear && (
            <Badge variant="outline" className="text-xs">
              {project.studentYear}
            </Badge>
          )}
          <Badge variant="outline" className="text-xs">
            {programInfo.trim()}
          </Badge>
          <Badge variant="outline" className="text-xs">
            {project.location}
          </Badge>
        </div>

        {/* Short description */}
        <p className="text-sm text-gray-600 dark:text-gray-400 line-clamp-2">
          {project.description}
        </p>

        {/* Tech stack */}
        <div className="flex flex-wrap gap-2">
          {project.techStack.slice(0, 3).map((tech) => (
            <Badge
              key={tech}
              variant="secondary"
              className="bg-purple-100 dark:bg-purple-900/30 text-purple-700 dark:text-purple-300 hover:bg-purple-200 dark:hover:bg-purple-900/50 text-xs"
            >
              {tech}
            </Badge>
          ))}
          {project.techStack.length > 3 && (
            <Badge
              variant="secondary"
              className="bg-gray-100 dark:bg-gray-900/30 text-gray-600 dark:text-gray-400 text-xs"
            >
              +{project.techStack.length - 3}
            </Badge>
          )}
        </div>

        {/* Job Roles - if available */}
        {project.jobRoles && project.jobRoles.length > 0 && (
          <div className="flex flex-wrap gap-2 pt-1">
            {project.jobRoles.slice(0, 2).map((role) => (
              <Badge
                key={role}
                variant="outline"
                className="text-xs bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-300 border-blue-200 dark:border-blue-800"
              >
                {role}
              </Badge>
            ))}
            {project.jobRoles.length > 2 && (
              <Badge variant="outline" className="text-xs">
                +{project.jobRoles.length - 2} more
              </Badge>
            )}
          </div>
        )}
      </div>
    </div>

    {/* Save to Collection Modal */}
    <SaveToCollectionModal
      projectId={project.id}
      projectTitle={project.title}
      isOpen={showSaveModal}
      onClose={() => setShowSaveModal(false)}
    />
  </>
  );
}
