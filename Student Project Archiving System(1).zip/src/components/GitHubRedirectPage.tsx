import { ExternalLink, ArrowLeft } from 'lucide-react';
import { Button } from './ui/button';

interface GitHubRedirectPageProps {
  projectTitle: string;
  githubUrl: string;
  onBack: () => void;
}

export function GitHubRedirectPage({
  projectTitle,
  githubUrl,
  onBack,
}: GitHubRedirectPageProps) {
  const handleProceed = () => {
    window.open(githubUrl, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50 dark:from-slate-900 dark:to-slate-800 flex items-center justify-center p-4">
      <div className="max-w-2xl w-full bg-white dark:bg-slate-800 rounded-xl shadow-lg border border-border p-8 space-y-6">
        <div className="space-y-2">
          <h2>You're viewing a student project on GitHub</h2>
          <p className="text-muted-foreground">
            "{projectTitle}"
          </p>
        </div>

        <div className="space-y-4 text-muted-foreground">
          <p>
            You'll see code, README, and artifacts the student published for learning and
            demonstration purposes.
          </p>

          <div className="bg-muted/50 border border-border rounded-lg p-4">
            <p className="text-foreground">
              <span className="font-medium">Future vision:</span> Every graduating student receives a DAE portfolio
              link that aggregates all their projects—shareable anywhere, anytime.
            </p>
          </div>
        </div>

        <div className="flex gap-3 pt-4">
          <Button
            variant="ghost"
            onClick={onBack}
            className="flex-1"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Project
          </Button>
          <Button
            onClick={handleProceed}
            className="flex-1 bg-gradient-to-r from-[#7C3AED] to-[#EC4899] hover:opacity-90"
          >
            Proceed to GitHub
            <ExternalLink className="w-4 h-4 ml-2" />
          </Button>
        </div>
      </div>
    </div>
  );
}
