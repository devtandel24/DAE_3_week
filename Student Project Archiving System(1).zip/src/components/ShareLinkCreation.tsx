import { useState, useMemo, useEffect } from 'react';
import { ChevronRight, Copy, QrCode, ExternalLink, Eye, Clock, Shield, X, SlidersHorizontal, Filter } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Checkbox } from './ui/checkbox';
import { Badge } from './ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from './ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from './ui/table';
import { Switch } from './ui/switch';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { mockProjects, FIXED_TRACKS, FIXED_LOCATIONS, FIXED_PROGRAM_TYPES, FIXED_JOB_ROLES } from '../lib/mockData';
import { useCollectionsStore } from '../lib/collectionsStore';
import { toast } from 'sonner@2.0.3';
import logoImage from 'figma:asset/5a41359254d30e34254c79b43c72d23d4047b129.png';
import { Separator } from './ui/separator';
import { ScrollArea } from './ui/scroll-area';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from './ui/accordion';
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from './ui/sheet';

interface ShareLinkCreationProps {
  onBack: () => void;
  onPreview?: () => void;
  collectionId?: string | null;
}

const categories = ['ALL', 'WEB DEV', 'CYBERSECURITY', 'GAME DEV', 'IoT', 'AI & DATA SCIENCE'];
const levels = ['Beginner', 'Intermediate', 'Advanced'];
const semesters = ['Spring', 'Summer', 'Fall', 'Winter'];

export function ShareLinkCreation({ onBack, onPreview, collectionId = null }: ShareLinkCreationProps) {
  const { collections } = useCollectionsStore();
  const [step, setStep] = useState(1);
  const [selectedProjects, setSelectedProjects] = useState<string[]>([]);
  const [theme, setTheme] = useState<'light' | 'dark'>('light');
  const [expiration, setExpiration] = useState('30');
  const [leadCapture, setLeadCapture] = useState(false);
  const [password, setPassword] = useState(false);
  const [passwordValue, setPasswordValue] = useState('');
  const [generatedLink, setGeneratedLink] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [filterOpen, setFilterOpen] = useState(false);
  
  // Filter states
  const [selectedCategories, setSelectedCategories] = useState<string[]>(['ALL']);
  const [selectedTechStack, setSelectedTechStack] = useState<string[]>([]);
  const [selectedFrameworks, setSelectedFrameworks] = useState<string[]>([]);
  const [selectedCohorts, setSelectedCohorts] = useState<string[]>([]);
  const [selectedIndustries, setSelectedIndustries] = useState<string[]>([]);
  const [selectedCourses, setSelectedCourses] = useState<string[]>([]);
  const [selectedLevels, setSelectedLevels] = useState<string[]>([]);
  const [selectedTracks, setSelectedTracks] = useState<string[]>([]);
  const [selectedThemes, setSelectedThemes] = useState<string[]>([]);
  const [selectedYears, setSelectedYears] = useState<number[]>([]);
  const [selectedSemesters, setSelectedSemesters] = useState<string[]>([]);
  const [selectedLocations, setSelectedLocations] = useState<string[]>([]);
  const [selectedProgramTypes, setSelectedProgramTypes] = useState<string[]>([]);
  const [selectedJobRoles, setSelectedJobRoles] = useState<string[]>([]);

  // Pre-select projects from collection if collectionId is provided
  useEffect(() => {
    if (collectionId && collections[collectionId]) {
      const collectionProjectIds = collections[collectionId].projectIds;
      setSelectedProjects(collectionProjectIds);
    }
  }, [collectionId, collections]);

  const toggleProject = (id: string) => {
    setSelectedProjects((prev) =>
      prev.includes(id) ? prev.filter((p) => p !== id) : [...prev, id]
    );
  };

  const toggleCategory = (category: string) => {
    if (category === 'ALL') {
      setSelectedCategories(['ALL']);
    } else {
      const newCategories = selectedCategories.includes(category)
        ? selectedCategories.filter((c) => c !== category)
        : [...selectedCategories.filter((c) => c !== 'ALL'), category];
      
      setSelectedCategories(newCategories.length === 0 ? ['ALL'] : newCategories);
    }
  };

  const toggleFilter = (value: string, selected: string[], setSelected: (value: string[]) => void) => {
    if (selected.includes(value)) {
      setSelected(selected.filter((v) => v !== value));
    } else {
      setSelected([...selected, value]);
    }
  };

  const toggleYearFilter = (value: number) => {
    if (selectedYears.includes(value)) {
      setSelectedYears(selectedYears.filter((v) => v !== value));
    } else {
      setSelectedYears([...selectedYears, value]);
    }
  };

  const handleGenerate = () => {
    const link = `https://share.dae.com/${Math.random().toString(36).substring(7)}`;
    setGeneratedLink(link);
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(generatedLink);
    toast.success('Link copied to clipboard!');
  };

  const clearAllFilters = () => {
    setSelectedTechStack([]);
    setSelectedFrameworks([]);
    setSelectedCohorts([]);
    setSelectedIndustries([]);
    setSelectedCourses([]);
    setSelectedLevels([]);
    setSelectedTracks([]);
    setSelectedThemes([]);
    setSelectedYears([]);
    setSelectedSemesters([]);
    setSelectedLocations([]);
    setSelectedProgramTypes([]);
    setSelectedJobRoles([]);
    setSearchQuery('');
    setSelectedCategories(['ALL']);
  };

  // Extract unique values for filters
  const allTechStack = useMemo(() => {
    const techs = new Set<string>();
    mockProjects.forEach(p => p.techStack.forEach(t => techs.add(t)));
    return Array.from(techs).sort();
  }, []);

  const allFrameworks = useMemo(() => {
    const frameworks = new Set<string>();
    mockProjects.forEach(p => p.frameworks.forEach(f => frameworks.add(f)));
    return Array.from(frameworks).sort();
  }, []);

  const allCohorts = useMemo(() => {
    const cohorts = new Set<string>();
    mockProjects.forEach(p => cohorts.add(p.cohort));
    return Array.from(cohorts).sort();
  }, []);

  const allIndustries = useMemo(() => {
    const industries = new Set<string>();
    mockProjects.forEach(p => industries.add(p.industry));
    return Array.from(industries).sort();
  }, []);

  const allCourses = useMemo(() => {
    const courses = new Set<string>();
    mockProjects.forEach(p => p.courses.forEach(c => courses.add(c)));
    return Array.from(courses).sort();
  }, []);

  const allThemes = useMemo(() => {
    const themes = new Set<string>();
    mockProjects.forEach(p => p.theme.forEach(t => themes.add(t)));
    return Array.from(themes).sort();
  }, []);

  const allYears = useMemo(() => {
    const years = new Set<number>();
    mockProjects.forEach(p => years.add(p.year));
    return Array.from(years).sort((a, b) => b - a);
  }, []);

  const filteredProjects = useMemo(() => {
    let filtered = mockProjects;

    if (searchQuery) {
      filtered = filtered.filter((project) =>
        project.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        project.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        project.student.toLowerCase().includes(searchQuery.toLowerCase()) ||
        project.techStack.some((tech) => tech.toLowerCase().includes(searchQuery.toLowerCase())) ||
        project.industry.toLowerCase().includes(searchQuery.toLowerCase()) ||
        project.courses.some((course) => course.toLowerCase().includes(searchQuery.toLowerCase())) ||
        project.track.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    if (!selectedCategories.includes('ALL')) {
      filtered = filtered.filter((project) =>
        selectedCategories.includes(project.category)
      );
    }

    if (selectedTechStack.length > 0) {
      filtered = filtered.filter((project) =>
        selectedTechStack.some((tech) => project.techStack.includes(tech))
      );
    }

    if (selectedFrameworks.length > 0) {
      filtered = filtered.filter((project) =>
        selectedFrameworks.some((framework) => project.frameworks.includes(framework))
      );
    }

    if (selectedCohorts.length > 0) {
      filtered = filtered.filter((project) =>
        selectedCohorts.includes(project.cohort)
      );
    }

    if (selectedIndustries.length > 0) {
      filtered = filtered.filter((project) =>
        selectedIndustries.includes(project.industry)
      );
    }

    if (selectedCourses.length > 0) {
      filtered = filtered.filter((project) =>
        selectedCourses.some((course) => project.courses.includes(course))
      );
    }

    if (selectedLevels.length > 0) {
      filtered = filtered.filter((project) =>
        selectedLevels.includes(project.level)
      );
    }

    if (selectedTracks.length > 0) {
      filtered = filtered.filter((project) =>
        selectedTracks.includes(project.track)
      );
    }

    if (selectedThemes.length > 0) {
      filtered = filtered.filter((project) =>
        selectedThemes.some((theme) => project.theme.includes(theme))
      );
    }

    if (selectedYears.length > 0) {
      filtered = filtered.filter((project) =>
        selectedYears.includes(project.year)
      );
    }

    if (selectedSemesters.length > 0) {
      filtered = filtered.filter((project) =>
        selectedSemesters.includes(project.semester)
      );
    }

    if (selectedLocations.length > 0) {
      filtered = filtered.filter((project) =>
        selectedLocations.includes(project.location)
      );
    }

    if (selectedProgramTypes.length > 0) {
      filtered = filtered.filter((project) =>
        selectedProgramTypes.includes(project.programType)
      );
    }

    if (selectedJobRoles.length > 0) {
      filtered = filtered.filter((project) =>
        project.jobRoles && selectedJobRoles.some((role) => project.jobRoles!.includes(role))
      );
    }

    return filtered;
  }, [
    searchQuery, selectedCategories, selectedTechStack, selectedFrameworks,
    selectedCohorts, selectedIndustries, selectedCourses, selectedLevels,
    selectedTracks, selectedThemes, selectedYears, selectedSemesters,
    selectedLocations, selectedProgramTypes, selectedJobRoles
  ]);

  const activeFiltersCount =
    selectedTechStack.length +
    selectedFrameworks.length +
    selectedCohorts.length +
    selectedIndustries.length +
    selectedCourses.length +
    selectedLevels.length +
    selectedTracks.length +
    selectedThemes.length +
    selectedYears.length +
    selectedSemesters.length +
    selectedLocations.length +
    selectedProgramTypes.length +
    selectedJobRoles.length +
    (selectedCategories.includes('ALL') ? 0 : selectedCategories.length);

  const shareLinks = [
    {
      id: '1',
      created: '2024-10-10',
      projects: 5,
      expiry: '2024-11-10',
      views: 245,
      status: 'Active',
    },
    {
      id: '2',
      created: '2024-09-15',
      projects: 3,
      expiry: '2024-10-15',
      views: 128,
      status: 'Expired',
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-slate-900">
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-5xl mx-auto">
          <div className="flex items-center gap-4 mb-8">
            <Button variant="ghost" onClick={onBack}>
              ← Back
            </Button>
            <div>
              <h1>Create Share Link</h1>
              {collectionId && collections[collectionId] && (
                <p className="text-muted-foreground">
                  From collection: <span className="text-primary">{collections[collectionId].name}</span>
                </p>
              )}
            </div>
          </div>

          <div className="flex items-center justify-center mb-8">
            <div className="flex items-center gap-4">
              <div className={`flex items-center justify-center w-10 h-10 rounded-full ${step >= 1 ? 'bg-purple-500 text-white' : 'bg-gray-300 dark:bg-gray-700'}`}>
                1
              </div>
              <div className={`w-24 h-1 ${step >= 2 ? 'bg-purple-500' : 'bg-gray-300 dark:bg-gray-700'}`} />
              <div className={`flex items-center justify-center w-10 h-10 rounded-full ${step >= 2 ? 'bg-purple-500 text-white' : 'bg-gray-300 dark:bg-gray-700'}`}>
                2
              </div>
              <div className={`w-24 h-1 ${step >= 3 ? 'bg-purple-500' : 'bg-gray-300 dark:bg-gray-700'}`} />
              <div className={`flex items-center justify-center w-10 h-10 rounded-full ${step >= 3 ? 'bg-purple-500 text-white' : 'bg-gray-300 dark:bg-gray-700'}`}>
                3
              </div>
            </div>
          </div>

          {step === 1 && (
            <div className="bg-white dark:bg-slate-800 rounded-xl p-8 border border-border">
              <h2 className="mb-6">Step 1: Select Projects</h2>
              
              {/* Search Bar */}
              <div className="relative mb-4">
                <Input
                  placeholder="Search projects by title, student, industry, or technology..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pr-10"
                />
                {searchQuery && (
                  <button
                    onClick={() => setSearchQuery('')}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
              </div>

              {/* Category Pills */}
              <div className="flex flex-wrap items-center gap-2 mb-4">
                {categories.map((category) => (
                  <button
                    key={category}
                    onClick={() => toggleCategory(category)}
                    className={`px-4 py-1.5 rounded-full text-sm uppercase tracking-wide transition-all ${
                      selectedCategories.includes(category)
                        ? 'bg-gradient-to-r from-[#7C3AED] to-[#EC4899] text-white shadow-lg shadow-purple-500/30'
                        : 'bg-gray-100 dark:bg-slate-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-slate-600'
                    }`}
                  >
                    {category}
                  </button>
                ))}
              </div>

              {/* Filter Controls */}
              <div className="flex items-center gap-3 mb-4">
                <Sheet open={filterOpen} onOpenChange={setFilterOpen}>
                  <SheetTrigger asChild>
                    <Button variant="outline" className="gap-2">
                      <SlidersHorizontal className="w-4 h-4" />
                      Advanced Filters
                      {activeFiltersCount > 0 && (
                        <Badge variant="secondary" className="ml-1 bg-purple-500 text-white">
                          {activeFiltersCount}
                        </Badge>
                      )}
                    </Button>
                  </SheetTrigger>
                  <SheetContent className="w-full sm:max-w-md overflow-y-auto">
                    <SheetHeader>
                      <SheetTitle>Filter Projects</SheetTitle>
                      <SheetDescription>
                        Refine your search by selecting filters below
                      </SheetDescription>
                    </SheetHeader>

                    <div className="mt-6 space-y-4">
                      {activeFiltersCount > 0 && (
                        <Button
                          variant="outline"
                          onClick={clearAllFilters}
                          className="w-full"
                        >
                          Clear All {activeFiltersCount} Filter{activeFiltersCount > 1 ? 's' : ''}
                        </Button>
                      )}

                      <Separator />

                      <ScrollArea className="h-[calc(100vh-240px)]">
                        <Accordion type="multiple" className="w-full">
                          {/* Industry Filter */}
                          <AccordionItem value="industry">
                            <AccordionTrigger>
                              Industry {selectedIndustries.length > 0 && `(${selectedIndustries.length})`}
                            </AccordionTrigger>
                            <AccordionContent>
                              <div className="space-y-2 pl-4">
                                {allIndustries.map((industry) => (
                                  <div key={industry} className="flex items-center space-x-2">
                                    <Checkbox
                                      id={`industry-${industry}`}
                                      checked={selectedIndustries.includes(industry)}
                                      onCheckedChange={() => toggleFilter(industry, selectedIndustries, setSelectedIndustries)}
                                    />
                                    <label
                                      htmlFor={`industry-${industry}`}
                                      className="text-sm cursor-pointer flex-1"
                                    >
                                      {industry}
                                    </label>
                                  </div>
                                ))}
                              </div>
                            </AccordionContent>
                          </AccordionItem>

                          {/* Track Filter */}
                          <AccordionItem value="track">
                            <AccordionTrigger>
                              Track {selectedTracks.length > 0 && `(${selectedTracks.length})`}
                            </AccordionTrigger>
                            <AccordionContent>
                              <div className="space-y-2 pl-4">
                                {FIXED_TRACKS.map((track) => (
                                  <div key={track} className="flex items-center space-x-2">
                                    <Checkbox
                                      id={`track-${track}`}
                                      checked={selectedTracks.includes(track)}
                                      onCheckedChange={() => toggleFilter(track, selectedTracks, setSelectedTracks)}
                                    />
                                    <label
                                      htmlFor={`track-${track}`}
                                      className="text-sm cursor-pointer flex-1"
                                    >
                                      {track}
                                    </label>
                                  </div>
                                ))}
                              </div>
                            </AccordionContent>
                          </AccordionItem>

                          {/* Level Filter */}
                          <AccordionItem value="level">
                            <AccordionTrigger>
                              Difficulty Level {selectedLevels.length > 0 && `(${selectedLevels.length})`}
                            </AccordionTrigger>
                            <AccordionContent>
                              <div className="space-y-2 pl-4">
                                {levels.map((level) => (
                                  <div key={level} className="flex items-center space-x-2">
                                    <Checkbox
                                      id={`level-${level}`}
                                      checked={selectedLevels.includes(level)}
                                      onCheckedChange={() => toggleFilter(level, selectedLevels, setSelectedLevels)}
                                    />
                                    <label
                                      htmlFor={`level-${level}`}
                                      className="text-sm cursor-pointer flex-1"
                                    >
                                      {level}
                                    </label>
                                  </div>
                                ))}
                              </div>
                            </AccordionContent>
                          </AccordionItem>

                          {/* Tech Stack Filter */}
                          <AccordionItem value="techstack">
                            <AccordionTrigger>
                              Tech Stack {selectedTechStack.length > 0 && `(${selectedTechStack.length})`}
                            </AccordionTrigger>
                            <AccordionContent>
                              <div className="space-y-2 pl-4 max-h-64 overflow-y-auto">
                                {allTechStack.map((tech) => (
                                  <div key={tech} className="flex items-center space-x-2">
                                    <Checkbox
                                      id={`tech-${tech}`}
                                      checked={selectedTechStack.includes(tech)}
                                      onCheckedChange={() => toggleFilter(tech, selectedTechStack, setSelectedTechStack)}
                                    />
                                    <label
                                      htmlFor={`tech-${tech}`}
                                      className="text-sm cursor-pointer flex-1"
                                    >
                                      {tech}
                                    </label>
                                  </div>
                                ))}
                              </div>
                            </AccordionContent>
                          </AccordionItem>

                          {/* Cohort Filter */}
                          <AccordionItem value="cohort">
                            <AccordionTrigger>
                              Cohort {selectedCohorts.length > 0 && `(${selectedCohorts.length})`}
                            </AccordionTrigger>
                            <AccordionContent>
                              <div className="space-y-2 pl-4">
                                {allCohorts.map((cohort) => (
                                  <div key={cohort} className="flex items-center space-x-2">
                                    <Checkbox
                                      id={`cohort-${cohort}`}
                                      checked={selectedCohorts.includes(cohort)}
                                      onCheckedChange={() => toggleFilter(cohort, selectedCohorts, setSelectedCohorts)}
                                    />
                                    <label
                                      htmlFor={`cohort-${cohort}`}
                                      className="text-sm cursor-pointer flex-1"
                                    >
                                      {cohort}
                                    </label>
                                  </div>
                                ))}
                              </div>
                            </AccordionContent>
                          </AccordionItem>

                          {/* Year & Semester Filter */}
                          <AccordionItem value="time">
                            <AccordionTrigger>
                              Year & Semester {(selectedYears.length + selectedSemesters.length) > 0 && `(${selectedYears.length + selectedSemesters.length})`}
                            </AccordionTrigger>
                            <AccordionContent>
                              <div className="space-y-4 pl-4">
                                <div>
                                  <p className="text-sm mb-2">Year</p>
                                  {allYears.map((year) => (
                                    <div key={year} className="flex items-center space-x-2 mb-2">
                                      <Checkbox
                                        id={`year-${year}`}
                                        checked={selectedYears.includes(year)}
                                        onCheckedChange={() => toggleYearFilter(year)}
                                      />
                                      <label
                                        htmlFor={`year-${year}`}
                                        className="text-sm cursor-pointer flex-1"
                                      >
                                        {year}
                                      </label>
                                    </div>
                                  ))}
                                </div>
                                <Separator />
                                <div>
                                  <p className="text-sm mb-2">Semester</p>
                                  {semesters.map((semester) => (
                                    <div key={semester} className="flex items-center space-x-2 mb-2">
                                      <Checkbox
                                        id={`semester-${semester}`}
                                        checked={selectedSemesters.includes(semester)}
                                        onCheckedChange={() => toggleFilter(semester, selectedSemesters, setSelectedSemesters)}
                                      />
                                      <label
                                        htmlFor={`semester-${semester}`}
                                        className="text-sm cursor-pointer flex-1"
                                      >
                                        {semester}
                                      </label>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            </AccordionContent>
                          </AccordionItem>

                          {/* Demographics Filter */}
                          <AccordionItem value="demographics">
                            <AccordionTrigger>
                              Demographics {(selectedLocations.length + selectedProgramTypes.length) > 0 && `(${selectedLocations.length + selectedProgramTypes.length})`}
                            </AccordionTrigger>
                            <AccordionContent>
                              <div className="space-y-4 pl-4">
                                <div>
                                  <p className="text-sm mb-2">Location</p>
                                  {FIXED_LOCATIONS.map((location) => (
                                    <div key={location} className="flex items-center space-x-2 mb-2">
                                      <Checkbox
                                        id={`location-${location}`}
                                        checked={selectedLocations.includes(location)}
                                        onCheckedChange={() => toggleFilter(location, selectedLocations, setSelectedLocations)}
                                      />
                                      <label
                                        htmlFor={`location-${location}`}
                                        className="text-sm cursor-pointer flex-1"
                                      >
                                        {location}
                                      </label>
                                    </div>
                                  ))}
                                </div>
                                <Separator />
                                <div>
                                  <p className="text-sm mb-2">Program Type</p>
                                  {FIXED_PROGRAM_TYPES.map((type) => (
                                    <div key={type} className="flex items-center space-x-2 mb-2">
                                      <Checkbox
                                        id={`program-${type}`}
                                        checked={selectedProgramTypes.includes(type)}
                                        onCheckedChange={() => toggleFilter(type, selectedProgramTypes, setSelectedProgramTypes)}
                                      />
                                      <label
                                        htmlFor={`program-${type}`}
                                        className="text-sm cursor-pointer flex-1"
                                      >
                                        {type}
                                      </label>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            </AccordionContent>
                          </AccordionItem>

                          {/* Job Roles Filter */}
                          <AccordionItem value="jobroles">
                            <AccordionTrigger>
                              Job Roles {selectedJobRoles.length > 0 && `(${selectedJobRoles.length})`}
                            </AccordionTrigger>
                            <AccordionContent>
                              <div className="space-y-2 pl-4 max-h-64 overflow-y-auto">
                                {FIXED_JOB_ROLES.map((role) => (
                                  <div key={role} className="flex items-center space-x-2">
                                    <Checkbox
                                      id={`jobrole-${role}`}
                                      checked={selectedJobRoles.includes(role)}
                                      onCheckedChange={() => toggleFilter(role, selectedJobRoles, setSelectedJobRoles)}
                                    />
                                    <label
                                      htmlFor={`jobrole-${role}`}
                                      className="text-sm cursor-pointer flex-1"
                                    >
                                      {role}
                                    </label>
                                  </div>
                                ))}
                              </div>
                            </AccordionContent>
                          </AccordionItem>
                        </Accordion>
                      </ScrollArea>
                    </div>
                  </SheetContent>
                </Sheet>

                <div className="text-sm text-gray-600 dark:text-gray-400">
                  Showing {filteredProjects.length} project{filteredProjects.length !== 1 ? 's' : ''}
                </div>
              </div>

              {/* Active Filters Display */}
              {activeFiltersCount > 0 && (
                <div className="flex flex-wrap gap-2 mb-4">
                  {selectedIndustries.map((industry) => (
                    <Badge key={`badge-industry-${industry}`} variant="secondary" className="gap-1">
                      {industry}
                      <button onClick={() => toggleFilter(industry, selectedIndustries, setSelectedIndustries)}>
                        <X className="w-3 h-3" />
                      </button>
                    </Badge>
                  ))}
                  {selectedTracks.map((track) => (
                    <Badge key={`badge-track-${track}`} variant="secondary" className="gap-1">
                      {track}
                      <button onClick={() => toggleFilter(track, selectedTracks, setSelectedTracks)}>
                        <X className="w-3 h-3" />
                      </button>
                    </Badge>
                  ))}
                  {selectedLevels.map((level) => (
                    <Badge key={`badge-level-${level}`} variant="secondary" className="gap-1">
                      {level}
                      <button onClick={() => toggleFilter(level, selectedLevels, setSelectedLevels)}>
                        <X className="w-3 h-3" />
                      </button>
                    </Badge>
                  ))}
                  {selectedTechStack.map((tech) => (
                    <Badge key={`badge-tech-${tech}`} variant="secondary" className="gap-1">
                      {tech}
                      <button onClick={() => toggleFilter(tech, selectedTechStack, setSelectedTechStack)}>
                        <X className="w-3 h-3" />
                      </button>
                    </Badge>
                  ))}
                  {selectedCohorts.map((cohort) => (
                    <Badge key={`badge-cohort-${cohort}`} variant="secondary" className="gap-1">
                      {cohort}
                      <button onClick={() => toggleFilter(cohort, selectedCohorts, setSelectedCohorts)}>
                        <X className="w-3 h-3" />
                      </button>
                    </Badge>
                  ))}
                  {selectedYears.map((year) => (
                    <Badge key={`badge-year-${year}`} variant="secondary" className="gap-1">
                      {year}
                      <button onClick={() => toggleYearFilter(year)}>
                        <X className="w-3 h-3" />
                      </button>
                    </Badge>
                  ))}
                  {selectedSemesters.map((semester) => (
                    <Badge key={`badge-semester-${semester}`} variant="secondary" className="gap-1">
                      {semester}
                      <button onClick={() => toggleFilter(semester, selectedSemesters, setSelectedSemesters)}>
                        <X className="w-3 h-3" />
                      </button>
                    </Badge>
                  ))}
                  {selectedLocations.map((location) => (
                    <Badge key={`badge-location-${location}`} variant="secondary" className="gap-1">
                      {location}
                      <button onClick={() => toggleFilter(location, selectedLocations, setSelectedLocations)}>
                        <X className="w-3 h-3" />
                      </button>
                    </Badge>
                  ))}
                  {selectedProgramTypes.map((type) => (
                    <Badge key={`badge-program-${type}`} variant="secondary" className="gap-1">
                      {type}
                      <button onClick={() => toggleFilter(type, selectedProgramTypes, setSelectedProgramTypes)}>
                        <X className="w-3 h-3" />
                      </button>
                    </Badge>
                  ))}
                  {selectedJobRoles.map((role) => (
                    <Badge key={`badge-jobrole-${role}`} variant="secondary" className="gap-1">
                      {role}
                      <button onClick={() => toggleFilter(role, selectedJobRoles, setSelectedJobRoles)}>
                        <X className="w-3 h-3" />
                      </button>
                    </Badge>
                  ))}
                </div>
              )}

              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-12"></TableHead>
                      <TableHead>Thumbnail</TableHead>
                      <TableHead>Title</TableHead>
                      <TableHead>Student</TableHead>
                      <TableHead>Category</TableHead>
                      <TableHead>Tags</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredProjects.map((project) => (
                      <TableRow key={project.id}>
                        <TableCell>
                          <Checkbox
                            checked={selectedProjects.includes(project.id)}
                            onCheckedChange={() => toggleProject(project.id)}
                          />
                        </TableCell>
                        <TableCell>
                          <ImageWithFallback
                            src={project.thumbnail}
                            alt={project.title}
                            className="w-16 h-10 object-cover rounded"
                          />
                        </TableCell>
                        <TableCell className="max-w-xs truncate">{project.title}</TableCell>
                        <TableCell>{project.student}</TableCell>
                        <TableCell>
                          <Badge variant="secondary">{project.category}</Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex flex-wrap gap-1 max-w-xs">
                            <Badge variant="outline" className="text-xs">{project.industry}</Badge>
                            <Badge variant="outline" className="text-xs">{project.track}</Badge>
                            <Badge variant="outline" className="text-xs">{project.location}</Badge>
                            <Badge variant="outline" className="text-xs">{project.programType}</Badge>
                            {project.theme.slice(0, 2).map((t) => (
                              <Badge key={t} variant="outline" className="text-xs">{t}</Badge>
                            ))}
                            {project.theme.length > 2 && (
                              <Badge variant="outline" className="text-xs">+{project.theme.length - 2}</Badge>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>

              <div className="mt-6 flex justify-between items-center">
                <p className="text-gray-600 dark:text-gray-400">
                  {selectedProjects.length} project(s) selected
                </p>
                <Button
                  onClick={() => setStep(2)}
                  disabled={selectedProjects.length === 0}
                  className="bg-gradient-to-r from-[#7C3AED] to-[#EC4899] hover:opacity-90"
                >
                  Next <ChevronRight className="w-4 h-4 ml-2" />
                </Button>
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="bg-white dark:bg-slate-800 rounded-xl p-8 border border-border space-y-6">
              <h2>Step 2: Configure Settings</h2>

              <div>
                <Label>Theme</Label>
                <div className="mt-2 grid grid-cols-2 gap-4">
                  <button
                    onClick={() => setTheme('light')}
                    className={`p-4 border-2 rounded-lg transition-all ${
                      theme === 'light'
                        ? 'border-purple-500 bg-purple-50 dark:bg-purple-900/20'
                        : 'border-border hover:border-gray-400'
                    }`}
                  >
                    <div className="w-full h-24 bg-white rounded mb-2 border border-gray-200"></div>
                    <p className="text-center">Light Theme</p>
                  </button>
                  <button
                    onClick={() => setTheme('dark')}
                    className={`p-4 border-2 rounded-lg transition-all ${
                      theme === 'dark'
                        ? 'border-purple-500 bg-purple-50 dark:bg-purple-900/20'
                        : 'border-border hover:border-gray-400'
                    }`}
                  >
                    <div className="w-full h-24 bg-slate-900 rounded mb-2 border border-gray-700"></div>
                    <p className="text-center">Dark Theme</p>
                  </button>
                </div>
              </div>

              <div>
                <Label htmlFor="expiration">Link Expiration</Label>
                <Select value={expiration} onValueChange={setExpiration}>
                  <SelectTrigger id="expiration" className="mt-2">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="7">7 days</SelectItem>
                    <SelectItem value="14">14 days</SelectItem>
                    <SelectItem value="30">30 days</SelectItem>
                    <SelectItem value="90">90 days</SelectItem>
                    <SelectItem value="never">Never expires</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-center justify-between p-4 border border-border rounded-lg">
                <div className="flex items-center gap-3">
                  <Eye className="w-5 h-5 text-purple-500" />
                  <div>
                    <p>Lead Capture</p>
                    <p className="text-gray-600 dark:text-gray-400">
                      Collect visitor information
                    </p>
                  </div>
                </div>
                <Switch checked={leadCapture} onCheckedChange={setLeadCapture} />
              </div>

              <div className="space-y-3">
                <div className="flex items-center justify-between p-4 border border-border rounded-lg">
                  <div className="flex items-center gap-3">
                    <Shield className="w-5 h-5 text-purple-500" />
                    <div>
                      <p>Password Protection</p>
                      <p className="text-gray-600 dark:text-gray-400">
                        Require password to access
                      </p>
                    </div>
                  </div>
                  <Switch checked={password} onCheckedChange={setPassword} />
                </div>
                {password && (
                  <Input
                    type="password"
                    placeholder="Enter password"
                    value={passwordValue}
                    onChange={(e) => setPasswordValue(e.target.value)}
                  />
                )}
              </div>

              <div className="flex justify-between">
                <Button variant="outline" onClick={() => setStep(1)}>
                  Back
                </Button>
                <Button
                  onClick={() => {
                    handleGenerate();
                    setStep(3);
                    // Show expiration notification
                    const expirationDays = expiration === 'never' ? 'never' : `${expiration} days`;
                    if (expiration !== 'never') {
                      toast.success(`Share link created! Link will expire in ${expiration} days.`, {
                        duration: 5000,
                      });
                    } else {
                      toast.success('Share link created! This link will never expire.', {
                        duration: 5000,
                      });
                    }
                  }}
                  className="bg-gradient-to-r from-[#7C3AED] to-[#EC4899] hover:opacity-90"
                >
                  Generate Link <ChevronRight className="w-4 h-4 ml-2" />
                </Button>
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="bg-white dark:bg-slate-800 rounded-xl p-8 border border-border space-y-6">
              <h2>Step 3: Your Share Link is Ready!</h2>

              <div className="p-6 bg-purple-50 dark:bg-purple-900/20 rounded-lg border-2 border-purple-500">
                <Label className="mb-2 block">Share Link</Label>
                <div className="flex gap-2">
                  <Input value={generatedLink} readOnly className="flex-1" />
                  <Button onClick={handleCopyLink} className="gap-2">
                    <Copy className="w-4 h-4" />
                    Copy
                  </Button>
                </div>
              </div>

              {/* Expiration Warning */}
              {expiration !== 'never' && (
                <div className="p-4 bg-orange-50 dark:bg-orange-900/20 rounded-lg border border-orange-300 dark:border-orange-700 flex items-start gap-3">
                  <Clock className="w-5 h-5 text-orange-600 dark:text-orange-400 mt-0.5 flex-shrink-0" />
                  <div className="flex-1">
                    <p className="font-medium text-orange-900 dark:text-orange-200">
                      Link Expiration Notice
                    </p>
                    <p className="text-sm text-orange-700 dark:text-orange-300 mt-1">
                      This share link will expire in <strong>{expiration} days</strong>. After that, it will no longer be accessible. 
                      {parseInt(expiration) <= 7 && ' Consider creating a new link before expiration.'}
                    </p>
                  </div>
                </div>
              )}

              <div className="flex justify-center">
                <div className="w-48 h-48 bg-white dark:bg-slate-900 p-4 rounded-lg border border-border relative">
                  <div className="w-full h-full bg-gradient-to-br from-purple-500 to-pink-500 rounded flex items-center justify-center">
                    <QrCode className="w-24 h-24 text-white" />
                  </div>
                  <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-12 h-12 bg-white dark:bg-slate-800 rounded-lg flex items-center justify-center p-1 border-2 border-white dark:border-slate-800">
                    <img src={logoImage} alt="dae" className="w-full h-full object-contain" />
                  </div>
                </div>
              </div>

              <div className="flex gap-3">
                <Button variant="outline" className="flex-1 gap-2">
                  <QrCode className="w-4 h-4" />
                  Download QR Code
                </Button>
                <Button 
                  onClick={onPreview}
                  className="flex-1 gap-2 bg-gradient-to-r from-[#7C3AED] to-[#EC4899] hover:opacity-90"
                >
                  <ExternalLink className="w-4 h-4" />
                  Open Preview
                </Button>
              </div>

              <Button variant="outline" onClick={onBack} className="w-full">
                Back to Dashboard
              </Button>
            </div>
          )}

          {step === 1 && (
            <div className="mt-8 bg-white dark:bg-slate-800 rounded-xl p-8 border border-border">
              <h3 className="mb-6">Share Link History</h3>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Created</TableHead>
                    <TableHead>Projects</TableHead>
                    <TableHead>Expiry</TableHead>
                    <TableHead>Views</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {shareLinks.map((link) => (
                    <TableRow key={link.id}>
                      <TableCell>{new Date(link.created).toLocaleDateString()}</TableCell>
                      <TableCell>{link.projects} projects</TableCell>
                      <TableCell>{new Date(link.expiry).toLocaleDateString()}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          <Eye className="w-4 h-4 text-gray-400" />
                          {link.views}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge
                          variant={link.status === 'Active' ? 'default' : 'secondary'}
                          className={link.status === 'Active' ? 'bg-green-500' : ''}
                        >
                          {link.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-2">
                          <Button variant="ghost" size="icon" className="w-8 h-8">
                            <Copy className="w-4 h-4" />
                          </Button>
                          <Button variant="ghost" size="icon" className="w-8 h-8">
                            <ExternalLink className="w-4 h-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
