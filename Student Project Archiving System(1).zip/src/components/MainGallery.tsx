import { useState, useMemo } from 'react';
import { Search, X, SlidersHorizontal, ArrowUpDown, Filter, SearchX } from 'lucide-react';
import { HeroCarousel } from './HeroCarousel';
import { ProjectCard } from './ProjectCard';
import { ProjectDetailModal } from './ProjectDetailModal';
import { EmptyState } from './EmptyState';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Checkbox } from './ui/checkbox';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { ScrollArea } from './ui/scroll-area';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from './ui/accordion';
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from './ui/sheet';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from './ui/dropdown-menu';
import { mockProjects, Project, FIXED_TRACKS, FIXED_LOCATIONS, FIXED_PROGRAM_TYPES, FIXED_JOB_ROLES } from '../lib/mockData';

const categories = ['ALL', 'WEB DEV', 'CYBERSECURITY', 'GAME DEV', 'IoT', 'AI & DATA SCIENCE'];
const levels = ['Beginner', 'Intermediate', 'Advanced'];
const semesters = ['Spring', 'Summer', 'Fall', 'Winter'];

export function MainGallery() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategories, setSelectedCategories] = useState<string[]>(['ALL']);
  const [sortBy, setSortBy] = useState<'newest' | 'oldest' | 'popular' | 'a-z'>('newest');
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [visibleProjects, setVisibleProjects] = useState(12);
  const [filterOpen, setFilterOpen] = useState(false);
  
  // Advanced filter states
  const [selectedTechStack, setSelectedTechStack] = useState<string[]>([]);
  const [selectedFrameworks, setSelectedFrameworks] = useState<string[]>([]);
  const [selectedCohorts, setSelectedCohorts] = useState<string[]>([]);
  const [selectedIndustries, setSelectedIndustries] = useState<string[]>([]);
  const [selectedCourses, setSelectedCourses] = useState<string[]>([]);
  const [selectedLevels, setSelectedLevels] = useState<string[]>([]);
  const [selectedTracks, setSelectedTracks] = useState<string[]>([]);
  const [selectedThemes, setSelectedThemes] = useState<string[]>([]);
  const [selectedYears, setSelectedYears] = useState<number[]>([]);
  const [selectedSemesters, setSelectedSemesters] = useState<string[]>([]);
  const [selectedLocations, setSelectedLocations] = useState<string[]>([]);
  const [selectedProgramTypes, setSelectedProgramTypes] = useState<string[]>([]);
  const [selectedJobRoles, setSelectedJobRoles] = useState<string[]>([]);

  const toggleCategory = (category: string) => {
    if (category === 'ALL') {
      setSelectedCategories(['ALL']);
    } else {
      const newCategories = selectedCategories.includes(category)
        ? selectedCategories.filter((c) => c !== category)
        : [...selectedCategories.filter((c) => c !== 'ALL'), category];
      
      setSelectedCategories(newCategories.length === 0 ? ['ALL'] : newCategories);
    }
  };

  const toggleFilter = (value: string, selected: string[], setSelected: (value: string[]) => void) => {
    if (selected.includes(value)) {
      setSelected(selected.filter((v) => v !== value));
    } else {
      setSelected([...selected, value]);
    }
  };

  const toggleYearFilter = (value: number) => {
    if (selectedYears.includes(value)) {
      setSelectedYears(selectedYears.filter((v) => v !== value));
    } else {
      setSelectedYears([...selectedYears, value]);
    }
  };

  // Extract unique values for filters
  const allTechStack = useMemo(() => {
    const techs = new Set<string>();
    mockProjects.forEach(p => p.techStack.forEach(t => techs.add(t)));
    return Array.from(techs).sort();
  }, []);

  const allFrameworks = useMemo(() => {
    const frameworks = new Set<string>();
    mockProjects.forEach(p => p.frameworks.forEach(f => frameworks.add(f)));
    return Array.from(frameworks).sort();
  }, []);

  const allCohorts = useMemo(() => {
    const cohorts = new Set<string>();
    mockProjects.forEach(p => cohorts.add(p.cohort));
    return Array.from(cohorts).sort();
  }, []);

  const allYears = useMemo(() => {
    const years = new Set<number>();
    mockProjects.forEach(p => years.add(p.year));
    return Array.from(years).sort((a, b) => b - a);
  }, []);

  // Dynamic filter generation from project data
  const allIndustries = useMemo(() => {
    const industries = new Set<string>();
    mockProjects.forEach(p => industries.add(p.industry));
    return Array.from(industries).sort();
  }, []);

  const allCourses = useMemo(() => {
    const courses = new Set<string>();
    mockProjects.forEach(p => p.courses.forEach(c => courses.add(c)));
    return Array.from(courses).sort();
  }, []);

  const allThemes = useMemo(() => {
    const themes = new Set<string>();
    mockProjects.forEach(p => p.theme.forEach(t => themes.add(t)));
    return Array.from(themes).sort();
  }, []);

  // Fixed tracks from program structure
  const allTracks = ['Web Development', 'Game Development', 'Cybersecurity', 'IoT', 'AI & Data Science'];

  const filteredAndSortedProjects = useMemo(() => {
    let filtered = mockProjects;

    if (searchQuery) {
      filtered = filtered.filter((project) =>
        project.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        project.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        project.student.toLowerCase().includes(searchQuery.toLowerCase()) ||
        project.techStack.some((tech) => tech.toLowerCase().includes(searchQuery.toLowerCase())) ||
        project.industry.toLowerCase().includes(searchQuery.toLowerCase()) ||
        project.courses.some((course) => course.toLowerCase().includes(searchQuery.toLowerCase())) ||
        project.track.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    if (!selectedCategories.includes('ALL')) {
      filtered = filtered.filter((project) =>
        selectedCategories.includes(project.category)
      );
    }

    // Tech Stack filter
    if (selectedTechStack.length > 0) {
      filtered = filtered.filter((project) =>
        selectedTechStack.some((tech) => project.techStack.includes(tech))
      );
    }

    // Frameworks filter
    if (selectedFrameworks.length > 0) {
      filtered = filtered.filter((project) =>
        selectedFrameworks.some((framework) => project.frameworks.includes(framework))
      );
    }

    // Cohort filter
    if (selectedCohorts.length > 0) {
      filtered = filtered.filter((project) =>
        selectedCohorts.includes(project.cohort)
      );
    }

    // Industry filter
    if (selectedIndustries.length > 0) {
      filtered = filtered.filter((project) =>
        selectedIndustries.includes(project.industry)
      );
    }

    // Course filter
    if (selectedCourses.length > 0) {
      filtered = filtered.filter((project) =>
        selectedCourses.some((course) => project.courses.includes(course))
      );
    }

    // Level filter
    if (selectedLevels.length > 0) {
      filtered = filtered.filter((project) =>
        selectedLevels.includes(project.level)
      );
    }

    // Track filter
    if (selectedTracks.length > 0) {
      filtered = filtered.filter((project) =>
        selectedTracks.includes(project.track)
      );
    }

    // Theme filter
    if (selectedThemes.length > 0) {
      filtered = filtered.filter((project) =>
        selectedThemes.some((theme) => project.theme.includes(theme))
      );
    }

    // Year filter
    if (selectedYears.length > 0) {
      filtered = filtered.filter((project) =>
        selectedYears.includes(project.year)
      );
    }

    // Semester filter
    if (selectedSemesters.length > 0) {
      filtered = filtered.filter((project) =>
        selectedSemesters.includes(project.semester)
      );
    }

    // Location filter (Demographics)
    if (selectedLocations.length > 0) {
      filtered = filtered.filter((project) =>
        selectedLocations.includes(project.location)
      );
    }

    // Program Type filter (Demographics)
    if (selectedProgramTypes.length > 0) {
      filtered = filtered.filter((project) =>
        selectedProgramTypes.includes(project.programType)
      );
    }

    // Job Roles filter
    if (selectedJobRoles.length > 0) {
      filtered = filtered.filter((project) =>
        project.jobRoles && selectedJobRoles.some((role) => project.jobRoles!.includes(role))
      );
    }

    const sorted = [...filtered].sort((a, b) => {
      switch (sortBy) {
        case 'newest':
          return new Date(b.date).getTime() - new Date(a.date).getTime();
        case 'oldest':
          return new Date(a.date).getTime() - new Date(b.date).getTime();
        case 'popular':
          return b.views - a.views;
        case 'a-z':
          return a.title.localeCompare(b.title);
        default:
          return 0;
      }
    });

    return sorted;
  }, [
    searchQuery, selectedCategories, sortBy, selectedTechStack, selectedFrameworks,
    selectedCohorts, selectedIndustries, selectedCourses, selectedLevels,
    selectedTracks, selectedThemes, selectedYears, selectedSemesters,
    selectedLocations, selectedProgramTypes, selectedJobRoles
  ]);

  const displayedProjects = filteredAndSortedProjects.slice(0, visibleProjects);

  const handleProjectClick = (project: Project) => {
    setSelectedProject(project);
  };

  const handleNextProject = () => {
    if (!selectedProject) return;
    const currentIndex = filteredAndSortedProjects.findIndex((p) => p.id === selectedProject.id);
    const nextIndex = (currentIndex + 1) % filteredAndSortedProjects.length;
    setSelectedProject(filteredAndSortedProjects[nextIndex]);
  };

  const handlePreviousProject = () => {
    if (!selectedProject) return;
    const currentIndex = filteredAndSortedProjects.findIndex((p) => p.id === selectedProject.id);
    const prevIndex = (currentIndex - 1 + filteredAndSortedProjects.length) % filteredAndSortedProjects.length;
    setSelectedProject(filteredAndSortedProjects[prevIndex]);
  };

  const clearAllFilters = () => {
    setSelectedTechStack([]);
    setSelectedFrameworks([]);
    setSelectedCohorts([]);
    setSelectedIndustries([]);
    setSelectedCourses([]);
    setSelectedLevels([]);
    setSelectedTracks([]);
    setSelectedThemes([]);
    setSelectedYears([]);
    setSelectedSemesters([]);
    setSelectedLocations([]);
    setSelectedProgramTypes([]);
    setSelectedJobRoles([]);
    setSearchQuery('');
    setSelectedCategories(['ALL']);
  };

  const activeFiltersCount =
    selectedTechStack.length +
    selectedFrameworks.length +
    selectedCohorts.length +
    selectedIndustries.length +
    selectedCourses.length +
    selectedLevels.length +
    selectedTracks.length +
    selectedThemes.length +
    selectedYears.length +
    selectedSemesters.length +
    selectedLocations.length +
    selectedProgramTypes.length +
    selectedJobRoles.length +
    (selectedCategories.includes('ALL') ? 0 : selectedCategories.length);

  return (
    <div className="min-h-screen bg-white dark:bg-slate-900">
      <div className="container mx-auto px-4 py-8 space-y-8">
        <HeroCarousel />

        {/* Search Bar */}
        <div className="max-w-[800px] mx-auto">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-purple-500" />
            <Input
              type="text"
              placeholder="Search projects, students, industries, courses, or technologies..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="h-14 pl-12 pr-12 rounded-full border-2 border-border focus:border-purple-500 focus:ring-2 focus:ring-purple-500/20"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
              >
                <X className="w-5 h-5" />
              </button>
            )}
          </div>
        </div>

        {/* Category Pills */}
        <div className="flex flex-wrap items-center justify-center gap-3">
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => toggleCategory(category)}
              className={`px-6 py-2 rounded-full uppercase tracking-wide transition-all ${
                selectedCategories.includes(category)
                  ? 'bg-gradient-to-r from-[#7C3AED] to-[#EC4899] text-white shadow-lg shadow-purple-500/30'
                  : 'bg-gray-100 dark:bg-slate-800 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-slate-700'
              }`}
            >
              {category}
            </button>
          ))}
        </div>

        {/* Filter & Sort Bar */}
        <div className="flex flex-wrap items-center gap-3">
          <Sheet open={filterOpen} onOpenChange={setFilterOpen}>
            <SheetTrigger asChild>
              <Button variant="outline" className="gap-2">
                <Filter className="w-4 h-4" />
                Advanced Filters
                {activeFiltersCount > 0 && (
                  <Badge className="ml-1 bg-gradient-to-r from-[#7C3AED] to-[#EC4899] text-white border-0">
                    {activeFiltersCount}
                  </Badge>
                )}
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-full sm:w-[480px]">
              <SheetHeader>
                <SheetTitle>Filter Projects</SheetTitle>
                <SheetDescription>
                  Refine your search by selecting filters below
                </SheetDescription>
              </SheetHeader>

              <div className="mt-6 space-y-4">
                {/* Clear All Filters */}
                {activeFiltersCount > 0 && (
                  <Button
                    variant="outline"
                    onClick={clearAllFilters}
                    className="w-full"
                  >
                    Clear All {activeFiltersCount} Filter{activeFiltersCount > 1 ? 's' : ''}
                  </Button>
                )}

                <Separator />

                <ScrollArea className="h-[calc(100vh-240px)]">
                  <Accordion type="multiple" className="w-full">
                    {/* Industry Filter */}
                    <AccordionItem value="industry">
                      <AccordionTrigger>
                        Industry {selectedIndustries.length > 0 && `(${selectedIndustries.length})`}
                      </AccordionTrigger>
                      <AccordionContent>
                        <div className="space-y-2 pl-4">
                          {allIndustries.map((industry) => (
                            <div key={industry} className="flex items-center space-x-2">
                              <Checkbox
                                id={`industry-${industry}`}
                                checked={selectedIndustries.includes(industry)}
                                onCheckedChange={() => toggleFilter(industry, selectedIndustries, setSelectedIndustries)}
                              />
                              <label
                                htmlFor={`industry-${industry}`}
                                className="text-sm cursor-pointer flex-1"
                              >
                                {industry}
                              </label>
                            </div>
                          ))}
                        </div>
                      </AccordionContent>
                    </AccordionItem>

                    {/* Course Filter */}
                    <AccordionItem value="course">
                      <AccordionTrigger>
                        Course {selectedCourses.length > 0 && `(${selectedCourses.length})`}
                      </AccordionTrigger>
                      <AccordionContent>
                        <div className="space-y-2 pl-4">
                          {allCourses.map((course) => (
                            <div key={course} className="flex items-center space-x-2">
                              <Checkbox
                                id={`course-${course}`}
                                checked={selectedCourses.includes(course)}
                                onCheckedChange={() => toggleFilter(course, selectedCourses, setSelectedCourses)}
                              />
                              <label
                                htmlFor={`course-${course}`}
                                className="text-sm cursor-pointer flex-1"
                              >
                                {course}
                              </label>
                            </div>
                          ))}
                        </div>
                      </AccordionContent>
                    </AccordionItem>

                    {/* Level Filter */}
                    <AccordionItem value="level">
                      <AccordionTrigger>
                        Difficulty Level {selectedLevels.length > 0 && `(${selectedLevels.length})`}
                      </AccordionTrigger>
                      <AccordionContent>
                        <div className="space-y-2 pl-4">
                          {levels.map((level) => (
                            <div key={level} className="flex items-center space-x-2">
                              <Checkbox
                                id={`level-${level}`}
                                checked={selectedLevels.includes(level)}
                                onCheckedChange={() => toggleFilter(level, selectedLevels, setSelectedLevels)}
                              />
                              <label
                                htmlFor={`level-${level}`}
                                className="text-sm cursor-pointer flex-1"
                              >
                                {level}
                              </label>
                            </div>
                          ))}
                        </div>
                      </AccordionContent>
                    </AccordionItem>

                    {/* Track Filter */}
                    <AccordionItem value="track">
                      <AccordionTrigger>
                        Track {selectedTracks.length > 0 && `(${selectedTracks.length})`}
                      </AccordionTrigger>
                      <AccordionContent>
                        <div className="space-y-2 pl-4">
                          {allTracks.map((track) => (
                            <div key={track} className="flex items-center space-x-2">
                              <Checkbox
                                id={`track-${track}`}
                                checked={selectedTracks.includes(track)}
                                onCheckedChange={() => toggleFilter(track, selectedTracks, setSelectedTracks)}
                              />
                              <label
                                htmlFor={`track-${track}`}
                                className="text-sm cursor-pointer flex-1"
                              >
                                {track}
                              </label>
                            </div>
                          ))}
                        </div>
                      </AccordionContent>
                    </AccordionItem>

                    {/* Theme Filter */}
                    <AccordionItem value="theme">
                      <AccordionTrigger>
                        Theme {selectedThemes.length > 0 && `(${selectedThemes.length})`}
                      </AccordionTrigger>
                      <AccordionContent>
                        <div className="space-y-2 pl-4">
                          {allThemes.map((theme) => (
                            <div key={theme} className="flex items-center space-x-2">
                              <Checkbox
                                id={`theme-${theme}`}
                                checked={selectedThemes.includes(theme)}
                                onCheckedChange={() => toggleFilter(theme, selectedThemes, setSelectedThemes)}
                              />
                              <label
                                htmlFor={`theme-${theme}`}
                                className="text-sm cursor-pointer flex-1"
                              >
                                {theme}
                              </label>
                            </div>
                          ))}
                        </div>
                      </AccordionContent>
                    </AccordionItem>

                    {/* Tech Stack Filter */}
                    <AccordionItem value="techStack">
                      <AccordionTrigger>
                        Tech Stack {selectedTechStack.length > 0 && `(${selectedTechStack.length})`}
                      </AccordionTrigger>
                      <AccordionContent>
                        <div className="space-y-2 pl-4">
                          {allTechStack.map((tech) => (
                            <div key={tech} className="flex items-center space-x-2">
                              <Checkbox
                                id={`tech-${tech}`}
                                checked={selectedTechStack.includes(tech)}
                                onCheckedChange={() => toggleFilter(tech, selectedTechStack, setSelectedTechStack)}
                              />
                              <label
                                htmlFor={`tech-${tech}`}
                                className="text-sm cursor-pointer flex-1"
                              >
                                {tech}
                              </label>
                            </div>
                          ))}
                        </div>
                      </AccordionContent>
                    </AccordionItem>

                    {/* Frameworks Filter */}
                    <AccordionItem value="frameworks">
                      <AccordionTrigger>
                        Frameworks {selectedFrameworks.length > 0 && `(${selectedFrameworks.length})`}
                      </AccordionTrigger>
                      <AccordionContent>
                        <div className="space-y-2 pl-4">
                          {allFrameworks.map((framework) => (
                            <div key={framework} className="flex items-center space-x-2">
                              <Checkbox
                                id={`framework-${framework}`}
                                checked={selectedFrameworks.includes(framework)}
                                onCheckedChange={() => toggleFilter(framework, selectedFrameworks, setSelectedFrameworks)}
                              />
                              <label
                                htmlFor={`framework-${framework}`}
                                className="text-sm cursor-pointer flex-1"
                              >
                                {framework}
                              </label>
                            </div>
                          ))}
                        </div>
                      </AccordionContent>
                    </AccordionItem>

                    {/* Year Filter */}
                    <AccordionItem value="year">
                      <AccordionTrigger>
                        Year {selectedYears.length > 0 && `(${selectedYears.length})`}
                      </AccordionTrigger>
                      <AccordionContent>
                        <div className="space-y-2 pl-4">
                          {allYears.map((year) => (
                            <div key={year} className="flex items-center space-x-2">
                              <Checkbox
                                id={`year-${year}`}
                                checked={selectedYears.includes(year)}
                                onCheckedChange={() => toggleYearFilter(year)}
                              />
                              <label
                                htmlFor={`year-${year}`}
                                className="text-sm cursor-pointer flex-1"
                              >
                                {year}
                              </label>
                            </div>
                          ))}
                        </div>
                      </AccordionContent>
                    </AccordionItem>

                    {/* Semester Filter */}
                    <AccordionItem value="semester">
                      <AccordionTrigger>
                        Semester {selectedSemesters.length > 0 && `(${selectedSemesters.length})`}
                      </AccordionTrigger>
                      <AccordionContent>
                        <div className="space-y-2 pl-4">
                          {semesters.map((semester) => (
                            <div key={semester} className="flex items-center space-x-2">
                              <Checkbox
                                id={`semester-${semester}`}
                                checked={selectedSemesters.includes(semester)}
                                onCheckedChange={() => toggleFilter(semester, selectedSemesters, setSelectedSemesters)}
                              />
                              <label
                                htmlFor={`semester-${semester}`}
                                className="text-sm cursor-pointer flex-1"
                              >
                                {semester}
                              </label>
                            </div>
                          ))}
                        </div>
                      </AccordionContent>
                    </AccordionItem>

                    {/* Cohort Filter */}
                    <AccordionItem value="cohort">
                      <AccordionTrigger>
                        Cohort {selectedCohorts.length > 0 && `(${selectedCohorts.length})`}
                      </AccordionTrigger>
                      <AccordionContent>
                        <div className="space-y-2 pl-4">
                          {allCohorts.map((cohort) => (
                            <div key={cohort} className="flex items-center space-x-2">
                              <Checkbox
                                id={`cohort-${cohort}`}
                                checked={selectedCohorts.includes(cohort)}
                                onCheckedChange={() => toggleFilter(cohort, selectedCohorts, setSelectedCohorts)}
                              />
                              <label
                                htmlFor={`cohort-${cohort}`}
                                className="text-sm cursor-pointer flex-1"
                              >
                                {cohort}
                              </label>
                            </div>
                          ))}
                        </div>
                      </AccordionContent>
                    </AccordionItem>

                    {/* Demographics Filter */}
                    <AccordionItem value="demographics">
                      <AccordionTrigger>
                        Demographics {(selectedLocations.length + selectedProgramTypes.length) > 0 && `(${selectedLocations.length + selectedProgramTypes.length})`}
                      </AccordionTrigger>
                      <AccordionContent>
                        <div className="space-y-4 pl-4">
                          <div>
                            <p className="text-sm mb-2">Location</p>
                            {FIXED_LOCATIONS.map((location) => (
                              <div key={location} className="flex items-center space-x-2 mb-2">
                                <Checkbox
                                  id={`location-${location}`}
                                  checked={selectedLocations.includes(location)}
                                  onCheckedChange={() => toggleFilter(location, selectedLocations, setSelectedLocations)}
                                />
                                <label
                                  htmlFor={`location-${location}`}
                                  className="text-sm cursor-pointer flex-1"
                                >
                                  {location}
                                </label>
                              </div>
                            ))}
                          </div>
                          <Separator />
                          <div>
                            <p className="text-sm mb-2">Program Type</p>
                            {FIXED_PROGRAM_TYPES.map((type) => (
                              <div key={type} className="flex items-center space-x-2 mb-2">
                                <Checkbox
                                  id={`program-${type}`}
                                  checked={selectedProgramTypes.includes(type)}
                                  onCheckedChange={() => toggleFilter(type, selectedProgramTypes, setSelectedProgramTypes)}
                                />
                                <label
                                  htmlFor={`program-${type}`}
                                  className="text-sm cursor-pointer flex-1"
                                >
                                  {type}
                                </label>
                              </div>
                            ))}
                          </div>
                        </div>
                      </AccordionContent>
                    </AccordionItem>

                    {/* Job Roles Filter */}
                    <AccordionItem value="jobroles">
                      <AccordionTrigger>
                        Job Roles {selectedJobRoles.length > 0 && `(${selectedJobRoles.length})`}
                      </AccordionTrigger>
                      <AccordionContent>
                        <div className="space-y-2 pl-4">
                          {FIXED_JOB_ROLES.map((role) => (
                            <div key={role} className="flex items-center space-x-2">
                              <Checkbox
                                id={`jobrole-${role}`}
                                checked={selectedJobRoles.includes(role)}
                                onCheckedChange={() => toggleFilter(role, selectedJobRoles, setSelectedJobRoles)}
                              />
                              <label
                                htmlFor={`jobrole-${role}`}
                                className="text-sm cursor-pointer flex-1"
                              >
                                {role}
                              </label>
                            </div>
                          ))}
                        </div>
                      </AccordionContent>
                    </AccordionItem>
                  </Accordion>
                </ScrollArea>
              </div>
            </SheetContent>
          </Sheet>

          {/* Sort Dropdown */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" className="gap-2">
                <ArrowUpDown className="w-4 h-4" />
                Sort: {sortBy === 'newest' ? 'Newest' : sortBy === 'oldest' ? 'Oldest' : sortBy === 'popular' ? 'Most Popular' : 'A-Z'}
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => setSortBy('newest')}>
                Newest First
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setSortBy('oldest')}>
                Oldest First
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setSortBy('popular')}>
                Most Popular
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setSortBy('a-z')}>
                A-Z
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          <div className="ml-auto text-sm text-gray-600 dark:text-gray-400">
            Showing {filteredAndSortedProjects.length} {filteredAndSortedProjects.length === 1 ? 'project' : 'projects'}
          </div>
        </div>

        {/* Active Filters Display */}
        {activeFiltersCount > 0 && (
          <div className="flex flex-wrap gap-2">
            {selectedIndustries.map((industry) => (
              <Badge key={`badge-industry-${industry}`} variant="secondary" className="gap-1">
                {industry}
                <button onClick={() => toggleFilter(industry, selectedIndustries, setSelectedIndustries)}>
                  <X className="w-3 h-3" />
                </button>
              </Badge>
            ))}
            {selectedCourses.map((course) => (
              <Badge key={`badge-course-${course}`} variant="secondary" className="gap-1">
                {course}
                <button onClick={() => toggleFilter(course, selectedCourses, setSelectedCourses)}>
                  <X className="w-3 h-3" />
                </button>
              </Badge>
            ))}
            {selectedLevels.map((level) => (
              <Badge key={`badge-level-${level}`} variant="secondary" className="gap-1">
                {level}
                <button onClick={() => toggleFilter(level, selectedLevels, setSelectedLevels)}>
                  <X className="w-3 h-3" />
                </button>
              </Badge>
            ))}
            {selectedTracks.map((track) => (
              <Badge key={`badge-track-${track}`} variant="secondary" className="gap-1">
                {track}
                <button onClick={() => toggleFilter(track, selectedTracks, setSelectedTracks)}>
                  <X className="w-3 h-3" />
                </button>
              </Badge>
            ))}
            {selectedThemes.map((theme) => (
              <Badge key={`badge-theme-${theme}`} variant="secondary" className="gap-1">
                {theme}
                <button onClick={() => toggleFilter(theme, selectedThemes, setSelectedThemes)}>
                  <X className="w-3 h-3" />
                </button>
              </Badge>
            ))}
            {selectedYears.map((year) => (
              <Badge key={`badge-year-${year}`} variant="secondary" className="gap-1">
                {year}
                <button onClick={() => toggleYearFilter(year)}>
                  <X className="w-3 h-3" />
                </button>
              </Badge>
            ))}
            {selectedSemesters.map((semester) => (
              <Badge key={`badge-semester-${semester}`} variant="secondary" className="gap-1">
                {semester}
                <button onClick={() => toggleFilter(semester, selectedSemesters, setSelectedSemesters)}>
                  <X className="w-3 h-3" />
                </button>
              </Badge>
            ))}
            {selectedJobRoles.map((role) => (
              <Badge key={`badge-jobrole-${role}`} variant="secondary" className="gap-1">
                {role}
                <button onClick={() => toggleFilter(role, selectedJobRoles, setSelectedJobRoles)}>
                  <X className="w-3 h-3" />
                </button>
              </Badge>
            ))}
          </div>
        )}

        {/* Projects Grid or Empty State */}
        {filteredAndSortedProjects.length === 0 ? (
          <EmptyState
            icon={SearchX}
            title="No projects found"
            description="Try adjusting your filters or search query to find what you're looking for."
            actionLabel="Clear All Filters"
            onAction={clearAllFilters}
          />
        ) : (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {displayedProjects.map((project) => (
                <ProjectCard
                  key={project.id}
                  project={project}
                  onClick={() => handleProjectClick(project)}
                />
              ))}
            </div>

            {/* Load More Button */}
            {visibleProjects < filteredAndSortedProjects.length && (
              <div className="flex justify-center mt-8">
                <Button
                  onClick={() => setVisibleProjects((prev) => prev + 8)}
                  variant="outline"
                  size="lg"
                  className="min-w-[200px]"
                >
                  Load More Projects ({filteredAndSortedProjects.length - visibleProjects} remaining)
                </Button>
              </div>
            )}
          </>
        )}
      </div>

      {/* Project Detail Modal */}
      {selectedProject && (
        <ProjectDetailModal
          project={selectedProject}
          onClose={() => setSelectedProject(null)}
          onNext={handleNextProject}
          onPrevious={handlePreviousProject}
        />
      )}
    </div>
  );
}
