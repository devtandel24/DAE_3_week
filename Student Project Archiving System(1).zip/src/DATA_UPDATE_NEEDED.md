# DATA UPDATE NEEDED

## Status
Projects 1-3 have been updated with the new data structure.
Projects 4-20 still need updating.

## Required Changes for Projects 4-20

Each project needs these fields updated:

1. **Change `course` to `courses`** (string → array):
   ```typescript
   // OLD:
   course: 'IoT Systems',
   
   // NEW:
   courses: ['IoT Systems', 'Embedded Systems'],
   ```

2. **Add `location` field**:
   ```typescript
   location: 'New Haven', // or 'Stamford'
   ```

3. **Add `programType` field**:
   ```typescript
   programType: 'Adult', // or 'High School'
   ```

4. **Update `track` to use fixed tracks only**:
   - Web Development
   - Game Development
   - Cybersecurity
   - IoT
   - AI & Data Science
   
   (Remove: Frontend Development, Backend Development, Full-Stack Development, IoT Engineering, Data Science, Cloud Architecture, Mobile Development)

## Quick Fix Pattern

For each project (4-20), find this section and update:

```typescript
// Find:
course: 'SOME_COURSE_NAME',
track: 'SOME_TRACK_NAME',

// Replace with:
courses: ['SOME_COURSE_NAME'],  // Make it an array, can add more courses
track: 'Web Development',  // Use one of the 5 fixed tracks
location: 'New Haven',  // or 'Stamford'
programType: 'Adult',  // or 'High School'
```

## Example Update

**Project 4 - Before:**
```typescript
industry: 'Real Estate',
course: 'IoT Systems',
level: 'Intermediate',
track: 'IoT Engineering',
// ... rest
```

**Project 4 - After:**
```typescript
industry: 'Real Estate',
courses: ['IoT Systems', 'Embedded Systems'],
level: 'Intermediate',
track: 'IoT',
// ... rest
location: 'New Haven',
programType: 'Adult'
```

## Track Mapping Guide

- IoT Engineering → IoT
- Full-Stack Development → Web Development  
- Frontend Development → Web Development
- Backend Development → Web Development
- Data Science → AI & Data Science
- Cloud Architecture → Web Development
- Mobile Development → Web Development

## The app will work with just projects 1-3, but having all 20 updated provides better demo data.
